import { useEffect, useRef, useState } from "react";
import * as C from "./lib/catalog";
import { Rep, SessionError, submitSelection } from "./api";
import { drop, load, save } from "./storage";
import logo from "./assets/cpw-logo.png";

/* In-progress selections autosave to this device so a closed tab, dead
   battery or failed submit never loses a 20 minute meeting. */
const DRAFT_KEY = "cpw-matsel-draft-v1";
type Draft = {
  submissionId: string;
  poolType: PoolType; clientName: string; clientEmail: string;
  projectAddress: string; projectReference: string; holdReason: string;
  vals: Vals; na: Record<string, boolean>;
  decks: number[]; walls: number[]; structs: number[]; nextId: number;
  savedAt: number;
};
const newSubmissionId = () =>
  (typeof crypto !== "undefined" && "randomUUID" in crypto)
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;

/* =====================================================================
   CPW Material Selections — branching, catalog-driven intake form.
   Value store is a flat path map (e.g. "coping.material",
   "decking.0.color") so branching + repeatable areas stay simple.
   ===================================================================== */

const OTHER = "__other__";
type Vals = Record<string, string>;
type PoolType = "Concrete" | "Fiberglass";

export function NewSelectionPage({ rep, onSignOut }: { rep: Rep; onSignOut: (msg?: string) => void }) {
  const [draft] = useState(() => load<Draft>(DRAFT_KEY));
  const [restored, setRestored] = useState(() => !!draft && !!(draft.clientName || Object.keys(draft.vals || {}).length));
  const [submissionId, setSubmissionId] = useState(() => draft?.submissionId ?? newSubmissionId());

  const [poolType, setPoolType] = useState<PoolType>(draft?.poolType ?? "Concrete");
  const [clientName, setClientName] = useState(draft?.clientName ?? "");
  const [clientEmail, setClientEmail] = useState(draft?.clientEmail ?? "");
  const [projectAddress, setProjectAddress] = useState(draft?.projectAddress ?? "");
  const [projectReference, setProjectReference] = useState(draft?.projectReference ?? "");
  const [holdReason, setHoldReason] = useState(draft?.holdReason ?? "");

  const [vals, setVals] = useState<Vals>(draft?.vals ?? {});
  const [na, setNa] = useState<Record<string, boolean>>(draft?.na ?? { structures: true, firebowls: true, walls: true });

  // repeatable areas — arrays of stable ids
  const [decks, setDecks] = useState<number[]>(draft?.decks ?? [0]);
  const [walls, setWalls] = useState<number[]>(draft?.walls ?? [0]);
  const [structs, setStructs] = useState<number[]>(draft?.structs ?? [0]);
  const idRef = useState(() => ({ n: draft?.nextId ?? 100 }))[0];
  const newId = () => idRef.n++;

  // autosave the in-progress selection
  useEffect(() => {
    save(DRAFT_KEY, {
      submissionId, poolType, clientName, clientEmail, projectAddress, projectReference, holdReason,
      vals, na, decks, walls, structs, nextId: idRef.n, savedAt: Date.now(),
    } satisfies Draft);
  }, [submissionId, poolType, clientName, clientEmail, projectAddress, projectReference, holdReason, vals, na, decks, walls, structs, idRef]);

  const startFresh = () => { drop(DRAFT_KEY); window.location.reload(); };

  const [errKeys, setErrKeys] = useState<Set<string>>(new Set());
  const [missing, setMissing] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState<null | "sign_now" | "send_later">(null);

  // Parent pick -> dependent picks that must reset when the parent changes.
  const DEPENDENTS: Record<string, string[]> = {
    "firebowl.model": ["firebowl.size"],
    "firebowl.material": ["firebowl.color"],
  };
  const set = (k: string, v: string) => setVals(p => {
    const next = { ...p, [k]: v };
    if (p[k] !== v) for (const d of DEPENDENTS[k] ?? []) { delete next[d]; delete next[`${d}__other`]; }
    return next;
  });
  const removeDeco = () => setVals(p => {
    const next = { ...p };
    for (const k of Object.keys(next)) if (k.startsWith("waterline.deco.")) delete next[k];
    return next;
  });
  const get = (k: string) => vals[k] ?? "";
  const eff = (k: string): string => {
    const raw = vals[k] ?? "";
    if (raw === OTHER) return (vals[`${k}__other`] ?? "").trim();
    return raw.trim();
  };

  const ctx: Ctx = { vals, set, eff, errKeys };

  /* -------- requirements (mirror render branches) -------- */
  function requirements(): { path: string; label: string }[] {
    const reqs: { path: string; label: string }[] = [];
    const add = (path: string, label: string) => reqs.push({ path, label });

    // Interior finish
    const ib = eff("interior.brand");
    if (ib) {
      if (ib === "StoneScapes") { add("interior.texture", "Interior finish — StoneScapes texture"); add("interior.color", "Interior finish — color"); }
      else if (ib === "JewelScapes") { add("interior.series", "Interior finish — JewelScapes series"); add("interior.color", "Interior finish — color"); }
      else add("interior.color", "Interior finish — color");
    } else add("interior.brand", "Interior finish — brand");

    // Coping
    const cm = eff("coping.material");
    if (!cm) add("coping.material", "Coping — material");
    else if (cm === "Travertine") {
      add("coping.travColor", "Coping — travertine color");
      add("coping.travProfile", "Coping — profile");
      add("coping.travThickness", "Coping — thickness");
    } else if (cm === "Concrete Paver") {
      add("coping.paverProduct", "Coping — paver product");
      add("coping.paverColor", "Coping — paver color");
    } else if (cm === "Flagstone") add("coping.flagColor", "Coping — flagstone color");
    else if (cm === "Cantilever Concrete") add("coping.cantColor", "Coping — color/finish");

    // Waterline (concrete only)
    if (poolType === "Concrete" && !na["waterline"]) {
      add("waterline.brand", "Waterline tile — brand");
      add("waterline.product", "Waterline tile — product");
      const wb = eff("waterline.brand");
      if (wb === "Aquabella") {
        const wv = C.AQUABELLA_CATALOG[eff("waterline.product")];
        if (wv && wv.length) {
          if (wv.some(v => v.color)) add("waterline.color", "Waterline tile — color");
          if (wv.some(v => v.size)) add("waterline.size", "Waterline tile — size");
        }
      } else {
        add("waterline.size", "Waterline tile — size");
      }
      if (eff("waterline.deco.on") === "Yes") {
        add("waterline.deco.product", "Deco tile — product");
        add("waterline.deco.ratio", "Deco tile — pattern ratio");
      }
      add("waterline.grout", "Waterline tile — grout color");
      add("waterline.stepTile", "Waterline tile — step/spa tile included?");
    }

    // Decking areas
    decks.forEach((id, i) => {
      const p = `decking.${id}`;
      const mat = eff(`${p}.material`);
      const n = i + 1;
      if (!mat) { add(`${p}.material`, `Decking area ${n} — material`); return; }
      if (mat === "Travertine") {
        add(`${p}.travColor`, `Decking area ${n} — travertine color`);
        add(`${p}.pattern`, `Decking area ${n} — pattern`);
      } else if (mat === "Concrete Pavers") {
        add(`${p}.paverProduct`, `Decking area ${n} — paver product`);
        add(`${p}.paverColor`, `Decking area ${n} — paver color`);
      } else if (mat === "Poured Concrete") {
        add(`${p}.finish`, `Decking area ${n} — concrete finish`);
      }
    });

    // Retaining walls
    if (!na["walls"]) {
      walls.forEach((id, i) => {
        const p = `walls.${id}`;
        const t = eff(`${p}.type`);
        const n = i + 1;
        if (!t) { add(`${p}.type`, `Retaining wall ${n} — wall type`); return; }
        if (t.startsWith("SRW")) {
          add(`${p}.srwProduct`, `Retaining wall ${n} — SRW product`);
          add(`${p}.srwColor`, `Retaining wall ${n} — SRW color`);
        } else {
          add(`${p}.cmuFinish`, `Retaining wall ${n} — CMU finish`);
        }
      });
    }

    // Fire bowls
    if (!na["firebowls"]) {
      add("firebowl.model", "Fire bowl — model");
      const fm = get("firebowl.model");
      if (fm && fm !== OTHER) add("firebowl.size", "Fire bowl — size");
      add("firebowl.material", "Fire bowl — material");
      const fmat = get("firebowl.material");
      if (fmat && fmat !== OTHER) add("firebowl.color", "Fire bowl — color / finish");
    }

    return reqs;
  }

  function validate(): { missing: string[]; keys: Set<string> } {
    const miss: string[] = [];
    const keys = new Set<string>();
    if (!clientName.trim()) miss.push("Client name");
    if (!clientEmail.trim() || !/^\S+@\S+\.\S+$/.test(clientEmail.trim()))
      miss.push("Client email (needed to send the DocuSign)");
    for (const r of requirements()) {
      if (!eff(r.path)) { miss.push(r.label); keys.add(r.path); }
    }
    return { missing: miss, keys };
  }

  /* -------- payload assembly (flat paths -> nested json) -------- */
  function buildSelections() {
    const root: any = {};
    const put = (path: string, value: string) => {
      const parts = path.split(".");
      let node = root;
      for (let i = 0; i < parts.length - 1; i++) {
        const key = parts[i];
        node[key] = node[key] ?? {};
        node = node[key];
      }
      node[parts[parts.length - 1]] = value;
    };
    for (const k of Object.keys(vals)) {
      if (k.endsWith("__other") || k === "waterline.deco.on") continue;
      if (k.startsWith("waterline.deco.") && eff("waterline.deco.on") !== "Yes") continue;
      const v = eff(k);
      if (!v) continue;
      // skip na / hidden sections
      if (k.startsWith("waterline.") && (poolType !== "Concrete" || na["waterline"])) continue;
      if (k.startsWith("walls.") && na["walls"]) continue;
      if (k.startsWith("structures.") && na["structures"]) continue;
      if (k.startsWith("firebowl.") && na["firebowls"]) continue;
      put(k, v);
    }
    // shell/meta
    root.poolType = poolType;
    // convert repeatable objects to arrays in stable order
    const arrayify = (key: string, ids: number[]) => {
      if (root[key] && typeof root[key] === "object") {
        root[key] = ids.map(id => root[key][id]).filter(Boolean);
      }
    };
    arrayify("decking", decks);
    arrayify("walls", walls);
    arrayify("structures", structs);
    return root;
  }

  async function submit(mode: "sign_now" | "send_later") {
    let complete = true;
    let miss: string[] = [];
    if (mode === "sign_now") {
      const r = validate();
      if (r.missing.length) {
        setMissing(r.missing); setErrKeys(r.keys);
        window.scrollTo({ top: 0, behavior: "smooth" });
        return;
      }
      setErrKeys(new Set()); setMissing([]);
    } else {
      if (!clientName.trim()) { setMissing(["Client name"]); return; }
      const r = validate();
      complete = r.missing.length === 0;
      miss = r.missing;
    }
    setSubmitting(true);
    try {
      await submitSelection(rep, {
        submission_id: submissionId,
        clientName: clientName.trim(),
        clientEmail: clientEmail.trim() || undefined,
        projectAddress: projectAddress.trim() || undefined,
        projectReference: projectReference.trim() || undefined,
        repName: rep.name,
        repEmail: rep.email,
        mode,
        poolType,
        selections: buildSelections(),
        complete,
        missing: miss,
        holdReason: mode === "send_later" ? holdReason.trim() || undefined : undefined,
      });
      drop(DRAFT_KEY);
      setDone(mode);
      window.scrollTo({ top: 0 });
    } catch (e) {
      if (e instanceof SessionError) {
        onSignOut("Your sign in expired. Confirm your email to send. Your selections are saved on this device.");
        return;
      }
      setMissing([`Could not submit: ${e instanceof Error ? e.message : String(e)} Your selections are saved on this device.`]);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } finally {
      setSubmitting(false);
    }
  }

  if (done) {
    return <Confirmation mode={done} clientName={clientName} onNew={() => { drop(DRAFT_KEY); setSubmissionId(newSubmissionId()); window.location.reload(); }} />;
  }

  const naToggle = (key: string, label = "Not applicable") => (
    <label className="msf-na">
      <input type="checkbox" checked={!!na[key]} onChange={e => setNa(p => ({ ...p, [key]: e.target.checked }))} />
      {label}
    </label>
  );

  return (
    <div className="msf">
      <div className="msf-wrap">
        <Topbar name={rep.name} onSignOut={() => onSignOut()} onStartFresh={startFresh} />

        {restored && (
          <div className="msf-notice">
            <span><b>Picked up where you left off</b>{clientName ? ` for ${clientName}` : ""}. Unsent selections stay on this device until you send them.</span>
            <span>
              <button type="button" className="msf-linkbtn" onClick={() => setRestored(false)}>Keep going</button>
              {"  ·  "}
              <button type="button" className="msf-linkbtn" onClick={startFresh}>Start a new client</button>
            </span>
          </div>
        )}

        <div className="msf-hero">
          <p className="msf-eyebrow">Material Selections</p>
          <h1>Let's lock in every finish{clientName ? `, ${clientName.split(" ")[0]}` : ""}.</h1>
          <p className="msf-lede">
            Walk each area with the client and record selections as you make them.
            Pick the material and the fields that matter for it appear. When everything
            is chosen, send it for signature right here so nothing leaves the table undecided.
          </p>
        </div>

        {missing.length > 0 && (
          <div className="msf-errbox show">
            <b>Finish these before you can send for signature:</b>
            <ul>{missing.map(m => <li key={m}>{m}</li>)}</ul>
          </div>
        )}

        {/* 01 project */}
        <Card num="01" title="The project">
          <div className="msf-grid">
            <Field label="Client name" req>
              <input id="client_name" className="msf-input" value={clientName} onChange={e => setClientName(e.target.value)} placeholder="First and last name" />
            </Field>
            <Field label="Client email" req>
              <input id="client_email" className="msf-input" type="email" value={clientEmail} onChange={e => setClientEmail(e.target.value)} placeholder="Where the signature request goes" />
            </Field>
            <Field label="Project address">
              <input id="project_address" className="msf-input" value={projectAddress} onChange={e => setProjectAddress(e.target.value)} placeholder="Street, city" />
            </Field>
            <Field label="Reference / proposal #">
              <input id="project_reference" className="msf-input" value={projectReference} onChange={e => setProjectReference(e.target.value)} placeholder="Optional" />
            </Field>
            <div className="msf-field full">
              <label>Pool type</label>
              <div className="msf-seg" role="group" aria-label="Pool type">
                {(["Concrete", "Fiberglass"] as PoolType[]).map(pt => (
                  <button key={pt} type="button" aria-pressed={poolType === pt} onClick={() => setPoolType(pt)}>{pt}</button>
                ))}
              </div>
              <p className="msf-hint">{poolType === "Fiberglass" ? "Waterline tile is hidden for fiberglass shells." : "Concrete pools include a waterline tile section."}</p>
            </div>
          </div>
        </Card>

        {/* 02 shell */}
        <Card num="02" title="Pool structure & shell">
          <div className="msf-grid">
            <Text ctx={ctx} path="shell.dimensions" label="Overall dimensions" ph="e.g. 32' x 16'" />
            <Text ctx={ctx} path="shell.depth" label="Depth profile" ph="e.g. 3.5' to 5.5'" />
            {poolType === "Fiberglass" && <>
              <Text ctx={ctx} path="shell.manufacturer" label="Fiberglass manufacturer" />
              <Text ctx={ctx} path="shell.model" label="Model name" />
            </>}
          </div>
        </Card>

        {/* 03 interior finish */}
        <Card num="03" title="Pool interior finish">
          <div className="msf-grid">
            <Pick ctx={ctx} path="interior.brand" label="Finish brand" opts={C.INTERIOR_BRANDS} req />
            {eff("interior.brand") === "StoneScapes" && <>
              <Pick ctx={ctx} path="interior.texture" label="Texture / series" opts={C.STONESCAPES_TEXTURES} req />
              <Pick ctx={ctx} path="interior.color" label="Color" req
                opts={eff("interior.texture").includes("Puerto Rico") ? C.STONESCAPES_PRB_COLORS : C.STONESCAPES_COLORS} />
            </>}
            {eff("interior.brand") === "JewelScapes" && <>
              <Pick ctx={ctx} path="interior.series" label="Series" opts={C.JEWELSCAPES_SERIES} req />
              <Pick ctx={ctx} path="interior.color" label="Color" req
                opts={C.JEWELSCAPES_COLORS[eff("interior.series")] ?? []} />
            </>}
            {(eff("interior.brand") === "PebbleTec" || eff("interior.brand") === "Plaster") &&
              <Text ctx={ctx} path="interior.color" label="Color / finish" req />}
            {eff("interior.brand") === OTHER && null}
          </div>
        </Card>

        {/* 04 coping */}
        <Card num="04" title="Pool edge & coping">
          <div className="msf-grid">
            <Pick ctx={ctx} path="coping.material" label="Coping material" opts={C.COPING_MATERIALS} req />
            {eff("coping.material") === "Travertine" && <>
              <Pick ctx={ctx} path="coping.travColor" label="Travertine color" opts={C.TRAVERTINE_COLORS} req />
              <Pick ctx={ctx} path="coping.travProfile" label="Profile" opts={C.TRAVERTINE_PROFILES} req />
              <Pick ctx={ctx} path="coping.travThickness" label="Thickness" opts={C.TRAVERTINE_THICKNESS} req />
            </>}
            {eff("coping.material") === "Concrete Paver" && <>
              <Pick ctx={ctx} path="coping.paverBrand" label="Manufacturer" opts={C.DECK_PAVER_BRANDS} />
              <PaverProduct ctx={ctx} base="coping" />
            </>}
            {eff("coping.material") === "Flagstone" && <>
              <Text ctx={ctx} path="coping.flagColor" label="Flagstone type / color" req />
              <Text ctx={ctx} path="coping.flagSize" label="Size / thickness" />
            </>}
            {eff("coping.material") === "Cantilever Concrete" && <>
              <Text ctx={ctx} path="coping.cantColor" label="Color / finish" req ph="Integral color or finish" />
            </>}
            <Pick ctx={ctx} path="coping.grout" label="Grout / joint color" opts={C.GROUT_COLORS} />
          </div>
        </Card>

        {/* 05 waterline tile (concrete only) */}
        {poolType === "Concrete" && (
          <Card num="05" title="Waterline tile" aside={naToggle("waterline")}>
            {!na["waterline"] && (
              <div className="msf-grid">
                <Pick ctx={ctx} path="waterline.brand" label="Tile brand" opts={C.TILE_BRANDS} req />
                {eff("waterline.brand") === "Aquabella" &&
                  <AquabellaPicker ctx={ctx} base="waterline" req />}
                {eff("waterline.brand") === "NPT" && <>
                  <Combo ctx={ctx} path="waterline.product" label="NPT tile (type to search)" opts={C.NPT_PRODUCTS} req />
                  <Pick ctx={ctx} path="waterline.size" label="Tile size" opts={C.TILE_SIZES} req />
                  <Text ctx={ctx} path="waterline.sku" label="SKU (if provided)" ph="Optional" />
                </>}
                {eff("waterline.brand") === OTHER && <>
                  <Text ctx={ctx} path="waterline.product" label="Tile product" req ph="Tile name" />
                  <Text ctx={ctx} path="waterline.size" label="Tile size" req ph='e.g. 1"x2"' />
                  <Text ctx={ctx} path="waterline.sku" label="SKU (if provided)" ph="Optional" />
                </>}
                <Pick ctx={ctx} path="waterline.pattern" label="Tile pattern" opts={C.TILE_PATTERNS} />
                {eff("waterline.deco.on") === "Yes" ? (
                  <div className="msf-full">
                    <Area title="Deco tile" onRemove={removeDeco}>
                      {eff("waterline.brand") === "Aquabella" ? <AquabellaPicker ctx={ctx} base="waterline.deco" req />
                        : eff("waterline.brand") === "NPT" ? <>
                          <Combo ctx={ctx} path="waterline.deco.product" label="NPT deco tile (type to search)" opts={C.NPT_PRODUCTS} req />
                          <Pick ctx={ctx} path="waterline.deco.size" label="Tile size" opts={C.TILE_SIZES} />
                        </> : <>
                          <Text ctx={ctx} path="waterline.deco.product" label="Deco tile product" req ph="Tile name" />
                          <Text ctx={ctx} path="waterline.deco.size" label="Tile size" ph='e.g. 6"x6"' />
                        </>}
                      <Pick ctx={ctx} path="waterline.deco.ratio" label="Pattern ratio (field to deco)" opts={C.DECO_RATIOS} req />
                    </Area>
                  </div>
                ) : (
                  <div className="msf-full">
                    <button type="button" className="msf-addrow" onClick={() => set("waterline.deco.on", "Yes")}>+ Add deco tile</button>
                  </div>
                )}
                <Pick ctx={ctx} path="waterline.grout" label="Grout color" opts={C.GROUT_COLORS} req />
                <Pick ctx={ctx} path="waterline.stepTile" label="Step / spa tile included?" opts={["Included", "Not included"]} req />
                {eff("waterline.stepTile") === "Included" &&
                  <Text ctx={ctx} path="waterline.stepProduct" label="Step / spa tile product" />}
              </div>
            )}
          </Card>
        )}

        {/* 06 decking (repeatable) */}
        <Card num="06" title="Pool decking & hardscape">
          {decks.map((id, i) => (
            <Area key={id} title={`Deck area ${i + 1}`} onRemove={decks.length > 1 ? () => setDecks(a => a.filter(x => x !== id)) : undefined}>
              <DeckArea ctx={ctx} id={id} />
            </Area>
          ))}
          <button type="button" className="msf-addrow" onClick={() => setDecks(a => [...a, newId()])}>+ Add another deck area</button>
        </Card>

        {/* 07 retaining walls (repeatable) */}
        <Card num="07" title="Retaining walls" aside={naToggle("walls")}>
          {!na["walls"] && <>
            {walls.map((id, i) => (
              <Area key={id} title={`Wall ${i + 1}`} onRemove={walls.length > 1 ? () => setWalls(a => a.filter(x => x !== id)) : undefined}>
                <WallArea ctx={ctx} id={id} />
              </Area>
            ))}
            <button type="button" className="msf-addrow" onClick={() => setWalls(a => [...a, newId()])}>+ Add another wall</button>
          </>}
        </Card>

        {/* 08 structures (repeatable) */}
        <Card num="08" title="Structures (cabana / pavilion)" aside={naToggle("structures")}>
          {!na["structures"] && <>
            {structs.map((id, i) => (
              <Area key={id} title={`Structure ${i + 1}`} onRemove={structs.length > 1 ? () => setStructs(a => a.filter(x => x !== id)) : undefined}>
                <StructureArea ctx={ctx} id={id} />
              </Area>
            ))}
            <button type="button" className="msf-addrow" onClick={() => setStructs(a => [...a, newId()])}>+ Add another structure</button>
          </>}
        </Card>

        {/* 09 fire bowls */}
        <Card num="09" title="Fire bowls & features" aside={naToggle("firebowls")}>
          {!na["firebowls"] && (
            <div className="msf-grid">
              <Pick ctx={ctx} path="firebowl.model" label="Model" opts={C.FIREBOWL_MODELS} req />
              {get("firebowl.model") && get("firebowl.model") !== OTHER &&
                <Pick ctx={ctx} path="firebowl.size" label="Size" opts={C.FIREBOWL_SIZES[get("firebowl.model")] ?? []} req />}
              <Pick ctx={ctx} path="firebowl.material" label="Material" opts={C.FIREBOWL_MATERIALS} req />
              {get("firebowl.material") && get("firebowl.material") !== OTHER &&
                <Pick ctx={ctx} path="firebowl.color" label="Color / finish" req
                  opts={C.FIREBOWL_FINISHES[get("firebowl.material")] ?? []} />}
              <Text ctx={ctx} path="firebowl.qty" label="Quantity" ph="e.g. 2" />
            </div>
          )}
        </Card>

        {/* 10 notes */}
        <Card num="10" title="Notes & custom items">
          <div className="msf-grid">
            <div className="msf-field full">
              <label>Anything else to capture</label>
              <textarea className="msf-textarea" value={get("notes")} onChange={e => set("notes", e.target.value)} placeholder="Special orders, custom items, client requests…" />
            </div>
          </div>
        </Card>

        {/* finalize */}
        <Card num="→" title="Finalize">
          <div className="msf-paths">
            <button data-testid="path-sign-now" className="msf-path primary" type="button" disabled={submitting} onClick={() => submit("sign_now")}>
              <span className="ttl">Send for signature</span>
              <span className="desc">Materials are final. Sends the client a DocuSign to sign right here, on their phone or this laptop, before they leave.</span>
              <span className="cta">{submitting ? "Working…" : "Finalize & send →"}</span>
            </button>
            <button data-testid="path-send-later" className="msf-path" type="button" disabled={submitting} onClick={() => submit("send_later")}>
              <span className="ttl">Can't finalize today</span>
              <span className="desc">Waiting on a sample or special order. Saves everything captured and routes it to Claire to send the DocuSign once it's settled.</span>
              <span className="cta">Save &amp; hand to Claire →</span>
            </button>
          </div>
          <div className="msf-hold msf-field">
            <label>If you can't finalize, what's outstanding? (optional)</label>
            <textarea className="msf-textarea" value={holdReason} onChange={e => setHoldReason(e.target.value)} placeholder="e.g. Client wants to see a travertine sample before choosing the deck color." />
          </div>
        </Card>

        <p className="msf-hint" style={{ textAlign: "center", marginTop: 24 }}>
          Signed in as {rep.name} ({rep.email}) · <button type="button" className="msf-linkbtn" onClick={() => onSignOut()}>Not you? Switch rep</button>
        </p>
      </div>
    </div>
  );
}

/* ============================ primitives ============================ */

interface Ctx {
  vals: Vals;
  set: (k: string, v: string) => void;
  eff: (k: string) => string;
  errKeys: Set<string>;
}

function Card({ num, title, aside, children }: { num: string; title: string; aside?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="msf-card">
      <div className="legend">
        <span className="num">{num}</span>
        <h2>{title}</h2>
        {aside}
      </div>
      {children}
    </div>
  );
}

function Field({ label, req, children }: { label: string; req?: boolean; children: React.ReactNode }) {
  return (
    <div className="msf-field">
      <label>{label}{req && <span className="req">*</span>}</label>
      {children}
    </div>
  );
}

function Area({ title, onRemove, children }: { title: string; onRemove?: () => void; children: React.ReactNode }) {
  return (
    <div className="msf-area">
      <div className="msf-area-head">
        <span className="msf-area-title">{title}</span>
        {onRemove && <button type="button" className="msf-rm sm" aria-label="Remove" onClick={onRemove}>&times;</button>}
      </div>
      <div className="msf-grid">{children}</div>
    </div>
  );
}

function Pick({ ctx, path, label, opts, req, ph }: { ctx: Ctx; path: string; label: string; opts?: string[]; req?: boolean; ph?: string }) {
  if (!opts) return <Text ctx={ctx} path={path} label={label} req={req} ph={ph} />;
  const err = ctx.errKeys.has(path);
  const raw = ctx.vals[path] ?? "";
  const isOther = raw === OTHER;
  return (
    <div className={`msf-field${err ? " err" : ""}`}>
      <label htmlFor={path}>{label}{req && <span className="req">*</span>}</label>
      <select id={path} className="msf-select" value={raw} onChange={e => ctx.set(path, e.target.value)}>
        <option value="">Select…</option>
        {opts.map(o => <option key={o} value={o}>{o}</option>)}
        <option value={OTHER}>Other…</option>
      </select>
      {isOther && (
        <div className="msf-otherwrap">
          <input className="msf-input" placeholder="Type it in" value={ctx.vals[`${path}__other`] ?? ""} onChange={e => ctx.set(`${path}__other`, e.target.value)} />
        </div>
      )}
    </div>
  );
}

function Text({ ctx, path, label, req, ph, full }: { ctx: Ctx; path: string; label: string; req?: boolean; ph?: string; full?: boolean }) {
  const err = ctx.errKeys.has(path);
  return (
    <div className={`msf-field${full ? " full" : ""}${err ? " err" : ""}`}>
      <label htmlFor={path}>{label}{req && <span className="req">*</span>}</label>
      <input id={path} className="msf-input" placeholder={ph ?? ""} value={ctx.vals[path] ?? ""} onChange={e => ctx.set(path, e.target.value)} />
    </div>
  );
}

/* Custom searchable combobox for long lists like tile catalogs. Filters as you
   type, click to select, and offers "Use …" so a rep can still enter something
   not in the list. Replaces the native <datalist>, which was unreliable. */
function Combo({ ctx, path, label, opts, req, ph }: { ctx: Ctx; path: string; label: string; opts: string[]; req?: boolean; ph?: string }) {
  const err = ctx.errKeys.has(path);
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const wrapRef = useRef<HTMLDivElement>(null);
  const val = ctx.vals[path] ?? "";
  useEffect(() => {
    const onDoc = (e: MouseEvent) => { if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);
  const query = (open ? q : "").toLowerCase();
  const filtered = opts.filter(o => o.toLowerCase().includes(query)).slice(0, 80);
  const hasExact = opts.some(o => o.toLowerCase() === q.trim().toLowerCase());
  const pick = (o: string) => { ctx.set(path, o); setOpen(false); setQ(""); };
  return (
    <div className={`msf-field${err ? " err" : ""}`} ref={wrapRef}>
      <label htmlFor={path}>{label}{req && <span className="req">*</span>}</label>
      <div className="msf-combo">
        <input id={path} className="msf-input" autoComplete="off"
          placeholder={ph ?? "Type to search…"}
          value={open ? q : val}
          onFocus={() => { setQ(""); setOpen(true); }}
          onChange={e => { setQ(e.target.value); setOpen(true); }} />
        {open && (
          <ul className="msf-combo-list">
            {filtered.map(o => (
              <li key={o} className={o === val ? "sel" : ""}
                onMouseDown={e => { e.preventDefault(); pick(o); }}>{o}</li>
            ))}
            {q.trim() && !hasExact && (
              <li className="msf-combo-custom" onMouseDown={e => { e.preventDefault(); pick(q.trim()); }}>Use &ldquo;{q.trim()}&rdquo;</li>
            )}
            {filtered.length === 0 && !q.trim() && <li className="msf-combo-empty">Type to search…</li>}
          </ul>
        )}
      </div>
    </div>
  );
}

function uniq(a: string[]): string[] { return Array.from(new Set(a)); }

/* Read-only SKU line that reflects the resolved catalog SKU + stock status. */
function SkuDisplay({ sku, pending, stock }: { sku: string; pending: boolean; stock?: boolean }) {
  return (
    <div className="msf-field">
      <label>SKU <span className="msf-auto">auto</span>
        {sku && (stock
          ? <span className="msf-tag ok">in stock</span>
          : <span className="msf-tag warn">special order</span>)}
      </label>
      <div className={`msf-sku${sku ? " ok" : ""}`}>{sku || (pending ? "Pick color & size…" : "—")}</div>
    </div>
  );
}

/* Aquabella tile: product -> color -> size -> SKU auto-populates from the
   scraped catalog. Products without published SKUs fall back to free entry. */
function AquabellaPicker({ ctx, base, req }: { ctx: Ctx; base: string; req?: boolean }) {
  const product = ctx.eff(`${base}.product`);
  const variations = C.AQUABELLA_CATALOG[product];
  const hasCatalog = !!variations && variations.length > 0;
  const colors = hasCatalog ? uniq(variations.map(v => v.color).filter(Boolean)) : [];
  const usesColor = colors.length > 0;
  const color = ctx.eff(`${base}.color`);
  const sizes = hasCatalog
    ? uniq(variations.filter(v => !usesColor || v.color === color).map(v => v.size).filter(Boolean))
    : [];
  const usesSize = sizes.length > 0;
  const size = ctx.eff(`${base}.size`);
  const match = hasCatalog
    ? variations.find(v => (!usesColor || v.color === color) && (!usesSize || v.size === size))
    : undefined;
  const sku = match?.sku ?? "";
  const stock = match?.stock ?? false;
  const pending = hasCatalog && ((usesColor && !color) || (usesSize && !size));

  useEffect(() => {
    if ((ctx.vals[`${base}.sku`] ?? "") !== sku) ctx.set(`${base}.sku`, sku);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sku]);

  return (
    <>
      <Combo ctx={ctx} path={`${base}.product`} label="Aquabella tile (type to search)" opts={C.AQUABELLA_PRODUCTS} req={req} />
      {hasCatalog ? (
        <>
          {usesColor && <Pick ctx={ctx} path={`${base}.color`} label="Color" opts={colors} req={req} />}
          {usesSize && <Pick ctx={ctx} path={`${base}.size`} label="Tile size" opts={sizes} req={req} />}
          <SkuDisplay sku={sku} pending={pending} stock={stock} />
        </>
      ) : product ? (
        <>
          <Text ctx={ctx} path={`${base}.color`} label="Color" ph="Color name" />
          <Text ctx={ctx} path={`${base}.size`} label="Tile size" ph={`e.g. 1"x2"`} />
          <Text ctx={ctx} path={`${base}.sku`} label="SKU" ph="Enter SKU" />
        </>
      ) : null}
    </>
  );
}

/* Paver product+color+pattern+size whose options depend on the chosen brand and
   product. Patterns/sizes come from per-product maps, falling back to defaults. */
function PaverProduct({ ctx, base }: { ctx: Ctx; base: string }) {
  const brand = ctx.eff(`${base}.paverBrand`);
  const products = brand === "Belgard" ? C.BELGARD_PAVERS : brand === "Techo-Bloc" ? C.TECHOBLOC_PAVERS : undefined;
  const colors = brand === "Belgard" ? C.BELGARD_COLORS : brand === "Techo-Bloc" ? C.TECHOBLOC_COLORS : undefined;
  const product = ctx.eff(`${base}.paverProduct`);
  const patterns = C.PAVER_PATTERNS[brand]?.[product] ?? C.PAVER_PATTERNS_DEFAULT;
  const sizes = C.PAVER_SIZES[brand]?.[product];
  return (
    <>
      <Pick ctx={ctx} path={`${base}.paverProduct`} label="Paver product" opts={products} req />
      <Pick ctx={ctx} path={`${base}.paverColor`} label="Paver color" opts={colors} req />
      {product && <Pick ctx={ctx} path={`${base}.paverPattern`} label="Laying pattern" opts={patterns} />}
      {product && (sizes
        ? <Pick ctx={ctx} path={`${base}.paverSize`} label="Size" opts={sizes} />
        : <Text ctx={ctx} path={`${base}.paverSize`} label="Size / caliber" />)}
    </>
  );
}

/* ============================ section bodies ============================ */

function DeckArea({ ctx, id }: { ctx: Ctx; id: number }) {
  const p = `decking.${id}`;
  const mat = ctx.eff(`${p}.material`);
  return (
    <>
      <Pick ctx={ctx} path={`${p}.material`} label="Material" opts={C.DECK_MATERIALS} req />
      {mat === "Travertine" && <>
        <Pick ctx={ctx} path={`${p}.travColor`} label="Travertine color" opts={C.TRAVERTINE_COLORS} req />
        <Pick ctx={ctx} path={`${p}.pattern`} label="Pattern" opts={C.DECK_PATTERNS} req />
        {["Herringbone", "Running Bond"].includes(ctx.eff(`${p}.pattern`)) &&
          <Text ctx={ctx} path={`${p}.patternSize`} label="Tile size(s)" ph="e.g. 6x12 + 12x12" />}
        <Pick ctx={ctx} path={`${p}.grout`} label="Grout / joint color" opts={C.GROUT_COLORS} />
      </>}
      {mat === "Concrete Pavers" && <>
        <Pick ctx={ctx} path={`${p}.paverBrand`} label="Manufacturer" opts={C.DECK_PAVER_BRANDS} />
        <PaverProduct ctx={ctx} base={p} />
      </>}
      {mat === "Poured Concrete" && <>
        <Pick ctx={ctx} path={`${p}.finish`} label="Concrete finish" opts={C.CONCRETE_FINISHES} req />
        {ctx.eff(`${p}.finish`) === "Broom Finish" && <>
          <Pick ctx={ctx} path={`${p}.integralColor`} label="Integral color added?" opts={["Yes", "No"]} />
          {ctx.eff(`${p}.integralColor`) === "Yes" &&
            <Text ctx={ctx} path={`${p}.integralColorNo`} label="Integral color # / name" ph="Mix color number" />}
        </>}
        {ctx.eff(`${p}.finish`) === "Spray Deck" &&
          <Text ctx={ctx} path={`${p}.sprayColor`} label="Spray deck color" req />}
      </>}
      {(mat === "Flagstone" || mat === "Porcelain Pavers") && <>
        <Text ctx={ctx} path={`${p}.color`} label="Color / product" req />
        <Text ctx={ctx} path={`${p}.size`} label="Size" />
        <Pick ctx={ctx} path={`${p}.grout`} label="Grout / joint color" opts={C.GROUT_COLORS} />
      </>}
    </>
  );
}

function WallArea({ ctx, id }: { ctx: Ctx; id: number }) {
  const p = `walls.${id}`;
  const t = ctx.eff(`${p}.type`);
  const cmuCoping = ctx.eff(`${p}.cmuCoping`);
  return (
    <>
      <Pick ctx={ctx} path={`${p}.type`} label="Wall type" opts={C.WALL_TYPES} req />
      {t.startsWith("SRW") && <>
        <Pick ctx={ctx} path={`${p}.srwProduct`} label="Wall product" opts={C.SRW_PRODUCTS} req />
        <Pick ctx={ctx} path={`${p}.srwColor`} label="Wall color" opts={C.DIAMOND_PRO_COLORS} req />
        <Pick ctx={ctx} path={`${p}.copingProduct`} label="Coping product" opts={C.SRW_COPING_PRODUCTS} />
        <Text ctx={ctx} path={`${p}.copingColor`} label="Coping color" ph="Matches wall" />
      </>}
      {t === "CMU Block Wall" && <>
        <Pick ctx={ctx} path={`${p}.cmuFinish`} label="Wall finish" opts={C.CMU_FINISHES} req />
        {ctx.eff(`${p}.cmuFinish`) === "Stucco" &&
          <Text ctx={ctx} path={`${p}.stuccoPaint`} label="Stucco paint # (Sherwin-Williams)" req />}
        {ctx.eff(`${p}.cmuFinish`) === "Split-face Travertine" &&
          <Pick ctx={ctx} path={`${p}.splitFaceColor`} label="Travertine color" opts={C.TRAVERTINE_COLORS} req />}
        {["Stone Veneer", "Brick Veneer"].includes(ctx.eff(`${p}.cmuFinish`)) &&
          <Text ctx={ctx} path={`${p}.veneerSku`} label="Veneer SKU / product" req />}
        <Pick ctx={ctx} path={`${p}.cmuCoping`} label="Coping" opts={C.CMU_COPING_OPTIONS} />
        {cmuCoping === "Travertine Coping" && <>
          <Pick ctx={ctx} path={`${p}.travColor`} label="Travertine color" opts={C.TRAVERTINE_COLORS} />
          <Pick ctx={ctx} path={`${p}.travProfile`} label="Profile" opts={C.TRAVERTINE_PROFILES} />
          <Pick ctx={ctx} path={`${p}.travThickness`} label="Thickness" opts={C.TRAVERTINE_THICKNESS} />
          <Pick ctx={ctx} path={`${p}.travSize`} label="Coping size" opts={C.TRAVERTINE_COPING_SIZES} />
        </>}
        {cmuCoping === "Brick Coping" &&
          <Text ctx={ctx} path={`${p}.brickCoping`} label="Brick / color" />}
        {cmuCoping === "Flagstone Coping" &&
          <Text ctx={ctx} path={`${p}.flagCoping`} label="Flagstone / color" />}
      </>}
    </>
  );
}

function StructureArea({ ctx, id }: { ctx: Ctx; id: number }) {
  const p = `structures.${id}`;
  const ceiling = ctx.eff(`${p}.ceiling`);
  const posts = ctx.eff(`${p}.posts`);
  const extWall = ctx.eff(`${p}.extWall`);
  const roof = ctx.eff(`${p}.roof`);
  return (
    <>
      <Text ctx={ctx} path={`${p}.name`} label="Structure type" ph="e.g. Cabana, Pavilion" />
      {/* fascia & soffit */}
      <Pick ctx={ctx} path={`${p}.fasciaMaterial`} label="Fascia / soffit material" opts={C.FASCIA_MATERIALS} />
      {ctx.eff(`${p}.fasciaMaterial`).startsWith("Miratec") &&
        <Text ctx={ctx} path={`${p}.fasciaPaint`} label="Fascia / soffit paint (SW #)" />}
      {ctx.eff(`${p}.fasciaMaterial`).startsWith("Cedar") &&
        <Text ctx={ctx} path={`${p}.fasciaStain`} label="Fascia / soffit stain color" />}
      {/* ceiling */}
      <Pick ctx={ctx} path={`${p}.ceiling`} label="Ceiling material" opts={C.CEILING_MATERIALS} />
      {ceiling === "TNG (tongue & groove)" && <>
        <Pick ctx={ctx} path={`${p}.ceilingFinish`} label="Ceiling finish" opts={C.CEILING_FINISHES} />
        {ctx.eff(`${p}.ceilingFinish`) === "Painted" &&
          <Text ctx={ctx} path={`${p}.ceilingPaint`} label="Ceiling paint (SW #)" />}
        {ctx.eff(`${p}.ceilingFinish`) === "Stained" &&
          <Text ctx={ctx} path={`${p}.ceilingStain`} label="Ceiling stain color" />}
      </>}
      {ceiling === "Hardie Board" &&
        <Text ctx={ctx} path={`${p}.ceilingPaint`} label="Ceiling paint (SW #)" />}
      {/* posts */}
      <Pick ctx={ctx} path={`${p}.posts`} label="Posts" opts={C.POST_WRAPS} />
      {posts === "Miratec wrapped" &&
        <Text ctx={ctx} path={`${p}.postPaint`} label="Post paint (SW #)" />}
      {posts === "Cedar wrapped" &&
        <Text ctx={ctx} path={`${p}.postStain`} label="Post stain color" />}
      {/* exterior walls */}
      <Pick ctx={ctx} path={`${p}.extWall`} label="Exterior wall" opts={C.EXTERIOR_WALL_TYPES} />
      {extWall === "Brick" &&
        <Text ctx={ctx} path={`${p}.extBrick`} label="Brick product / color" />}
      {extWall === "Cedar Siding" &&
        <Text ctx={ctx} path={`${p}.extStain`} label="Cedar stain color" />}
      {(extWall === "Lap Siding" || extWall === "Board and Batten") &&
        <Text ctx={ctx} path={`${p}.extPaint`} label="Exterior paint (SW #)" />}
      {/* downspouts */}
      <Text ctx={ctx} path={`${p}.gutters`} label="Downspouts / gutters color" />
      {/* roof */}
      <Pick ctx={ctx} path={`${p}.roof`} label="Roof type" opts={C.ROOF_TYPES} />
      {roof && <Text ctx={ctx} path={`${p}.roofColor`} label="Roof color" />}
      {/* wood details */}
      <Pick ctx={ctx} path={`${p}.woodDetail`} label="Wood detail (truss/gable)" opts={C.WOOD_DETAIL_MATERIALS} />
      {ctx.eff(`${p}.woodDetail`).startsWith("Miratec") &&
        <Text ctx={ctx} path={`${p}.woodDetailPaint`} label="Wood detail paint (SW #)" />}
      {ctx.eff(`${p}.woodDetail`).startsWith("Cedar") &&
        <Text ctx={ctx} path={`${p}.woodDetailStain`} label="Wood detail stain color" />}
    </>
  );
}

/* ============================ chrome ============================ */

function Topbar({ name, onSignOut, onStartFresh }: { name?: string | null; onSignOut?: () => void; onStartFresh?: () => void }) {
  return (
    <div className="msf-topbar">
      <img src={logo} alt="Contemporary Pool Works" className="msf-logo" />
      <div className="who">
        {name ? <>Rep: {name}<br /></> : null}
        {onStartFresh && <button type="button" className="msf-linkbtn" onClick={onStartFresh}>New client</button>}
        {onStartFresh && onSignOut && " · "}
        {onSignOut && <button type="button" className="msf-linkbtn" onClick={onSignOut}>Switch rep</button>}
      </div>
    </div>
  );
}

function Confirmation({ mode, clientName, onNew }: { mode: "sign_now" | "send_later"; clientName: string; onNew: () => void }) {
  const signNow = mode === "sign_now";
  return (
    <div className="msf">
      <div className="msf-wrap">
        <Topbar name={null} />
        <div className={`msf-done${signNow ? "" : " hold"}`}>
          <div className="tick">{signNow ? "✓" : "⏳"}</div>
          <h2>{signNow ? "Sent for signature" : "Saved for follow-up"}</h2>
          <p>
            {signNow
              ? `${clientName || "The client"} will get a DocuSign to approve these selections. They can sign on their phone or on this laptop before they leave.`
              : `Everything captured so far is saved. Claire will send ${clientName || "the client"} the DocuSign once the outstanding materials are settled.`}
          </p>
          <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
            <button className="msf-btn gold" type="button" onClick={onNew}>Start a new selection</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default NewSelectionPage;
