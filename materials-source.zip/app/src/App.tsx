import { useEffect, useState } from "react";
import { NewSelectionPage } from "./NewSelectionPage";
import { checkSession, Rep, REP_DOMAIN, requestCode, SessionError, verifyCode } from "./api";
import { drop, load, save } from "./storage";
import logo from "./assets/cpw-logo.png";

const REP_KEY = "cpw-matsel-rep-v2";          // signed in rep (name, email, token)
const LAST_KEY = "cpw-matsel-last-rep";       // prefill for the next sign in

export function App() {
  const [rep, setRep] = useState<Rep | null>(() => load<Rep>(REP_KEY));
  const [notice, setNotice] = useState("");

  const signOut = (msg = "") => {
    drop(REP_KEY);
    setRep(null);
    setNotice(msg);
  };

  // Confirm the saved sign in is still good, so an expired one surfaces at the
  // start of a meeting instead of at submit. Network trouble is ignored here.
  useEffect(() => {
    if (!rep) return;
    checkSession(rep.token).catch(e => {
      if (e instanceof SessionError) signOut(e.message);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!rep) {
    return (
      <RepGate
        notice={notice}
        onSignedIn={r => {
          save(REP_KEY, r);
          save(LAST_KEY, { name: r.name, email: r.email });
          setRep(r);
          setNotice("");
        }}
      />
    );
  }
  return <NewSelectionPage rep={rep} onSignOut={signOut} />;
}

function RepGate({ notice, onSignedIn }: { notice: string; onSignedIn: (r: Rep) => void }) {
  const last = load<{ name: string; email: string }>(LAST_KEY);
  const [step, setStep] = useState<"email" | "code">("email");
  const [name, setName] = useState(last?.name ?? "");
  const [email, setEmail] = useState(last?.email ?? "");
  const [code, setCode] = useState("");
  const [err, setErr] = useState(notice);
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);

  const cleanEmail = email.trim().toLowerCase();

  async function sendCode(e?: React.FormEvent) {
    e?.preventDefault();
    setErr(""); setInfo("");
    if (name.trim().length < 2) return setErr("Enter your name.");
    if (!cleanEmail.endsWith("@" + REP_DOMAIN) || !/^\S+@\S+$/.test(cleanEmail)) {
      return setErr(`Use your @${REP_DOMAIN} email address.`);
    }
    setBusy(true);
    try {
      await requestCode(name.trim(), cleanEmail);
      setStep("code");
      setCode("");
      setInfo(`We emailed a 6 digit code to ${cleanEmail}. It expires in 15 minutes.`);
    } catch (x) {
      setErr(x instanceof Error ? x.message : String(x));
    } finally {
      setBusy(false);
    }
  }

  async function confirm(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    const c = code.replace(/\D/g, "");
    if (c.length !== 6) return setErr("Enter the 6 digit code from your email.");
    setBusy(true);
    try {
      onSignedIn(await verifyCode(cleanEmail, c));
    } catch (x) {
      setErr(x instanceof Error ? x.message : String(x));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="msf">
      <div className="msf-wrap msf-gate">
        <div className="msf-topbar">
          <img src={logo} alt="Contemporary Pool Works" className="msf-logo" />
        </div>
        <div className="msf-hero">
          <p className="msf-eyebrow">Material Selections</p>
          <h1>{step === "email" ? "Rep sign in." : "Check your email."}</h1>
          <p className="msf-lede">
            {step === "email"
              ? `New or returning, same steps: enter your name and your @${REP_DOMAIN} email and we'll email you a code. You stay signed in on this device for 30 days.`
              : "Enter the code we just sent. Check spam if it's not there in a minute."}
          </p>
        </div>

        {step === "email" ? (
          <form className="msf-card" onSubmit={sendCode}>
            {err && <div className="msf-errbox show" style={{ marginTop: 0 }}><b>{err}</b></div>}
            <div className="msf-grid">
              <div className="msf-field">
                <label htmlFor="rep_name">Your name<span className="req">*</span></label>
                <input id="rep_name" className="msf-input" autoComplete="name" value={name} onChange={e => setName(e.target.value)} placeholder="First and last name" />
              </div>
              <div className="msf-field">
                <label htmlFor="rep_email">Your CPW email<span className="req">*</span></label>
                <input id="rep_email" className="msf-input" type="email" autoComplete="email" inputMode="email" value={email} onChange={e => setEmail(e.target.value)} placeholder={`you@${REP_DOMAIN}`} />
              </div>
            </div>
            <div style={{ marginTop: 20 }}>
              <button className="msf-btn gold" type="submit" disabled={busy}>{busy ? "Sending…" : "Email me a code →"}</button>
            </div>
          </form>
        ) : (
          <form className="msf-card" onSubmit={confirm}>
            {err && <div className="msf-errbox show" style={{ marginTop: 0 }}><b>{err}</b></div>}
            {info && !err && <p className="msf-hint" style={{ marginTop: 0, marginBottom: 14, fontSize: 14, color: "var(--muted)" }}>{info}</p>}
            <div className="msf-grid">
              <div className="msf-field full">
                <label htmlFor="rep_code">6 digit code<span className="req">*</span></label>
                <input id="rep_code" className="msf-input" autoComplete="one-time-code" inputMode="numeric" maxLength={6}
                  value={code} onChange={e => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))} placeholder="123456"
                  style={{ letterSpacing: "0.3em", fontSize: 20 }} autoFocus />
              </div>
            </div>
            <div style={{ marginTop: 20, display: "flex", gap: 16, alignItems: "center", flexWrap: "wrap" }}>
              <button className="msf-btn gold" type="submit" disabled={busy}>{busy ? "Checking…" : "Sign in →"}</button>
              <button type="button" className="msf-linkbtn" disabled={busy} onClick={() => sendCode()}>Send a new code</button>
              <button type="button" className="msf-linkbtn" disabled={busy} onClick={() => { setStep("email"); setErr(""); setInfo(""); }}>Use a different email</button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
