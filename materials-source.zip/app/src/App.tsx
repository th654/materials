import { useState } from "react";
import { NewSelectionPage } from "./NewSelectionPage";
import { Rep, verifyRep } from "./api";
import { drop, load, save } from "./storage";
import logo from "./assets/cpw-logo.png";

const REP_KEY = "cpw-matsel-rep-v1";

export function App() {
  const [rep, setRep] = useState<Rep | null>(() => load<Rep>(REP_KEY));
  const [notice, setNotice] = useState("");

  const signOut = (msg = "") => {
    drop(REP_KEY);
    setRep(null);
    setNotice(msg);
  };

  if (!rep) {
    return (
      <RepGate
        notice={notice}
        onSignedIn={r => { save(REP_KEY, r); setRep(r); setNotice(""); }}
      />
    );
  }
  return <NewSelectionPage rep={rep} onSignOut={signOut} />;
}

function RepGate({ notice, onSignedIn }: { notice: string; onSignedIn: (r: Rep) => void }) {
  const prev = load<Rep>(REP_KEY);
  const [name, setName] = useState(prev?.name ?? "");
  const [email, setEmail] = useState(prev?.email ?? "");
  const [passcode, setPasscode] = useState("");
  const [err, setErr] = useState(notice);
  const [busy, setBusy] = useState(false);

  async function go(e: React.FormEvent) {
    e.preventDefault();
    const r: Rep = { name: name.trim(), email: email.trim().toLowerCase(), passcode: passcode.trim() };
    if (!r.name || !/^\S+@\S+\.\S+$/.test(r.email) || !r.passcode) {
      setErr("Enter your name, work email and the rep passcode.");
      return;
    }
    setBusy(true);
    setErr("");
    try {
      await verifyRep(r);
      onSignedIn(r);
    } catch (x) {
      setErr(x instanceof Error ? x.message : String(x));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="msf">
      <div className="msf-wrap msf-gate">
        <div className="msf-topbar">
          <img src={logo} alt="Contemporary Pool Works" className="msf-logo" />
        </div>
        <div className="msf-hero">
          <p className="msf-eyebrow">Material Selections</p>
          <h1>Rep sign in.</h1>
          <p className="msf-lede">
            One time per device. Your name and email go on every selection sheet you send.
          </p>
        </div>
        <form className="msf-card" onSubmit={go}>
          {err && <div className="msf-errbox show" style={{ marginTop: 0 }}><b>{err}</b></div>}
          <div className="msf-grid">
            <div className="msf-field">
              <label htmlFor="rep_name">Your name<span className="req">*</span></label>
              <input id="rep_name" className="msf-input" autoComplete="name" value={name} onChange={e => setName(e.target.value)} placeholder="First and last name" />
            </div>
            <div className="msf-field">
              <label htmlFor="rep_email">Your work email<span className="req">*</span></label>
              <input id="rep_email" className="msf-input" type="email" autoComplete="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@cpoolworks.com" />
            </div>
            <div className="msf-field full">
              <label htmlFor="rep_pass">Rep passcode<span className="req">*</span></label>
              <input id="rep_pass" className="msf-input" type="password" autoComplete="current-password" value={passcode} onChange={e => setPasscode(e.target.value)} placeholder="From the office" />
            </div>
          </div>
          <div style={{ marginTop: 20 }}>
            <button className="msf-btn gold" type="submit" disabled={busy}>{busy ? "Checking…" : "Continue →"}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
