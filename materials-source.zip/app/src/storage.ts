/* localStorage wrappers that never throw (private mode, blocked storage). */
export function load<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}
export function save(key: string, value: unknown) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* ignore */ }
}
export function drop(key: string) {
  try { localStorage.removeItem(key); } catch { /* ignore */ }
}
