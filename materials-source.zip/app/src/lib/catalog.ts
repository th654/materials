// CPW Material Selections — product catalog data.
// Sourced from manufacturer sites (Sep 2026) + Thomas's spec. Every dropdown in
// the form also offers "Other…" so the rep can type anything not listed.
// Tile lists (NPT + Aquabella) are the FULL product lines scraped from
// nptpool.com/tile and aquabellatile.com/product-category/tile — see bottom.

/* ---------------- Pool interior finish ---------------- */
export const INTERIOR_BRANDS = ["StoneScapes", "Quartz", "JewelScapes", "PebbleTec", "Plaster"];

export const STONESCAPES_TEXTURES = [
  "Mini Pebble",
  "Glass Mini Pebble",
  "Regular Pebble",
  "Micro Pebble",
  "Small Puerto Rico Blend",
  "Large Puerto Rico Blend",
  "Touch of Glass",
];
export const STONESCAPES_COLORS = [
  "Aqua Blue", "Aqua Cool", "Aqua White", "Black", "Cameroon", "Caribbean Blue",
  "French Gray", "Mauve", "Midnight Blue", "Salt and Pepper", "Sand", "Tahoe Blue",
  "Tropics Blue", "White", "Zanzibar",
];
// Colors by finish as Ochoa's Pool prices them (2026 price sheet, in tier order: standard, premium, upgrade). The tier sets the
// price; it comes from Claire's price sheet, never from this file.
export const MINI_PEBBLE_COLORS = ["White", "Aqua Cool", "Salt & Pepper", "Caribbean Blue", "Tahoe Blue", "Bermuda Blue", "Aqua White", "Sand", "French Grey", "Jade", "Aqua Blue", "Dapple Grey", "Rubicon Bay", "Irish Mist", "Mauve", "Emerald", "Tropics Blue", "Midnight Blue", "Zanzibar White", "Black", "Cameroon"];
export const GLASS_MINI_PEBBLE_COLORS = ["White", "Aqua Cool", "Salt & Pepper", "Caribbean Blue", "Bermuda Blue", "Aqua White", "Sand", "French Grey", "Jade", "Aqua Blue", "Dapple Grey", "Rubicon Bay", "Tahoe Blue", "Hokitika George", "Andalusian", "Twizel", "Kingfisher", "Tropics Blue", "Midnight Blue", "Black"];
export const QUARTZ_COLORS = ["Ivory", "Diamond Brite", "Blue", "Mariner Blue", "Tropical Blue", "Sky Blue", "French Grey", "Bluefish", "Damselfly", "Anvil", "Dorado", "Aruba Sky", "Curacao Night", "Cappuccino", "Wahoo", "Royal Tang", "Midnight Blue", "Grenadine Gray", "Bonsai", "Mojave Beige", "Tahoe Blue", "Barbados Blue", "Montego Bay", "St. Matron Shade", "Zephyr Cove"];
export const PLASTER_COLORS = ["White", "White Extra Blue"];
export const STONESCAPES_PRB_COLORS = [
  "Aqua Blue", "Aqua Cool", "Aqua White", "Black", "Caribbean Blue", "French Gray",
  "Kingfisher", "Midnight Blue", "Sand", "Tahoe Blue", "Tropics Blue",
];
export const JEWELSCAPES_SERIES = [
  "Classic", "Reflective", "Opal Puerto Rico Blend", "Opal PRB Iridescent",
];
export const JEWELSCAPES_COLORS: Record<string, string[]> = {
  Classic: ["Spring Water", "Marina Blue", "Yacht Club Blue", "Windsurfer", "Waterfall"],
  Reflective: ["Peyto", "Azora", "Yosemite", "Mariana", "Aquamarine", "Crystal", "Iolite"],
  "Opal Puerto Rico Blend": ["Aruba Sky", "Barbados Blue", "French Gray", "Sea Mist", "Sky Blue", "Tahoe Blue"],
  "Opal PRB Iridescent": ["Barbados Blue", "Playa Blanca", "Sea Mist", "Sky Blue"],
};


/* ---------------- Fiberglass shells (Oct 2026, manufacturer sites) ---------------- */
export const FIBERGLASS_MANUFACTURERS = ["Latham", "Liberty"];
export const LATHAM_SHELLS = [
  "Apollo 14", "Ariel 16", "Aruba", "Astoria 12", "Astoria 14", "Astoria 16", "Athens 13.23", "Athens 13.37",
  "Axiom 12", "Axiom 12 Deluxe", "Axiom 14", "Axiom 14 Deluxe", "Axiom 16", "Barcelona", "Bay Isle",
  "Bermuda 12", "Bermuda 12 Deluxe", "Bermuda 14", "Bermuda 14 Deluxe", "Bermuda 16.35", "Bermuda 16.35 Deluxe", "Bermuda 16.40",
  "Cape Cod 12", "Cape Cod 14", "Cape Cod 16", "Cayman 14", "Cayman 14 Deluxe", "Cayman 16", "Claremont", "Claremont Flat Bottom",
  "Coral 16", "Corinthian 12", "Corinthian 14", "Corinthian 16", "Coronado", "Delray",
  "Enchantment 9.17", "Enchantment 9.21", "Enchantment 9.24", "Fiji", "Jamaica 10", "Jamaica 12", "Jamaica 14",
  "Key West", "Kingston", "Lake Shore", "Lake Shore 15.35", "Milan 8.14", "Milan 10.16", "Milan 10.20", "Monaco", "Nouveau 14",
  "Olympia 12", "Olympia 14", "Olympia 16", "Pleasant Cove", "Providence 14", "Renaissance 14",
  "San Marino 12.23", "San Marino 12.26", "Sirius", "St. Thomas", "Synergy", "Synergy Grand",
  "Tuscan 11.20", "Tuscan 13.24", "Tuscan 14.27", "Tuscan 14.30", "Tuscan 14.40", "Vista Isle",
];
export const LIBERTY_SHELLS = [
  "Anthem", "Compassion 12.23", "Compassion 12.26", "Devotion", "Dignity",
  "Enlightenment 8.14", "Enlightenment 10.16", "Enlightenment 10.20", "Enrichment 9.17", "Enrichment 9.21", "Enrichment 9.24",
  "Finesse", "Glory", "Heavenly 14", "Heavenly 14 Deluxe", "Heavenly 16", "Hero", "Hero Deluxe", "Independence", "Merit",
  "Opportunity", "Poise", "Relaxation", "Relaxation Deluxe", "Stature 13.23", "Stature 13.37", "Tradition",
  "Unity", "Unity Deluxe", "Valiant", "Victory", "Virtue", "Virtuous",
];
export const FIBERGLASS_SHELLS: Record<string, string[]> = { Latham: LATHAM_SHELLS, Liberty: LIBERTY_SHELLS };
// Shell colors. Latham: Crystite Crystal (standard) and Crystite Classic (upgrade). Liberty: Crystite Classic.
export const LATHAM_COLORS = [
  "Ocean Blue", "Sapphire Blue", "Night Sky", "Shale Gray", "Coastal Bronze", "Pearl White",
  "Ocean Blue Classic", "Sapphire Blue Classic", "Night Sky Classic", "Shale Gray Classic", "Coastal Bronze Classic", "Whisper White",
];
export const LIBERTY_COLORS = ["Sapphire Blue", "Ocean Blue", "Night Sky"];
export const FIBERGLASS_COLORS: Record<string, string[]> = { Latham: LATHAM_COLORS, Liberty: LIBERTY_COLORS };

/* ---------------- Coping ---------------- */
export const COPING_MATERIALS = ["Travertine", "Flagstone", "Concrete Paver", "Cantilever Concrete"];
// LMN is the source of truth for what CPW offers (Thomas, Nov 12 2026): SiteOne bid #8932922. Walnut replaces Noche.
export const TRAVERTINE_COLORS = ["Ivory", "Silver", "Walnut", "Diana Royale", "Ice White", "Marla Grey", "Tundra Grey", "Moon Cream"];
export const TRAVERTINE_PROFILES = ["Bullnose", "Modern Edge"];
export const TRAVERTINE_THICKNESS = ["3 cm", "5 cm"];
// Travertine coping sizes: pool coping and wall/stamped-block coping.
export const TRAVERTINE_COPING_SIZES = ["6x12", "12x24"];

/* ---------------- Waterline tile ---------------- */
export const TILE_BRANDS = ["NPT", "Aquabella"];
export const TILE_SIZES = ['1"x1"', '1"x2"', '1"x3"', '2"x2"', '2"x3"', '2"x4"', '3"x3"', '3"x6"', '6"x6"', '6"x12"', '6"x18"', '6"x24"', '12"x24"'];
export const TILE_PATTERNS = ["Straight / Stacked", "Offset / Running Bond", "Vertical Stack", "Blend"];
export const DECO_RATIOS = ["3:1 (3 field to 1 deco)", "4:1 (4 field to 1 deco)", "5:1 (5 field to 1 deco)", "2:1 (2 field to 1 deco)", "1:1 (alternating)"];
export const GROUT_COLORS = ["Bright White", "Snow White", "Gray", "Silver", "Charcoal", "Tan", "Natural"];

/* ---------------- Decking ---------------- */
export const DECK_MATERIALS = [
  "Travertine", "Concrete Pavers", "Poured Concrete", "Flagstone", "Porcelain Pavers",
];
// Techo-Bloc and Unilock are Indiana market lines, not SC (Thomas, Nov 13 2026).
export const DECK_PAVER_BRANDS = ["Belgard"];

// Belgard — paver lines + full color palette (regional availability varies).
export const BELGARD_PAVERS = [
  "Dublin Cobble", "Mega-Arbel", "Catalina Grana", "Cambridge Cobble", "Origins",
  "Dimensions", "Melville Plank", "Lafitt", "Belgian Cobble", "Appian Cobble",
  "Holland Stone", "Avalon Slate", "Trilogy", "Charlestone",
];
export const BELGARD_COLORS = [
  "Anthracite", "Ashwood", "Bella", "Bourbon", "Cheswick", "Danville Beige", "Fog",
  "Foundry", "Harvest Blend", "Hickory", "Iron Bay", "Midnight", "Napoli", "Newport Gray",
  "Pearl", "Rainier", "Rio", "Rosewood", "Sable Blend", "Scandina Gray", "Sepia",
  "Shaded Gray", "Sierra", "Sonoran Gray", "Teak", "Toscana", "Victorian",
];
// Techo-Bloc — paver lines + full color palette.
export const TECHOBLOC_PAVERS = [
  "Blu 60 Smooth", "Blu 60 Slate", "Blu 80 Smooth", "Villagio", "Mika", "Saint-Oxford",
  "Pure", "Eva Slate", "Antika", "Industria", "Aberdeen", "Diamond", "Westmount",
];
export const TECHOBLOC_COLORS = [
  "Stardust Beige", "Mineral White", "Moonrock Grey", "Meteor Black", "Bordeaux Red",
  "Midnight Grey", "Sepia Brown", "Silver Granite", "Caffè Crema", "Greyed Nickel",
  "Champlain Grey", "Onyx Black", "Shale Grey", "Beige Cream", "Chestnut Brown",
  "Sandlewood", "Riviera", "Smoked Pine", "Hazelnut Brandy", "Azzurro", "Merlot",
  "Victoria", "Chocolate Brown", "Charcoal", "Grey", "Salt and Pepper", "Pure White",
];

// Generic laying patterns used when a product has no curated list.
export const PAVER_PATTERNS_DEFAULT = [
  "Running Bond", "Herringbone 45°", "Herringbone 90°", "Modular / Ashlar",
  "Basketweave", "Random / No-repeat",
];
// Per-product laying patterns (brand -> product -> patterns). Sourced from the
// manufacturers' pattern guides. Products not listed fall back to the default.
export const PAVER_PATTERNS: Record<string, Record<string, string[]>> = {
  "Techo-Bloc": {
    "Blu 60 Smooth": ["Modular", "Linear", "Herringbone", "Parquet"],
    "Blu 60 Slate": ["Modular", "Linear", "Herringbone", "Parquet"],
    "Blu 80 Smooth": ["Modular", "Linear", "Herringbone"],
    "Industria": ["Linear", "Modular", "Herringbone"],
    "Villagio": ["Running Bond", "Modular", "Herringbone", "Random"],
    "Mika": ["Linear", "Modular"],
    "Antika": ["Random / No-repeat", "Modular"],
    "Eva Slate": ["Linear", "Modular"],
    "Aberdeen": ["Random / No-repeat", "Modular"],
  },
  "Belgard": {
    "Dublin Cobble": ["3-Piece Running Bond", "3-Piece Modular", "Large Square"],
    "Mega-Arbel": ["Cloverleaf / Random"],
    "Cambridge Cobble": ["Running Bond", "Herringbone", "Modular"],
    "Lafitt": ["Ashlar / Modular", "Running Bond"],
    "Catalina Grana": ["Modular", "Random"],
    "Melville Plank": ["Linear / Plank", "Ashlar"],
    "Holland Stone": ["Running Bond", "Herringbone 45°", "Herringbone 90°", "Basketweave"],
    "Belgian Cobble": ["Running Bond", "Modular", "Circle / Fan"],
    "Appian Cobble": ["Running Bond", "Modular"],
  },
};

// Per-product face sizes where size selection matters. Products not listed use
// a free type-in size field.
export const PAVER_SIZES: Record<string, Record<string, string[]>> = {
  "Techo-Bloc": {
    "Industria": [
      '6"x6"', '8"x8"', '8"x16"', '12"x4"', '12"x6"', '12"x12"', '18"x4"', '18"x6"',
      '18"x12"', '24"x4"', '24"x8"', '24"x12"', '24"x24"', '36"x12"', '36"x24"', '36"x36"',
    ],
    "Blu 60 Smooth": ['6.5"x13"', '13"x13"', '13"x19.5"', 'Blu Grande 19.5"x32.5"'],
    "Blu 60 Slate": ['6.5"x13"', '13"x13"', '13"x19.5"', 'Blu Grande 19.5"x32.5"'],
    "Blu 80 Smooth": ['6.5"x13"', '13"x13"', '13"x19.5"'],
  },
};

// Poured-concrete decking finishes.
export const CONCRETE_FINISHES = ["Broom Finish", "Salt Finish", "Spray Deck", "Stamped"];
// Travertine pavers as LMN carries them: the format is what sets the price.
export const TRAVERTINE_PAVER_FORMATS = ["French Pattern", "12x24", "16x16", "16x24", "24x24"];
export const DECK_PATTERNS = ["Running Bond", "Herringbone", "French Pattern", "Ashlar", "Basketweave"];

/* ---------------- Retaining walls ---------------- */
export const WALL_TYPES = ["SRW (segmental block)", "CMU Block Wall"];
export const SRW_PRODUCTS = ["Belgard Diamond Pro"];
// NEEDS_THOMAS: confirm the exact 4 regional Diamond Pro colors CPW uses.
export const DIAMOND_PRO_COLORS = ["Grey", "Timberline", "Sheffield"];
export const SRW_COPING_PRODUCTS = ["Belgard Universal Coping"];
export const CMU_FINISHES = ["Stucco", "Split-face Travertine", "Stone Veneer", "Brick Veneer"];
export const CMU_COPING_OPTIONS = ["Travertine Coping", "Brick Coping", "Flagstone Coping"];

/* ---------------- Structures (cabana / pavilion) ---------------- */
export const FASCIA_MATERIALS = ["Miratec (painted)", "Cedar / Wood (stained)"];
export const CEILING_MATERIALS = ["Vinyl", "Hardie Board", "TNG (tongue & groove)"];
export const CEILING_FINISHES = ["Painted", "Stained"];
export const POST_WRAPS = ["Miratec wrapped", "Cedar wrapped"];
export const EXTERIOR_WALL_TYPES = ["Brick", "Lap Siding", "Board and Batten", "Cedar Siding"];
export const ROOF_TYPES = ["Asphalt Shingles", "Standing Seam Metal"];
// Truss / gable wood detail. Miratec gets painted, Cedar gets stained.
export const WOOD_DETAIL_MATERIALS = ["Miratec (painted)", "Cedar (stained)"];

/* ---------------- Fire bowls ---------------- */
// Grand Effects fire bowl shapes: Corinthian = square, Essex & Legacy = round.
export const FIREBOWL_MODELS = [
  "Grand Effects Corinthian (square)",
  "Grand Effects Essex (round)",
  "Grand Effects Legacy (round)",
];
export const FIREBOWL_SIZES: Record<string, string[]> = {
  "Grand Effects Corinthian (square)": ['24"', '30"', '36"'],
  "Grand Effects Essex (round)": ['24"', '30"', '36"'],
  "Grand Effects Legacy (round)": ['30"', '36"'],
};
export const FIREBOWL_MATERIALS = ["Premium Concrete (GFRC)", "Copper", "Stainless Steel", "Powder-Coated Metal"];
// Finish/color options keyed by material, so the dropdown is never empty.
// "Hammered Copper" is a copper finish, not a material.
export const FIREBOWL_FINISHES: Record<string, string[]> = {
  "Premium Concrete (GFRC)": ["Natural", "Stone Grey", "Charcoal Grey", "Dark Walnut", "Ebony"],
  "Copper": ["Brushed Copper", "Oil-Rubbed Hammered Copper"],
  "Stainless Steel": ["Stainless Steel"],
  "Powder-Coated Metal": ["Black", "Bronze", "Chestnut Hammertone", "Grey Hammertone"],
};

/* ---------------- Waterline tile — full product lines ---------------- */
// Scraped Sep 2026 from nptpool.com/tile and aquabellatile.com/product-category/tile.
// NPT series with tile sold per SF on pool360 (Nov 13 2026). CPW rarely uses NPT now; anything else goes under Other.
export const NPT_PRODUCTS = [
  "2\" x 2\" Glazed",
  "Akron Field",
  "Aquarela",
  "Aquarius",
  "Atlantis",
  "Aurora",
  "Aventurine",
  "Aztec",
  "Bali",
  "Balistone",
  "Bamboo",
  "Barbados",
  "Barclay",
  "Baroque",
  "Beach Entry",
  "Bermuda",
  "Blend Brick Mix",
  "Blue Seas",
  "BMX Mix",
  "Boardwalk",
  "Borghini",
  "Botanical",
  "Caldera",
  "Catania",
  "Coral",
  "Cortina",
  "Crystal Crest",
  "Discovery Field",
  "Disko Bay",
  "Earthtone Brick",
  "Elements",
  "Ellada",
  "Elysium",
  "Equinox",
  "Escapade",
  "Fiji",
  "Gemstone",
  "Geostone",
  "Glacier Bay",
  "Granito",
  "Hana",
  "Harmony",
  "Iberia",
  "Inaka",
  "Islands",
  "Jubilee",
  "Jules",
  "Key West",
  "Keys",
  "Lantern",
  "Linen",
  "Marblestone",
  "Martinique",
  "Maui",
  "Melody",
  "Meridian",
  "Mermaid",
  "Mini Koyn",
  "Mini Koyn Glass",
  "Mix Mosaic",
  "Moon",
  "Moonbeam",
  "Navajo",
  "Newstone",
  "North Ocean",
  "Oceans",
  "Onyx",
  "Opal",
  "Orion",
  "Oxford",
  "Paradise",
  "Parallax",
  "Pearl",
  "Prism",
  "Purity",
  "Ridgeline",
  "Rushmore",
  "Safari",
  "Sargasso",
  "Scents",
  "Sea Glass",
  "Sea Ice",
  "Seabreeze",
  "Seamist",
  "Seascape",
  "Serpentine",
  "Seven Seas",
  "Sierra Blue Slate",
  "Slate",
  "Soleil",
  "South Seas",
  "Starburst",
  "Street Random",
  "Talavera",
  "Tivoli Stone",
  "Tuxedo",
  "Unglazed",
  "Utopia",
  "Vagli",
  "Veracruz",
  "Verona",
  "Villastone",
  "Volcano",
  "Zanzibar",
];

// Aquabella tile catalog. In-stock SKUs (stock:true) come from CPW's Aquabella
// Atlanta branch stock/pricing sheet; the rest are full-catalog items (special order).
// Shape: product name -> [{ color, size, sku, stock }]. SKU auto-populates on color+size.
export type TileVar = { color: string; size: string; sku: string; stock?: boolean };
export const AQUABELLA_CATALOG: Record<string, TileVar[]> = {
  "Abyss": [{ color: "Atlantis", size: "2x2", sku: "AB9AY221", stock: true }, { color: "Tikal", size: "2x2", sku: "AB9AY224", stock: true }, { color: "Port Royal", size: "6x6", sku: "AB9AY620_N", stock: true }, { color: "Atlantis", size: "6x6", sku: "AB9AY621_N", stock: true }, { color: "Thonis", size: "6x6", sku: "AB9AY622_N", stock: true }, { color: "Alexandria", size: "6x6", sku: "AB9AY623_N", stock: true }, { color: "Tikal", size: "6x6", sku: "AB9AY624_N", stock: true }, { color: "Alexandria", size: "1x2", sku: "AB9AY1223" }, { color: "Atlantis", size: "1x2", sku: "AB9AY1221" }, { color: "Port Royal", size: "1x2", sku: "AB9AY1220" }, { color: "Thonis", size: "1x2", sku: "AB9AY1222" }, { color: "Tikal", size: "1x2", sku: "AB9AY1224" }, { color: "Alexandria", size: "2x2", sku: "AB9AY223" }, { color: "Port Royal", size: "2x2", sku: "AB9AY220" }, { color: "Thonis", size: "2x2", sku: "AB9AY222" }, { color: "Alexandria", size: "6x6-deco", sku: "AB9AY623DECO" }, { color: "Atlantis", size: "6x6-deco", sku: "AB9AY621DECO" }, { color: "Port Royal", size: "6x6-deco", sku: "AB9AY620DECO" }, { color: "Thonis", size: "6x6-deco", sku: "AB9AY622DECO" }, { color: "Tikal", size: "6x6-deco", sku: "AB9AY624DECO" }],
  "Agate": [{ color: "Jasper", size: "6x6", sku: "AB9AGATJASP66", stock: true }, { color: "Jasper", size: "1x2", sku: "AB9AGATJASP12" }, { color: "Larimar", size: "1x2", sku: "AB9AGATLARI12" }, { color: "Larimar", size: "6x6", sku: "AB9AGATLARI66" }],
  "Aloha": [{ color: "Oahu", size: "border-hexagon", sku: "AB8ALOHOAHUBDR" }, { color: "Oahu", size: "full-hexagon", sku: "AB8ALOHOAHUFUL" }, { color: "Maui", size: "border-hexagon", sku: "AB8ALOHMAUIBDR" }, { color: "Maui", size: "full-hexagon", sku: "AB8ALOHMAUIFUL" }, { color: "Kona", size: "border-hexagon", sku: "AB8ALOHKONABDR" }, { color: "Kona", size: "full-hexagon", sku: "AB8ALOHKONAFUL" }],
  "Aqua": [{ color: "Bali", size: "1x1", sku: "AB8AQ1158" }, { color: "Arctic Frost", size: "1x2", sku: "AB8AQ1252" }, { color: "Obsidian", size: "1x2", sku: "AB8AQ1203" }],
  "Aqua - Arctic Frost": [{ color: "", size: "", sku: "AQ-1152" }],
  "Ardesia": [{ color: "Bone", size: "2x2", sku: "A65ARDE22BONEMOS" }, { color: "Bone", size: "6x24", sku: "A65ARDE624BONE" }, { color: "Bone", size: "12x24", sku: "A65ARDE1224BONE" }, { color: "White", size: "2x2", sku: "A65ARDE22WHITMOS" }, { color: "White", size: "6x24", sku: "A65ARDE624WHITE" }, { color: "White", size: "12x24", sku: "A65ARDE1224WHITE" }],
  "Artista": [{ color: "Dali", size: "1x1", sku: "AB1ARTIDALI11" }, { color: "Gaudi", size: "1x1", sku: "AB1ARTIGAUD11" }, { color: "Goya", size: "1x1", sku: "AB1ARTIGOYA11" }, { color: "Picasso", size: "1x1", sku: "AB1ARTIPICA11_N" }, { color: "Raphael", size: "1x1", sku: "AB1ARTIRAPH11" }, { color: "Dali", size: "1x2", sku: "AB1ARTIDALI12" }, { color: "Gaudi", size: "1x2", sku: "AB1ARTIGAUD12" }, { color: "Goya", size: "1x2", sku: "AB1ARTIGOYA12" }, { color: "Picasso", size: "1x2", sku: "AB1ARTIPICA12" }, { color: "Raphael", size: "1x2", sku: "AB1ARTIRAPH12" }, { color: "Dali", size: "2x2", sku: "AB1ARTIDALI22" }, { color: "Gaudi", size: "2x2", sku: "AB1ARTIGAUD22" }, { color: "Goya", size: "2x2", sku: "AB1ARTIGOYA22" }, { color: "Picasso", size: "2x2", sku: "AB1ARTIPICA22" }, { color: "Raphael", size: "2x2", sku: "AB1ARTIRAPH22" }, { color: "Dali", size: "penny-round", sku: "AB1ARTIDALIPR" }, { color: "Gaudi", size: "penny-round", sku: "AB1ARTIGAUDPR" }, { color: "Goya", size: "penny-round", sku: "AB1ARTIGOYAPR" }, { color: "Picasso", size: "penny-round", sku: "AB1ARTIPICAPR" }, { color: "Raphael", size: "penny-round", sku: "AB1ARTIRAPHPR" }],
  "Atlantic": [{ color: "Deepwater", size: "6x6", sku: "AB9ATLADEEP6_N", stock: true }, { color: "Deepwater", size: "1x2", sku: "AB9ATLADEEP12MOS" }, { color: "Inlet", size: "1x2", sku: "AB9ATLAINLE12MOS" }, { color: "Inlet", size: "6x6", sku: "AB9ATLAINLE6_N" }],
  "Aurora Borealis": [{ color: "Crystal", size: "1x2", sku: "AB8AB1210", stock: true }, { color: "Marvel", size: "1x2", sku: "AB8AB1211", stock: true }, { color: "Mystic", size: "1x2", sku: "AB8AB1212", stock: true }, { color: "Magic", size: "1x2", sku: "AB8AB1213", stock: true }, { color: "Radiance", size: "1x1", sku: "AB8AB1126" }, { color: "Radiance", size: "1x2", sku: "AB8AB1226" }, { color: "Crystal", size: "1x1", sku: "AB8AB1110" }, { color: "Magic", size: "1x1", sku: "AB8AB1113" }, { color: "Marvel", size: "1x1", sku: "AB8AB1111" }, { color: "Mystic", size: "1x1", sku: "AB8AB1112" }, { color: "", size: "", sku: "AB-2210" }],
  "Beachfront": [{ color: "Balboa", size: "1x2", sku: "A56BEACBALB12", stock: true }, { color: "Balboa", size: "blend", sku: "A56BEACBALB24", stock: true }, { color: "Santa Monica", size: "1x2", sku: "A56BEACSANT12", stock: true }, { color: "Balboa", size: "3x12", sku: "A56BEACBALB312", stock: true }, { color: "Balboa", size: "6x6", sku: "A56BEACBALB66", stock: true }, { color: "Crystal Cove", size: "3x12", sku: "A56BEACCRYS312", stock: true }, { color: "Crystal Cove", size: "6x6", sku: "A56BEACCRYS66", stock: true }, { color: "Crystal Cove Blen", size: "blend", sku: "A56BEACCRYS24", stock: true }, { color: "Newport", size: "3x12", sku: "A56BEACNEWP312", stock: true }, { color: "Newport", size: "6x6", sku: "A56BEACNEWP66", stock: true }, { color: "Santa Monica", size: "3x12", sku: "A56BEACSANT312", stock: true }, { color: "Santa Monica", size: "6x6", sku: "A56BEACSANT66", stock: true }, { color: "", size: "", sku: "N/A" }],
  "Boardwalk": [{ color: "Drift", size: "6x18", sku: "A30BOARDRIF618" }, { color: "Serene", size: "6x18", sku: "A30BOARSERE618" }, { color: "Soothe", size: "6x18", sku: "A30BOARSOOT618" }, { color: "Drift", size: "6x6", sku: "A30BOARDRIF66" }, { color: "Serene", size: "6x6", sku: "A30BOARSERE66" }, { color: "Soothe", size: "6x6", sku: "A30BOARSOOT66" }],
  "Bora Bora": [{ color: "Coral", size: "1x2", sku: "AB9BB1247", stock: true }, { color: "Marina", size: "6x6", sku: "AB9BB648" }, { color: "", size: "", sku: "BB-1247" }, { color: "", size: "1x2", sku: "AB9BB1246" }, { color: "", size: "6x6", sku: "AB9BB646" }],
  "Britannia": [{ color: "Yorkshire", size: "2x6", sku: "AB0BRITYORK26", stock: true }, { color: "Cathedral", size: "2x6", sku: "AB0BRITCATH26" }, { color: "Dover", size: "2x6", sku: "AB0BRITDOVE26" }, { color: "Stonehenge", size: "2x6", sku: "AB0BRITSTON26" }],
  "Canvas": [{ color: "Deam", size: "", sku: "AB9CANVDEAM6" }, { color: "Masami", size: "", sku: "AB9CANVMASA6" }, { color: "Mishima", size: "", sku: "AB9CANVMISH6" }],
  "Cascade": [{ color: "", size: "", sku: "AB5CS691" }],
  "Cascade - Peak Deco": [{ color: "", size: "", sku: "CS-695 Deco" }],
  "Cascade - Ridge Deco": [{ color: "", size: "", sku: "CS-693 Deco" }],
  "Cascade - Waterfall Deco": [{ color: "", size: "", sku: "CS-692 Deco" }],
  "Castile": [{ color: "Cordoba Blue", size: "6x6", sku: "A30CASTCOBL66" }, { color: "Cordoba Gray", size: "6x6", sku: "A30CASTCOGR66" }, { color: "Madrid Blue", size: "6x6", sku: "A30CASTMABL66" }, { color: "Madrid Gray", size: "6x6", sku: "A30CASTMAGR66" }, { color: "Toledo Blue", size: "6x6", sku: "A30CASTTOBL66" }, { color: "Toledo Gray", size: "6x6", sku: "A30CASTTOGR66" }, { color: "Solidas Bianco", size: "6x6", sku: "A30CASTSOBI66" }, { color: "Solidas Blue", size: "6x6", sku: "A30CASTSOBL66" }, { color: "Solidas Gray", size: "6x6", sku: "A30CASTSOGR66" }],
  "Cayman - Lyon": [{ color: "", size: "", sku: "CAY-148" }],
  "Chateu": [{ color: "Lyon Sky", size: "6x6", sku: "A56CHATLYONSKY66" }, { color: "Lyon Wind", size: "6x6", sku: "A56CHATLYONWIN66" }],
  "Cirrus Azul": [{ color: "", size: "", sku: "AUSCIRRAZUL66" }],
  "Cloud": [{ color: "Lake Blue", size: "3x3", sku: "AUSCLOULAKE33", stock: true }, { color: "Ocean Blue", size: "2x2", sku: "AUSCLOUOCEA22", stock: true }, { color: "Ocean Blue", size: "3x3", sku: "AUSCLOUOCEA33", stock: true }, { color: "Pacific Blue", size: "2x2", sku: "AUSCLOUPACI22", stock: true }, { color: "Pacific Blue", size: "3x3", sku: "AUSCLOUPACI33", stock: true }],
  "Colonial Brick": [{ color: "Williamsburg", size: "1x2", sku: "AB2CBB1WILL1X2", stock: true }, { color: "Jamestown", size: "1x2", sku: "AB2CBB2JAME1X2" }],
  "Colonial Brick Blend - Lexington": [{ color: "", size: "", sku: "CBB-4" }],
  "Constellations": [{ color: "Aquarius", size: "1x1", sku: "AB8CONSAQUA11", stock: true }, { color: "Leo", size: "1x1", sku: "AB8CONSLEO11", stock: true }, { color: "Aries", size: "1x1", sku: "AB8CONSARIE11" }, { color: "Scorpio", size: "1x1", sku: "AB8CONSSCOR11" }, { color: "Virgo", size: "1x1", sku: "AB8CONSVIRG11" }],
  "Crystaline - Surf": [{ color: "", size: "", sku: "CR-430" }],
  "Design": [{ color: "", size: "", sku: "DS-1237" }],
  "Design - Blue Blend": [{ color: "", size: "", sku: "DS-1137" }],
  "Design - Gold": [{ color: "", size: "1x1", sku: "AB8DS1136" }, { color: "", size: "1x2", sku: "AB8DS1236" }],
  "Empire": [{ color: "Inca", size: "6x18", sku: "A30EMPIINCA618", stock: true }, { color: "Mayan", size: "6x18", sku: "A30EMPIMAYA618", stock: true }],
  "Espania": [{ color: "Alicante", size: "1x2", sku: "AB0ESPAALI12" }, { color: "Granada", size: "1x2", sku: "AB0ESPAGRA12" }, { color: "Leon", size: "1x2", sku: "AB0ESPALEO12" }],
  "Espania - Barcelona Block Random": [{ color: "", size: "", sku: "ES-824" }],
  "Espania - Seville Block Random": [{ color: "", size: "", sku: "ES-825" }],
  "Explorer": [{ color: "Columbus", size: "1x2", sku: "AB1EXPLCOLU12" }, { color: "Polo", size: "1x2", sku: "AB1EXPLPOLO12" }, { color: "Magellan", size: "1x2", sku: "AB1EXPLMAGE12" }],
  "Fireglass": [{ color: "Fire 1", size: "1x1", sku: "A20FIRE1X1GLS1" }, { color: "Fire 2", size: "1x1", sku: "A20FIRE1X1GLS2" }, { color: "Fire 3", size: "1x1", sku: "A20FIRE1X1GLS3" }, { color: "Fire 4", size: "1x1", sku: "A20FIRE1X1GLS4" }],
  "Fjord": [{ color: "Majestic", size: "1x2", sku: "AB8FJ1297" }, { color: "Misty", size: "1x2", sku: "AB8FJ1299" }, { color: "Peaceful", size: "1x2", sku: "AB8FJ1293" }, { color: "Silent", size: "1x2", sku: "AB8FJ1298" }],
  "Fjord - Misty": [{ color: "", size: "1x1", sku: "AB8FJ1199" }, { color: "", size: "block-random", sku: "AB8FJ899" }],
  "Fjord - Peaceful": [{ color: "", size: "1x1", sku: "AB8FJ1193" }, { color: "", size: "block-random", sku: "AB8FJ893" }],
  "Fjord - Silent": [{ color: "", size: "1x1", sku: "AB8FJ1198" }, { color: "", size: "block-random", sku: "AB8FJ898" }],
  "Flora": [{ color: "Agave", size: "1x2", sku: "AB0FLORAGAV12" }, { color: "Laurel", size: "1x2", sku: "AB0FLORLAUR12" }, { color: "Periwinkle", size: "1x2", sku: "AB0FLORPERI12" }],
  "Gemstones": [{ color: "Lapis", size: "6x6", sku: "AB9GEMSLAPI66_N", stock: true }, { color: "Turquoise", size: "6x6", sku: "AB9GEMSTURQ66_N", stock: true }, { color: "Lapis", size: "1x2", sku: "AB9GEMSLAPI12" }, { color: "Oyster", size: "1x2", sku: "AB9GEMSOYST12" }, { color: "Turquoise", size: "1x2", sku: "AB9GEMSTURQ12" }, { color: "Oyster", size: "6x6", sku: "AB9GEMSOYST66_N" }],
  "Greek Isles - Crete": [{ color: "", size: "1x2", sku: "AB9GR1262" }, { color: "", size: "6x6", sku: "AB9GR662" }],
  "Harmony": [{ color: "Cobalt Blue", size: "1x1", sku: "AB2HM106", stock: true }, { color: "Cobalt Blue", size: "3x3", sku: "AB2HM306" }],
  "High Seas": [{ color: "Castaway", size: "", sku: "AB9HS642" }, { color: "Treasure", size: "", sku: "AB9HS641" }],
  "Himalaya": [{ color: "Katmandu", size: "1x2", sku: "A53HIMAKATM12", stock: true }, { color: "Tibet", size: "1x2", sku: "A53HIMATIBE12", stock: true }, { color: "Ascent", size: "6x6", sku: "A53HIMAASCE66_N", stock: true }, { color: "Everest", size: "6x6", sku: "A53HIMAEVER66_N", stock: true }, { color: "Katmandu", size: "6x6", sku: "A53HIMAKATM66_N", stock: true }, { color: "Nepal", size: "6x6", sku: "A53HIMANEPA66_N", stock: true }, { color: "Tibet", size: "6x6", sku: "A53HIMATIBE66_N", stock: true }, { color: "Tibet", size: "2x6", sku: "A53HIMATIBE26" }, { color: "Nepal", size: "2x6", sku: "A53HIMANEPA26" }, { color: "Katmandu", size: "2x6", sku: "A53HIMAKATM26" }, { color: "Everest", size: "2x6", sku: "A53HIMAEVER26" }, { color: "Ascent", size: "2x6", sku: "A53HIMAASCE26" }, { color: "Ascent", size: "1x2", sku: "A53HIMAASCE12_N" }, { color: "Everest", size: "1x2", sku: "A53HIMAEVER12_N" }, { color: "Nepal", size: "1x2", sku: "A53HIMANEPA12_N" }],
  "Italian Slate": [{ color: "San Marino", size: "2x2", sku: "AB9IS234", stock: true }, { color: "Milan", size: "2x2", sku: "AB9IS235", stock: true }, { color: "Typhoon Blend", size: "1x2", sku: "AB2TY885", stock: true }, { color: "Typhoon Blend", size: "1x1", sku: "AB2TY984", stock: true }, { color: "San Marino", size: "6x6", sku: "AB9IS634_N", stock: true }, { color: "Milan", size: "6x6", sku: "AB9IS635_N", stock: true }, { color: "Firenze", size: "6x6", sku: "AB9IS638_N", stock: true }, { color: "Dark Pearl", size: "6x24", sku: "AB9SLATDARKLED3D", stock: true }, { color: "Dark Pearl", size: "6x6", sku: "AB9SLATDARK66_N", stock: true }, { color: "Gold Coast", size: "6x24", sku: "AB9SLATGOLDLED3D", stock: true }, { color: "Gold Coast", size: "6x6", sku: "AB9SLATGOLD66_N", stock: true }, { color: "River Bend", size: "6x24", sku: "AB9SLATRIVELED3D", stock: true }, { color: "River Bend", size: "6x6", sku: "AB9SLATRIVE66_N", stock: true }, { color: "Calacatta", size: "6x6", sku: "AB9STONCALA6_N", stock: true }, { color: "Dolomite", size: "6x6", sku: "AB9STONDOLO6_N", stock: true }, { color: "Flint", size: "6x6", sku: "AB9STONFLIN6_N", stock: true }, { color: "Moonstone", size: "6x6", sku: "AB9STONMOON6_N", stock: true }, { color: "Obsidian", size: "6x6", sku: "AB9STONOBSI6_N", stock: true }, { color: "Blue Allure", size: "6x6", sku: "AB9TIMEBLUE6_N", stock: true }, { color: "Firenze", size: "1x2", sku: "AB9IS1238" }, { color: "Naples", size: "1x2", sku: "AB9IS1237" }, { color: "Milan", size: "1x2", sku: "AB9IS1235" }, { color: "San Marino", size: "1x2", sku: "AB9IS1234" }, { color: "Firenze", size: "2x2", sku: "AB9IS238" }, { color: "Naples", size: "6x6", sku: "AB9IS637" }, { color: "Milan", size: "6x6-deco", sku: "AB9IS635DECO" }, { color: "", size: "", sku: "IS-634 Deco" }],
  "Italian Slate 2x2": [{ color: "Naples", size: "", sku: "AB9IS237" }, { color: "San Marino", size: "", sku: "AB9IS234" }],
  "Key West": [{ color: "Catamaran", size: "6x6", sku: "AB9KEYWCATA66", stock: true }, { color: "Martello", size: "6x6", sku: "AB9KEYWMART66", stock: true }, { color: "Catamaran", size: "1x2", sku: "AB9KEYWCATA12" }, { color: "Lighthouse", size: "1x2", sku: "AB9KEYWLIGH12" }, { color: "Martello", size: "1x2", sku: "AB9KEYWMART12" }, { color: "Lighthouse", size: "6x6", sku: "AB9KEYWLIGH66" }],
  "Lakes": [{ color: "Tahoe", size: "1x2", sku: "AB9LAKETAHO12", stock: true }, { color: "Shasta", size: "6x6", sku: "AB9LAKESHAS6_N", stock: true }, { color: "Tahoe", size: "6x6", sku: "AB9LAKETAHO6_N", stock: true }, { color: "Havasu", size: "1x2", sku: "AB9LAKEHAVA12" }, { color: "Shasta", size: "1x2", sku: "AB9LAKESHAS12" }, { color: "Havasu", size: "6x6", sku: "AB9LAKEHAVA6_N" }],
  "Lifestyle": [{ color: "Light Grey", size: "2x18", sku: "A26LIFELIGR218" }, { color: "Seawater", size: "2x18", sku: "A26LIFESEAW218" }, { color: "Turquoise", size: "2x18", sku: "A26LIFETURQ218" }, { color: "White", size: "2x18", sku: "A26LIFEWHIT218" }],
  "London": [{ color: "Ashford", size: "1x1", sku: "AB8LS1172", stock: true }, { color: "Westminster", size: "1x2", sku: "AB8LS1276", stock: true }, { color: "Kensington", size: "1x1", sku: "AB8LS1178" }, { color: "Victoria", size: "1x1", sku: "AB8LS1177" }, { color: "Westminster", size: "1x1", sku: "AB8LS1176" }, { color: "Ashford", size: "1x2", sku: "AB8LS1272" }, { color: "Kensington", size: "1x2", sku: "AB8LS1278" }, { color: "Victoria", size: "1x2", sku: "AB8LS1277" }, { color: "", size: "1x1", sku: "AB8LS1174" }, { color: "", size: "1x2", sku: "AB8LS1274" }, { color: "", size: "", sku: "LS-1275" }],
  "Lunar": [{ color: "Crescent", size: "2x4", sku: "AB8LUNACRES24" }, { color: "Eclipse", size: "2x4", sku: "AB8LUNAECLI24" }, { color: "Gibbous", size: "2x4", sku: "AB8LUNAGIBB24" }],
  "Manhattan": [{ color: "Grand Central", size: "1x2", sku: "A24MANHGRAND12", stock: true }, { color: "Grand Central", size: "2x3", sku: "A24MANHGRAND23", stock: true }, { color: "Times Square", size: "1x2", sku: "A24MANHTIMES12", stock: true }, { color: "Times Square", size: "2x3", sku: "A24MANHTIMES23", stock: true }, { color: "Union Square", size: "1x2", sku: "A24MANHUNION12", stock: true }, { color: "Union Square", size: "2x3", sku: "A24MANHUNION23", stock: true }, { color: "Broadway", size: "1x2", sku: "A24MANHBROAD12" }, { color: "Broadway", size: "2x3", sku: "A24MANHBROAD23" }],
  "Melange": [{ color: "Atlantico", size: "6x6", sku: "A22MELAATLA6", stock: true }, { color: "Indiano", size: "6x6", sku: "A22MELAINDI6", stock: true }, { color: "Blend", size: "1x2", sku: "A22MELABLEN12MO" }],
  "Mineral": [{ color: "Ocean", size: "6x6", sku: "AUSMINEOCEA66" }, { color: "Storm", size: "6x6", sku: "AUSMINESTOR66_N" }, { color: "Sunrise", size: "6x6", sku: "AUSMINESUNR66_N" }],
  "Monet": [{ color: "Paradise", size: "1x2", sku: "AB8MS1284", stock: true }, { color: "Stormy", size: "block", sku: "AB8MS885", stock: true }, { color: "Impression Sunrise", size: "1x2", sku: "AB8MS1280" }, { color: "Water Lilies", size: "1x2", sku: "AB8MS1281" }, { color: "Impression Sunrise", size: "block-random", sku: "AB8MS880" }, { color: "Paradise", size: "block-random", sku: "AB8MS884" }, { color: "Stormy", size: "block-random", sku: "AB8MS885" }, { color: "Water Lilies", size: "block-random", sku: "AB8MS881" }, { color: "", size: "", sku: "MS-1180" }, { color: "", size: "1x1", sku: "AB8MS1186" }, { color: "", size: "block-random", sku: "AB8MS886" }, { color: "", size: "1x2", sku: "AB8MS1282" }],
  "Monticello": [{ color: "Villanova", size: "1x2", sku: "A56MONTVILL12", stock: true }, { color: "Adriano", size: "6x6", sku: "A56MONTADRI66", stock: true }, { color: "Avorio", size: "6x6", sku: "A56MONTAVOR66", stock: true }, { color: "Georgiana", size: "6x6", sku: "A56MONTGEOR66", stock: true }, { color: "Villanova", size: "6x6", sku: "A56MONTVILL66", stock: true }, { color: "Adriano", size: "1x2", sku: "A56MONTADRI12" }, { color: "Avorio", size: "1x2", sku: "A56MONTAVOR12" }, { color: "Georgiana", size: "1x2", sku: "A56MONTGEOR12" }],
  "Mountain Stone": [{ color: "Blue", size: "2x2", sku: "AUSMOUNBLUE22", stock: true }, { color: "Blue/Gray", size: "2x2", sku: "AUSMOUNBLGR22", stock: true }, { color: "Gloss Blue", size: "2x2", sku: "AUSMOUNGLOS22", stock: true }],
  "Mountains": [{ color: "Alps", size: "6x6", sku: "AB9MOUNALPS6_N", stock: true }, { color: "Rockies", size: "6x6", sku: "AB9MOUNROCK66_N", stock: true }, { color: "Alps", size: "1x2", sku: "AB9MOUNALPS12MOS" }, { color: "Rockies", size: "1x2", sku: "AB9MOUNROCK12MOS" }],
  "National Parks": [{ color: "Acadia", size: "16x26", sku: "A90NATIACAD1626" }, { color: "Bryce", size: "16x26", sku: "A90NATIBRYC1626" }, { color: "Crater", size: "16x26", sku: "A90NATICRAT1626" }, { color: "Mammoth", size: "16x26", sku: "A90NATIMAMM1626" }, { color: "Rainier", size: "16x26", sku: "A90NATIRAIN1626" }, { color: "Zion", size: "16x26", sku: "A90NATIZION1626" }],
  "Nevada": [{ color: "Mohave", size: "6x24", sku: "AB9NEVAMOHALED3D", stock: true }, { color: "Mohave", size: "6x6", sku: "AB9NEVAMOHA6_N", stock: true }, { color: "Vegas", size: "6x24", sku: "AB9NEVAVEGALED3D", stock: true }, { color: "Vegas", size: "6x6", sku: "AB9NEVAVEGA66_N", stock: true }, { color: "Mohave", size: "1x2", sku: "AB9NEVAMOHA12" }, { color: "Reno", size: "1x2", sku: "AB9NEVARENO12" }, { color: "Vegas", size: "1x2", sku: "AB9NEVAVEGA12" }, { color: "Reno", size: "6x6", sku: "AB9NEVARENO6_N" }, { color: "", size: "1x2", sku: "AB9NEVACARS12" }, { color: "", size: "6x6", sku: "AB9NEVACARS6_N" }],
  "Night Life": [{ color: "Ballad", size: "1x2", sku: "AB8NL1231", stock: true }, { color: "Soul", size: "1x2", sku: "AB8NL1234", stock: true }, { color: "Ballad", size: "1x1", sku: "AB8NL1131" }, { color: "Gallant", size: "1x1", sku: "AB8NL1132" }, { color: "Melody", size: "1x1", sku: "AB8NL1138" }, { color: "Soul", size: "1x1", sku: "AB8NL1134" }, { color: "Gallant", size: "1x2", sku: "AB8NL1232" }, { color: "Melody", size: "1x2", sku: "AB8NL1238" }, { color: "Ballad", size: "block-random", sku: "AB8NL831" }, { color: "Gallant", size: "block-random", sku: "AB8NL832" }, { color: "Melody", size: "block-random", sku: "AB8NL838" }, { color: "Soul", size: "block-random", sku: "AB8NL834" }],
  "North Seas": [{ color: "Adriatic", size: "1x2", sku: "AB8NS1219" }, { color: "Arctic", size: "1x2", sku: "AB8NS1225" }, { color: "Baltic", size: "1x2", sku: "AB8NS1217" }, { color: "Caspian", size: "1x2", sku: "AB8NS1213" }, { color: "Celtic", size: "1x2", sku: "AB8NS1216" }, { color: "Denmark", size: "1x2", sku: "AB8NS1220" }, { color: "Iceland", size: "1x2", sku: "AB8NS1212" }, { color: "Icelandic", size: "1x2", sku: "AB8NS1218" }, { color: "Irish", size: "1x2", sku: "AB8NS1215" }, { color: "Norwegian", size: "1x2", sku: "AB8NS1214" }, { color: "Polar", size: "1x2", sku: "AB8NS1210" }],
  "North Seas - Baltic": [{ color: "", size: "1x1", sku: "AB8NS117" }, { color: "", size: "block-random", sku: "AB8NS817" }],
  "North Seas - Celtic 1″x1″": [{ color: "", size: "", sku: "NS-116" }],
  "North Seas - Greenland  1″x1″": [{ color: "", size: "", sku: "NS-111" }],
  "North Seas - Icelandic": [{ color: "", size: "", sku: "NS-118" }],
  "North Seas - Irish  1″x1″": [{ color: "", size: "", sku: "NS-115" }],
  "North Seas - Norwegian  1″x1″": [{ color: "", size: "", sku: "NS-114" }],
  "North Seas - Polar  1″x1″": [{ color: "", size: "", sku: "NS-110" }],
  "Oasis": [{ color: "Calm", size: "6x6", sku: "A30OA650" }, { color: "Mountain Stream", size: "6x6", sku: "A30OA750" }, { color: "Tranquil", size: "6x6", sku: "A30OA450" }],
  "Oasis - Blue": [{ color: "", size: "", sku: "OA-60" }],
  "Oasis - Grigio Deco": [{ color: "", size: "", sku: "OA-30 Deco" }],
  "Oasis - Marine": [{ color: "", size: "", sku: "OA-44" }],
  "Ocean Breeze": [{ color: "Windstream", size: "1x1", sku: "AB2OB150", stock: true }, { color: "Seascape", size: "1x1", sku: "AB2OB151", stock: true }, { color: "Windstream", size: "3x3", sku: "AB2OB350", stock: true }, { color: "Windstream", size: "1x2", sku: "AB2OB550", stock: true }, { color: "Seascape", size: "1x2", sku: "AB2OB551", stock: true }, { color: "Windstrm", size: "akron", sku: "AB2OB750", stock: true }, { color: "Seascape", size: "akron", sku: "AB2OB751", stock: true }, { color: "Ocean Brz Blend", size: "1x2", sku: "AB2OB801", stock: true }, { color: "Ocean Brz Blend", size: "1x1", sku: "AB2OB900", stock: true }, { color: "Ocean Breeze Blend", size: "1x1", sku: "AB2OB900" }, { color: "Ocean Breeze Blend", size: "1x2", sku: "AB2OB801" }, { color: "Seascape", size: "3x3", sku: "AB2OB351" }, { color: "Seascape", size: "akron-deco", sku: "AB2OB751" }, { color: "Windstream", size: "akron-deco", sku: "AB2OB750" }, { color: "", size: "", sku: "OB-354" }],
  "Odyssey": [{ color: "Sparta", size: "1x2", sku: "AB8OD141", stock: true }, { color: "Rhodes", size: "1x2", sku: "AB8OD145", stock: true }, { color: "Sparta", size: "2x4", sku: "AB8OD2441", stock: true }, { color: "Rhodes", size: "2x4", sku: "AB8OD2445", stock: true }, { color: "Athens", size: "1x2", sku: "AB8OD140" }, { color: "Naxos", size: "1x2", sku: "AB8OD144" }, { color: "Athens", size: "2x4", sku: "AB8OD2440" }, { color: "Naxos", size: "2x4", sku: "AB8OD2444" }],
  "Olympus": [{ color: "Adonis", size: "1x2", sku: "A28OLYMADON12", stock: true }, { color: "Adonis", size: "3x6", sku: "A28OLYMADON36", stock: true }, { color: "Apollo", size: "1x2", sku: "A28OLYMAPOL12", stock: true }, { color: "Ares", size: "1x2", sku: "A28OLYMARES12", stock: true }, { color: "Athena", size: "1x2", sku: "A28OLYMATHE12", stock: true }, { color: "Poseidon", size: "1x2", sku: "A28OLYMPOSE12", stock: true }, { color: "Triton", size: "3x6", sku: "A28OLYMTRIT36", stock: true }, { color: "Ares", size: "3x6", sku: "A28OLYMARES36", stock: true }, { color: "Poseidon", size: "3x6", sku: "A28OLYMPOSE36", stock: true }],
  "Paradise": [{ color: "Eden", size: "", sku: "AB8PS2366" }, { color: "Divine", size: "", sku: "AB8PS2367" }, { color: "Heaven", size: "", sku: "AB8PS2365" }],
  "Pebble Beach - Cabo Verde": [{ color: "", size: "", sku: "PB-1780" }],
  "Pebble Beach - Newport Blue": [{ color: "", size: "", sku: "PB-1775" }],
  "Pebble Beach - Pebble Beach": [{ color: "", size: "", sku: "PB-1785" }],
  "Pinnacle": [{ color: "Denali", size: "6x6", sku: "A56PINNDENA66", stock: true }, { color: "Teton", size: "6x6", sku: "A56PINNTETO66", stock: true }, { color: "Denali", size: "1x2", sku: "A56PINNDENA12" }, { color: "Teton", size: "1x2", sku: "A56PINNTETO12" }],
  "Pool Gems - Onyx Blend": [{ color: "", size: "", sku: "PG-116s" }],
  "Pool Gems - Sedona Blend": [{ color: "", size: "1x1", sku: "AB8PG118" }, { color: "", size: "1x2", sku: "AB8PG128" }],
  "Quantum": [{ color: "Nova", size: "6x6", sku: "AB9QUANNOVA66" }, { color: "Prism", size: "6x6", sku: "AB9QUANPRIS66" }, { color: "Vector", size: "6x6", sku: "AB9QUANVECT66" }],
  "Rivers": [{ color: "Yukon", size: "1x2", sku: "AB9RIVEYUKO12MOS", stock: true }, { color: "Delaware", size: "6x6", sku: "AB9RIVEDELA6_N", stock: true }, { color: "Yukon", size: "6x6", sku: "AB9RIVEYUKO6_N", stock: true }, { color: "Delaware", size: "1x2", sku: "AB9RIVEDELA12MOS" }],
  "Riviera": [{ color: "Lorenzo", size: "2x4", sku: "AB8RV2431", stock: true }, { color: "Andora", size: "2x4", sku: "AB8RV2432" }, { color: "Finale", size: "2x4", sku: "AB8RV2434" }, { color: "Levanto", size: "2x4", sku: "AB8RV2433" }, { color: "Monaco", size: "2x4", sku: "AB8RV2428" }, { color: "San Remo", size: "2x4", sku: "AB8RV2430" }, { color: "", size: "", sku: "RV-2427" }],
  "Rustic Brick": [{ color: "Beige", size: "", sku: "A26RUSTBEI210" }, { color: "Grey", size: "", sku: "A26RUSTGRE210" }, { color: "Mud", size: "", sku: "A26RUSTMUD210" }, { color: "Old Red", size: "", sku: "A26RUSTOLDRED210" }, { color: "White", size: "", sku: "A26RUSTWHI210" }],
  "Shimmer": [{ color: "Bermuda Blend", size: "1x1", sku: "AB8SH1191" }, { color: "Aquamarine Blend", size: "1x1", sku: "AB8SH1194" }, { color: "Bermuda Blend", size: "1x2", sku: "AB8SH1291" }, { color: "Aquamarine Blend", size: "1x2", sku: "AB8SH1294" }, { color: "Bermuda Blend", size: "block-random", sku: "AB8SH891" }, { color: "Aquamarine Blend", size: "block-random", sku: "AB8SH894" }],
  "Shimmer - Antigua Blend": [{ color: "", size: "1x1", sku: "AB8SH1190" }, { color: "", size: "1x2", sku: "AB8SH1290" }],
  "Shimmer - Light Brown": [{ color: "", size: "1x1", sku: "AB8SH1195" }, { color: "", size: "1x2", sku: "AB8SH1295" }, { color: "", size: "block-random", sku: "AB8SH895" }],
  "Slate": [{ color: "Dark Pearl", size: "1x2", sku: "AB9SLATDARK12" }, { color: "Gold Coast", size: "1x2", sku: "AB9SLATGOLD12" }, { color: "River Bend", size: "1x2", sku: "AB9SLATRIVE12" }, { color: "Dark Pearl", size: "6x6", sku: "AB9SLATDARK66_N" }, { color: "Gold Coast", size: "6x6", sku: "AB9SLATGOLD66_N" }, { color: "River Bend", size: "6x6", sku: "AB9SLATRIVE66_N" }, { color: "Dark Pearl", size: "6x24", sku: "AB9SLATDARKLED3D" }, { color: "Gold Coast", size: "6x24", sku: "AB9SLATGOLDLED3D" }, { color: "River Bend", size: "6x24", sku: "AB9SLATRIVELED3D" }],
  "Solid": [{ color: "Black", size: "6x6", sku: "A15SOLIDBLACK6" }, { color: "Cobalt", size: "6x6", sku: "A15SOLIDCOBALT6" }, { color: "Light Blue", size: "6x6", sku: "A15SOLIDLBLUE6" }, { color: "Mercedes Blue", size: "6x6", sku: "A15SOLIDMERC6_N" }, { color: "Navy", size: "6x6", sku: "A15SOLIDNAVY6_N" }, { color: "White", size: "6x6", sku: "A15SOLIDWHITE6_N" }],
  "South Pacific": [{ color: "Tonga", size: "1x2", sku: "A35SOUTTONG12", stock: true }, { color: "Mariana", size: "1x2", sku: "A35SOUTMARI12" }],
  "Southern Isles - Mix 1": [{ color: "", size: "1x1", sku: "AB8SIS1101" }, { color: "", size: "1x2", sku: "AB8SIS1201" }],
  "Southern Isles - Mix 6": [{ color: "", size: "1x1", sku: "AB8SIS1106" }, { color: "", size: "1x2", sku: "AB8SIS1206" }],
  "Starlight": [{ color: "Asteroid", size: "1-5x4-0", sku: "AB8STARASTE154" }, { color: "Nebula", size: "1-5x4-0", sku: "AB8STARNEBU154" }, { color: "Stellar", size: "1-5x4-0", sku: "AB8STARSTEL154" }],
  "Stars": [{ color: "Gemini", size: "6x6", sku: "AB9STARGEMI6_N", stock: true }, { color: "Orion", size: "6x6", sku: "AB9STARORIO6_N", stock: true }, { color: "Polaris", size: "6x6", sku: "AB9STARPOLA6_N", stock: true }, { color: "Gemini", size: "1x2", sku: "AB9STARGEMI12MOS" }, { color: "Orion", size: "1x2", sku: "AB9STARORIO12MOS" }, { color: "Polaris", size: "1x2", sku: "AB9STARPOLA12MOS" }],
  "Stone Age": [{ color: "Dolomite", size: "6x24", sku: "AB9STONDOLO624", stock: true }, { color: "Flint", size: "6x24", sku: "AB9STONFLIN624", stock: true }, { color: "Moonstone", size: "6x24", sku: "AB9STONMOON624", stock: true }, { color: "Calacatta", size: "1x2", sku: "AB9STONCALA12" }, { color: "Blend Straight Joint", size: "1x2", sku: "AB9STON12MOSSTR" }, { color: "Blend Broken Joint", size: "1x2", sku: "AB9STON12MOSBROK" }, { color: "Calacatta", size: "12x24", sku: "AB9STONCALA1224" }, { color: "Dolomite", size: "12x24", sku: "AB9STONDOLO1224" }, { color: "Flint", size: "12x24", sku: "AB9STONFLIN1224" }, { color: "Moonstone", size: "12x24", sku: "AB9STONMOON1224" }, { color: "Calacatta", size: "6x24", sku: "AB9STONCALA624" }, { color: "Obsidian", size: "12x24", sku: "AB9STONOBSI1224" }, { color: "Obsidian", size: "6x24", sku: "AB9STONOBSI624" }, { color: "Flint", size: "6x6", sku: "AB9STONFLIN6_N" }, { color: "Moonstone", size: "6x6", sku: "AB9STONMOON6_N" }, { color: "Calacatta", size: "6x6", sku: "AB9STONCALA6_N" }, { color: "Dolomite", size: "6x6", sku: "AB9STONDOLO6_N" }, { color: "Obsidian", size: "6x6", sku: "AB9STONOBSI6_N" }],
  "Stratos": [{ color: "Vein Bone", size: "2x2", sku: "A65STRAWHIT22" }, { color: "Vein White", size: "2x2", sku: "A65STRABONE22" }, { color: "Vein Bone", size: "6x24", sku: "A65STRABONE624" }, { color: "Vein White", size: "6x24", sku: "A65STRAWHIT624" }, { color: "Vein White", size: "12x24", sku: "A65STRAWHIT1224" }, { color: "Vein Bone", size: "12x24", sku: "A65STRABONE1224" }, { color: "Vein Bone", size: "24x48-relief-tile", sku: "A65STRABONE2448" }, { color: "Vein White", size: "24x48-relief-tile", sku: "A65STRAWHIT2448" }],
  "Summit": [{ color: "Horizon", size: "6x18", sku: "A30SUMMHORI618", stock: true }, { color: "Ridge", size: "6x18", sku: "A30SUMMRIDG618", stock: true }, { color: "Snowcap", size: "6x18", sku: "A30SUMMSNOW618", stock: true }],
  "Sunny Day - Bluff Deco": [{ color: "", size: "", sku: "SD-674 Deco" }],
  "Sunny Day - Sandy Beach": [{ color: "", size: "", sku: "SD-670 Deco-1" }],
  "Sunny Day - Sea Wind Deco": [{ color: "", size: "", sku: "SD-671 Deco" }],
  "Sunny Day - Stratus": [{ color: "", size: "6x18", sku: "A30SD67618" }],
  "Sunny Day - Surf Spray Deco": [{ color: "", size: "", sku: "SD-670 Deco" }],
  "Terra Aqua - Glicine": [{ color: "", size: "6x6", sku: "AB7TAQUGLIC6" }, { color: "", size: "6x6-deco", sku: "AB7TAQUGLICDEC" }],
  "Terrain - Peak": [{ color: "", size: "2x2", sku: "AB8TR263" }, { color: "", size: "3x3", sku: "AB8TR363" }],
  "Terrain - Ridge": [{ color: "", size: "2x2", sku: "AB8TR262" }, { color: "", size: "3x3", sku: "AB8TR362" }],
  "Terrain - Valley": [{ color: "", size: "2x2", sku: "AB8TR261" }, { color: "", size: "3x3", sku: "AB8TR361" }],
  "Texas": [{ color: "Laredo", size: "1x2", sku: "AB9TEXALARE12MOS", stock: true }, { color: "Frisco", size: "6x6", sku: "AB9TEXAFRIS6", stock: true }, { color: "Laredo", size: "6x6", sku: "AB9TEXALARE6_N", stock: true }, { color: "Frisco", size: "1x2", sku: "AB9TEXAFRIS12MOS" }],
  "Tidal Wave": [{ color: "Rip Curl", size: "3x3", sku: "AB8TW3390" }, { color: "Swell", size: "3x3", sku: "AB8TW3392" }],
  "Timeless": [{ color: "Adventure", size: "6x6", sku: "AB9TIMEADVE6_N", stock: true }, { color: "Adventure", size: "1x2", sku: "AB9TIMEADVE12MOS" }, { color: "Blue Allure", size: "1x2", sku: "AB9TIMEBLUE12MOS" }, { color: "Blue Allure", size: "6x6", sku: "AB9TIMEBLUE6_N" }],
  "Travertino": [{ color: "Fontano", size: "1x2", sku: "AB9TRAVFONT12" }, { color: "Giuliano", size: "1x2", sku: "AB9TRAVGIUL12" }, { color: "Fontano", size: "6x6", sku: "AB9TRAVFONT66" }],
  "Travertino - Bellavista": [{ color: "", size: "1x2", sku: "AB9TRAVBELL12" }, { color: "", size: "6x6", sku: "AB9TRAVBELL66" }],
  "Tropic Isle": [{ color: "Aruba", size: "6x6", sku: "AUSTROPARUB66" }, { color: "Barbados", size: "6x6", sku: "AUSTROPBARB66_N" }],
  "Tuscany - Pisa": [{ color: "", size: "", sku: "TC-251" }],
  "Tuscany - Siena": [{ color: "", size: "", sku: "TC-652 Deco" }],
  "Typhoon": [{ color: "Fiji", size: "1x1", sku: "AB2TY180", stock: true }, { color: "Bali", size: "1x1", sku: "AB2TY181", stock: true }, { color: "Samoa", size: "1x1", sku: "AB2TY182", stock: true }, { color: "Samoa", size: "3x3", sku: "AB2TY382", stock: true }, { color: "Fiji", size: "1x2", sku: "AB2TY580", stock: true }, { color: "Bali", size: "1x2", sku: "AB2TY581", stock: true }, { color: "Samoa", size: "1x2", sku: "AB2TY582", stock: true }, { color: "Fiji", size: "akron", sku: "AB2TY780", stock: true }, { color: "Samoa", size: "akron", sku: "AB2TY782", stock: true }, { color: "Blend", size: "1x1", sku: "AB2TY984" }, { color: "Blend", size: "1x2", sku: "AB2TY885" }, { color: "Bali", size: "3x3", sku: "AB2TY381" }, { color: "Fiji", size: "3x3", sku: "AB2TY380" }, { color: "Fiji", size: "akron-deco", sku: "AB2TY780" }, { color: "Samoa", size: "akron-deco", sku: "AB2TY782" }],
  "Unglazed": [{ color: "Arctic White", size: "1x1", sku: "A25UNGLWHIT11" }, { color: "Black", size: "1x1", sku: "A25UNGLBLAC11" }, { color: "Cobalt Blue", size: "1x1", sku: "A25UNGLCOBA11" }, { color: "Arctic White", size: "2x2", sku: "A25UNGLWHIT22" }, { color: "Black", size: "2x2", sku: "A25UNGLBLAC22" }, { color: "Cobalt Blue", size: "2x2", sku: "AB8UG400" }],
  "USPT": [{ color: "Black", size: "3x3", sku: "AUSUSPTBLAC33", stock: true }, { color: "Blue", size: "3x3", sku: "AUSUSPTBLUE33", stock: true }, { color: "Caribbean Blue", size: "2x2", sku: "AUSUSPTCARI22", stock: true }, { color: "Caribbean Blue", size: "3x3", sku: "AUSUSPTCARI33", stock: true }, { color: "Cobalt Blue", size: "2x2", sku: "AUSUSPTCOBA22", stock: true }, { color: "Cobalt Blue", size: "3x3", sku: "AUSUSPTCOBA33", stock: true }],
  "Valley - Blue China Deco": [{ color: "", size: "", sku: "VA-633 Deco" }],
  "Valley - Peacock": [{ color: "", size: "", sku: "VA-636" }],
  "Venetian": [{ color: "Realto", size: "1x2", sku: "AB9VENEREAL12MOS", stock: true }, { color: "Realto", size: "6x6", sku: "AB9VENEREAL6_N", stock: true }, { color: "Murano", size: "1x2", sku: "AB9VENEMURA12MOS" }, { color: "Murano", size: "6x6", sku: "AB9VENEMURA6_N" }],
  "Vincen": [{ color: "White", size: "2x2", sku: "A65VINCWHIT22" }, { color: "Bone", size: "2x2", sku: "A65VINCBONE22" }, { color: "Bone", size: "6x24", sku: "A65VINC624BONE" }, { color: "Bone", size: "12x24", sku: "A65VINC1224BONE" }, { color: "White", size: "6x24", sku: "A65VINC624WHITE" }, { color: "White", size: "12x24", sku: "A65VINC1224WHITE" }],
  "Voyage": [{ color: "Anchor", size: "2x4", sku: "AB2VG2440", stock: true }, { color: "Narrows", size: "2x4", sku: "AB2VG2446", stock: true }, { color: "Reef", size: "2x4", sku: "AB2VG2448", stock: true }, { color: "Anchor", size: "1x2", sku: "AB2VG840", stock: true }, { color: "Narrows", size: "1x2", sku: "AB2VG846", stock: true }, { color: "Anchor", size: "1x1", sku: "AB2VG940", stock: true }, { color: "Narrows", size: "1x1", sku: "AB2VG946", stock: true }, { color: "Reef", size: "1x1", sku: "AB2VG948", stock: true }, { color: "Reef", size: "1x2", sku: "AB2VG848" }],
  "Windjammer": [{ color: "Lookout", size: "1x2", sku: "AB9WINDLOOK12" }, { color: "Lookout", size: "6x6", sku: "AB9WINDLOOK6" }],
};

// All selectable Aquabella product names.
export const AQUABELLA_PRODUCTS: string[] = [
  "Abyss", "Agate", "Aloha", "Aqua", "Aqua - Arctic Frost", "Ardesia", "Artista", "Atlantic", "Aurora Borealis", "Beachfront", "Boardwalk", "Bora Bora", "Britannia", "Canvas", "Cascade", "Cascade - Peak Deco", "Cascade - Ridge Deco", "Cascade - Waterfall Deco", "Castile", "Cayman - Lyon", "Chateu", "Cirrus Azul", "Cloud", "Colonial Brick", "Colonial Brick Blend - Lexington", "Constellations", "Crystaline - Surf", "Design", "Design - Blue Blend", "Design - Gold", "Empire", "Espania", "Espania - Barcelona Block Random", "Espania - Seville Block Random", "Explorer", "Fireglass", "Fjord", "Fjord - Misty", "Fjord - Peaceful", "Fjord - Silent", "Flora", "Gemstones", "Greek Isles - Crete", "Harmony", "High Seas", "Himalaya", "Italian Slate", "Italian Slate 2x2", "Key West", "Lakes", "Lifestyle", "London", "Lunar", "Manhattan", "Melange", "Mineral", "Monet", "Monticello", "Mountain Stone", "Mountains", "National Parks", "Nevada", "Night Life", "North Seas", "North Seas - Baltic", "North Seas - Celtic 1″x1″", "North Seas - Greenland  1″x1″", "North Seas - Icelandic", "North Seas - Irish  1″x1″", "North Seas - Norwegian  1″x1″", "North Seas - Polar  1″x1″", "Oasis", "Oasis - Blue", "Oasis - Grigio Deco", "Oasis - Marine", "Ocean Breeze", "Odyssey", "Olympus", "Paradise", "Pebble Beach - Cabo Verde", "Pebble Beach - Newport Blue", "Pebble Beach - Pebble Beach", "Pinnacle", "Pool Gems - Onyx Blend", "Pool Gems - Sedona Blend", "Quantum", "Rivers", "Riviera", "Rustic Brick", "Shimmer", "Shimmer - Antigua Blend", "Shimmer - Light Brown", "Slate", "Solid", "South Pacific", "Southern Isles - Mix 1", "Southern Isles - Mix 6", "Starlight", "Stars", "Stone Age", "Stratos", "Summit", "Sunny Day - Bluff Deco", "Sunny Day - Sandy Beach", "Sunny Day - Sea Wind Deco", "Sunny Day - Stratus", "Sunny Day - Surf Spray Deco", "Terra Aqua - Glicine", "Terrain - Peak", "Terrain - Ridge", "Terrain - Valley", "Texas", "Tidal Wave", "Timeless", "Travertino", "Travertino - Bellavista", "Tropic Isle", "Tuscany - Pisa", "Tuscany - Siena", "Typhoon", "Unglazed", "USPT", "Valley - Blue China Deco", "Valley - Peacock", "Venetian", "Vincen", "Voyage", "Windjammer"
];

/* NPT tile by series, color and size, from pool360 (Nov 13 2026). No prices here: Claire's price sheet carries those. */
export const NPT_CATALOG: Record<string, TileVar[]> = {
  "2\" x 2\" Glazed": [{ color: "Blue", size: "2x2", sku: "PTK-37-9626" }, { color: "Cobalt", size: "2x2", sku: "PTK-37-9605" }, { color: "Electric Blue", size: "2x2", sku: "PTK-37-9627" }, { color: "Lake Blue", size: "2x2", sku: "PTK-37-9607" }],
  "Akron Field": [{ color: "Cloud Olive Blue", size: "3x3", sku: "CEK-37-9675" }, { color: "Royal Blue", size: "3x3", sku: "CEK-37-9665" }],
  "Aquarela": [{ color: "Teal", size: "6x18", sku: "REA-37-7050" }, { color: "Turquoise", size: "6x18", sku: "REA-37-7051" }, { color: "White", size: "6x18", sku: "REA-37-7052" }],
  "Aquarius": [{ color: "Candy", size: "1x1", sku: "OCG-37-0258" }, { color: "Candy", size: "1x2", sku: "OCG-37-0259" }, { color: "Mica", size: "1x2", sku: "OCG-37-0251" }, { color: "Mica Blue", size: "1x1", sku: "OCG-37-0250" }, { color: "Olympic", size: "1x1", sku: "OCG-37-0254" }, { color: "Olympic", size: "1x2", sku: "OCG-37-0255" }, { color: "Royal", size: "1x1", sku: "OCG-37-0252" }, { color: "Royal", size: "1x2", sku: "OCG-37-0253" }, { color: "Steel", size: "1x1", sku: "OCG-37-0256" }, { color: "Steel", size: "1x2", sku: "OCG-37-0257" }],
  "Atlantis": [{ color: "Blue", size: "6x6", sku: "DCR-37-0122" }, { color: "Teal", size: "6x6", sku: "DCR-37-0120" }],
  "Aurora": [{ color: "Cobalt", size: "1x1", sku: "OCG-37-0321" }, { color: "Cobalt", size: "6x6", sku: "OCG-37-0324" }, { color: "Navy", size: "1x1", sku: "OCG-37-0322" }, { color: "Navy", size: "6x6", sku: "OCG-37-0325" }, { color: "White", size: "1x1", sku: "OCG-37-0320" }, { color: "White", size: "6x6", sku: "OCG-37-0323" }],
  "Aventurine": [{ color: "Blue", size: "1x1", sku: "OCG-37-0301" }, { color: "Blue", size: "1x2", sku: "OCG-37-0303" }, { color: "Teal", size: "1x1", sku: "OCG-37-0300" }, { color: "Teal", size: "1x2", sku: "OCG-37-0302" }],
  "Aztec": [{ color: "Cobalt", size: "6x6", sku: "MCY-37-5115" }],
  "BMX Mix": [{ color: "Blonde Mix", size: "1x1", sku: "CEK-37-9247" }, { color: "Blonde Mix", size: "3x3", sku: "CEK-37-9249" }, { color: "Blue", size: "3x3", sku: "CEK-37-9379" }, { color: "Blue Mix", size: "1x1", sku: "CEK-37-9248" }],
  "Bali": [{ color: "Graystone", size: "1x2", sku: "TGU-37-1052" }, { color: "Graystone", size: "3x3", sku: "TGU-37-1053" }, { color: "Turquoise", size: "1x2", sku: "TGU-37-1050" }, { color: "Turquoise", size: "3x3", sku: "TGU-37-1051" }],
  "Balistone": [{ color: "Celadon", size: "1.25x1.25", sku: "ISA-37-1061" }, { color: "Celadon", size: "4x4", sku: "ISA-37-1062" }, { color: "Celadon", size: "6x12", sku: "ISA-37-1063" }],
  "Bamboo": [{ color: "Random Aqua Marine", size: "", sku: "CEK-37-9203" }, { color: "Random Atlantic Blue", size: "", sku: "CEK-37-9201" }, { color: "Random Cloud Blue", size: "", sku: "CEK-37-9200" }, { color: "Random Twilight Gray", size: "", sku: "CEK-37-9202" }],
  "Barbados": [{ color: "Aqua", size: "2x2", sku: "CRZ-37-9201" }, { color: "Aqua", size: "6x6", sku: "CRZ-37-9264" }, { color: "Cobalto", size: "2x2", sku: "CRZ-37-9203" }, { color: "Cobalto", size: "6x6", sku: "CRZ-37-9265" }, { color: "Silver", size: "6x6", sku: "CRZ-37-9204" }, { color: "Terra", size: "6x6", sku: "CRZ-37-9207" }],
  "Barclay": [{ color: "Blue Gray", size: "1x2", sku: "GMI-37-0245" }, { color: "Blue Gray", size: "6x6", sku: "GMI-37-0242" }, { color: "Light Gray", size: "1x2", sku: "GMI-37-0244" }, { color: "Light Gray", size: "6x6", sku: "GMI-37-0241" }, { color: "Teal Green", size: "1x2", sku: "GMI-37-0243" }, { color: "Teal Green", size: "6x6", sku: "GMI-37-0240" }],
  "Baroque": [{ color: "Blue", size: "1x1", sku: "CEK-37-9204" }, { color: "Blue", size: "1x2", sku: "CEK-37-9207" }, { color: "Blue", size: "6x6", sku: "CEK-37-9210" }, { color: "Dark Blue", size: "1x1", sku: "CEK-37-9205" }, { color: "Dark Blue", size: "1x2", sku: "CEK-37-9208" }, { color: "Dark Blue", size: "6x6", sku: "CEK-37-9211" }, { color: "Turquoise", size: "1x1", sku: "CEK-37-9206" }, { color: "Turquoise", size: "1x2", sku: "CEK-37-9209" }, { color: "Turquoise", size: "6x6", sku: "CEK-37-9212" }],
  "Beach Entry": [{ color: "Sand Round", size: "1x1", sku: "VOM-37-5030" }, { color: "White Marble Round", size: "1x1", sku: "VOM-37-5032" }],
  "Bermuda": [{ color: "Bermuda Blue", size: "6x6", sku: "GMI-37-0055" }],
  "Blend Brick Mix": [{ color: "Standard", size: "3x3", sku: "CEK-37-9243" }],
  "Blue Seas": [{ color: "Light Blue", size: "6x6", sku: "GMI-37-0020" }, { color: "Royal Blue", size: "6x6", sku: "GMI-37-0021" }, { color: "Teal", size: "6x6", sku: "GMI-37-0022" }],
  "Boardwalk": [{ color: "Ocean \" x \"", size: "", sku: "GMI-37-0183" }],
  "Borghini": [{ color: "Blue", size: "2x3", sku: "MBA-37-2081" }, { color: "Turquoise", size: "2x3", sku: "MBA-37-2082" }, { color: "White", size: "2x3", sku: "MBA-37-2080" }],
  "Botanical": [{ color: "Lake Blue", size: "6x6", sku: "PTK-37-9603" }, { color: "Sky Blue", size: "6x6", sku: "PTK-37-9600" }],
  "Caldera": [{ color: "Blue Agate", size: "6x6", sku: "PTK-37-9751" }],
  "Catania": [{ color: "Ocean", size: "6x6", sku: "PTL-37-9700" }],
  "Coral": [{ color: "Rustic", size: "2x2", sku: "GMI-37-0162" }, { color: "Rustic", size: "6x6", sku: "GMI-37-0058" }, { color: "Teal", size: "6x6", sku: "GMI-37-0060" }],
  "Cortina": [{ color: "Champagne Beige", size: "6x6", sku: "PTL-37-9786" }, { color: "Curacao Blue", size: "6x6", sku: "PTL-37-9784" }],
  "Crystal Crest": [{ color: "Emerald", size: "1x2", sku: "GMI-37-0225" }, { color: "Emerald", size: "6x6", sku: "GMI-37-0222" }, { color: "Light Blue", size: "1x2", sku: "GMI-37-0224" }, { color: "Light Blue", size: "6x6", sku: "GMI-37-0221" }, { color: "Navy", size: "1x2", sku: "GMI-37-0223" }, { color: "Navy", size: "6x6", sku: "GMI-37-0220" }],
  "Discovery Field": [{ color: "Basic Black", size: "3x3", sku: "CPT-37-9006" }, { color: "Basic Caribbean Blue", size: "3x3", sku: "CPT-37-9005" }, { color: "Basic Cobalt Blue", size: "3x3", sku: "CPT-37-9002" }, { color: "Blue", size: "3x3", sku: "CPT-37-9001" }, { color: "Marine Green", size: "3x3", sku: "CPT-37-9003" }, { color: "Teal Gree", size: "3x3", sku: "CPT-37-9004" }, { color: "Terra Blue", size: "3x3", sku: "CPT-37-9000" }],
  "Disko Bay": [{ color: "Cyan Bay , 13SQF/CS", size: "6x6", sku: "CPT-37-9127" }, { color: "Iceberg White , 13SQF/CS", size: "6x6", sku: "CPT-37-9128" }, { color: "Ocean Blue , 13SQF/CS", size: "6x6", sku: "CPT-37-9126" }],
  "Earthtone Brick": [{ color: "Dirt Brown", size: "2x4", sku: "CEK-37-9261" }, { color: "Sea Blue", size: "2x4", sku: "CEK-37-9260" }],
  "Elements": [{ color: "Black", size: "12x24", sku: "NVB-37-0064" }, { color: "Bronze", size: "12x24", sku: "NVB-37-0066" }, { color: "Gray", size: "12x24", sku: "NVB-37-0065" }, { color: "Night Sky Pearl", size: "1x1", sku: "LBT-37-5445" }, { color: "White", size: "12x24", sku: "NVB-37-0067" }],
  "Ellada": [{ color: "Anafi", size: "6x6", sku: "MCY-37-5050" }, { color: "Milos", size: "6x6", sku: "MCY-37-5052" }, { color: "Naxos", size: "6x6", sku: "MCY-37-5053" }],
  "Elysium": [{ color: "Gray", size: "1x2", sku: "MBA-37-2030" }, { color: "Gray", size: "2x4", sku: "MBA-37-2034" }, { color: "Peacock", size: "1x2", sku: "MBA-37-2031" }, { color: "Peacock", size: "2x4", sku: "MBA-37-2035" }, { color: "Turquoise", size: "1x2", sku: "MBA-37-2032" }, { color: "Turquoise", size: "2x4", sku: "MBA-37-2036" }],
  "Equinox": [{ color: "Black Steel", size: "1x1", sku: "BTI-37-1104" }, { color: "Black Steel", size: "1x2", sku: "BTI-37-1116" }, { color: "Black Steel", size: "2x2", sku: "BTI-37-1110" }, { color: "Dark Blue", size: "1x1", sku: "BTI-37-1100" }, { color: "Dark Blue", size: "1x2", sku: "BTI-37-1112" }, { color: "Dark Blue", size: "2x2", sku: "BTI-37-1106" }, { color: "Icy Teal", size: "1x1", sku: "BTI-37-1102" }, { color: "Icy Teal", size: "1x2", sku: "BTI-37-1114" }, { color: "Icy Teal", size: "2x2", sku: "BTI-37-1108" }, { color: "Multicolor", size: "1x1", sku: "BTI-37-1101" }, { color: "Multicolor", size: "1x2", sku: "BTI-37-1113" }, { color: "Multicolor", size: "2x2", sku: "BTI-37-1107" }],
  "Escapade": [{ color: "Aqua", size: "", sku: "MBA-37-2010" }, { color: "Aqua", size: "1x2", sku: "MBA-37-2013" }, { color: "Blue", size: "", sku: "MBA-37-2011" }, { color: "Blue", size: "1x2", sku: "MBA-37-2014" }],
  "Fiji": [{ color: "Bay Blue", size: "1x1", sku: "CPT-37-9104" }, { color: "Bay Blue", size: "2x2", sku: "CPT-37-9107" }, { color: "Bay Blue", size: "6x6", sku: "CPT-37-9101" }, { color: "Sky Blue", size: "1x1", sku: "CPT-37-9103" }, { color: "Sky Blue", size: "6x6", sku: "CPT-37-9100" }],
  "Gemstone": [{ color: "Blue \" x \"", size: "", sku: "GMI-37-0186" }],
  "Geostone": [{ color: "Geo Blue", size: "6x6", sku: "NVB-37-0086" }, { color: "Geo Blue", size: "6x6", sku: "NVB-37-0088" }, { color: "Geo Sand", size: "6x6", sku: "NVB-37-0089" }],
  "Glacier Bay": [{ color: "Ocean", size: "1x1", sku: "VOM-37-5071" }, { color: "Ocean", size: "1x2", sku: "VOM-37-5070" }, { color: "Sky Blue", size: "1x1", sku: "VOM-37-5073" }, { color: "Sky Blue", size: "1x2", sku: "VOM-37-5072" }, { color: "White", size: "1x1", sku: "VOM-37-5075" }, { color: "White", size: "1x2", sku: "VOM-37-5074" }],
  "Granito": [{ color: "Bahia Blue", size: "6x6", sku: "PTL-37-9750" }],
  "Hana": [{ color: "Capri", size: "6x6", sku: "CPT-37-9783" }, { color: "Cyan", size: "6x6", sku: "CPT-37-9785" }],
  "Harmony": [{ color: "Lake Blue", size: "3x3", sku: "PTK-37-9639" }, { color: "Ocean Blue", size: "3x3", sku: "PTK-37-9677" }, { color: "Olive Blue", size: "3x3", sku: "PTK-37-9675" }, { color: "Pacific Blue", size: "3x3", sku: "PTK-37-9679" }],
  "Iberia": [{ color: "Cadiz", size: "3x3", sku: "KKC-37-9600" }, { color: "La Mancha", size: "3x3", sku: "KKC-37-9601" }, { color: "Santiago", size: "3x3", sku: "KKC-37-9602" }],
  "Inaka": [{ color: "Subway Blue", size: "2x4", sku: "CEK-37-9504" }],
  "Islands": [{ color: "Ocean Breeze", size: "6x6", sku: "PTK-37-9740" }],
  "Jubilee": [{ color: "Black", size: "6x18", sku: "REA-37-7000" }, { color: "White", size: "6x18", sku: "REA-37-7001" }],
  "Jules": [{ color: "Bright Cobalt Blue", size: "1x1", sku: "BTI-37-2050" }, { color: "Rustic Blue", size: "1x1", sku: "BTI-37-2051" }],
  "Key West": [{ color: "Cool Waves", size: "6x6", sku: "CRZ-37-9267" }, { color: "Marina", size: "6x6", sku: "CRZ-37-9266" }, { color: "Silver", size: "6x6", sku: "CRZ-37-9215" }, { color: "Sunset (Earth)", size: "6x6", sku: "CRZ-37-9218" }],
  "Keys": [{ color: "Blue", size: "1x1", sku: "BTI-37-1151" }, { color: "Blue", size: "1x2", sku: "BTI-37-1153" }, { color: "Dark Blue", size: "1x1", sku: "BTI-37-1164" }, { color: "Dark Blue", size: "2x2", sku: "BTI-37-1165" }, { color: "Light Blue", size: "1x1", sku: "BTI-37-1160" }, { color: "Light Blue", size: "2x2", sku: "BTI-37-1161" }, { color: "Medium Blue", size: "1x1", sku: "BTI-37-1162" }, { color: "Medium Blue", size: "2x2", sku: "BTI-37-1163" }],
  "Lantern": [{ color: "Royal Blue", size: "3x3", sku: "CPT-37-9040" }],
  "Linen": [{ color: "Beige", size: "6x12", sku: "ISA-37-1075" }, { color: "Graphite", size: "6x12", sku: "ISA-37-1074" }, { color: "Midnight", size: "6x12", sku: "ISA-37-1071" }, { color: "Sand", size: "1x1", sku: "ISA-37-1080" }, { color: "Sand", size: "2x6", sku: "ISA-37-1082" }, { color: "Sky Blue", size: "6x12", sku: "ISA-37-1072" }, { color: "Turquoise", size: "6x12", sku: "ISA-37-1070" }, { color: "White", size: "6x12", sku: "ISA-37-1073" }],
  "Marblestone": [{ color: "Blue Marble", size: "6x6", sku: "NVB-37-0083" }, { color: "Standard", size: "6x6", sku: "NVB-37-0085" }],
  "Martinique": [{ color: "Ocean Blue", size: "2x2", sku: "CPT-37-9716" }, { color: "Ocean Blue", size: "6x6", sku: "CPT-37-9781" }, { color: "Royal Blue", size: "2x2", sku: "CPT-37-9774" }, { color: "Royal Blue", size: "6x6", sku: "CPT-37-9782" }],
  "Maui": [{ color: "Blue", size: "1x2", sku: "TGU-37-1070" }, { color: "Blue", size: "3x3", sku: "TGU-37-1071" }, { color: "Cobalt", size: "1x2", sku: "TGU-37-1072" }, { color: "Cobalt", size: "3x3", sku: "TGU-37-1073" }, { color: "Teal", size: "1x2", sku: "TGU-37-1074" }, { color: "Teal", size: "3x3", sku: "TGU-37-1075" }],
  "Melody": [{ color: "Alice Blue White", size: "1x1", sku: "MBA-37-2074" }, { color: "Alice Blue White", size: "1x3", sku: "MBA-37-2075" }, { color: "Aquamarine", size: "1x1", sku: "MBA-37-2072" }, { color: "Aquamarine", size: "1x3", sku: "MBA-37-2073" }, { color: "Cobalt", size: "1x1", sku: "MBA-37-2070" }, { color: "Cobalt", size: "1x3", sku: "MBA-37-2071" }],
  "Meridian": [{ color: "Cobalt", size: "2x2", sku: "CPT-37-9789" }, { color: "Electric", size: "1x1", sku: "CPT-37-9791" }, { color: "Electric Blue", size: "1x2", sku: "CPT-37-9795" }, { color: "Sea Green", size: "1x2", sku: "CPT-37-9794" }],
  "Mermaid": [{ color: "Abruzzo Interlocking", size: "", sku: "LBT-37-5454" }, { color: "Aero Interlocking", size: "", sku: "LBT-37-5452" }, { color: "Portofino Interlocking", size: "", sku: "LBT-37-5450" }],
  "Mini Koyn": [{ color: "Basic Cobalt", size: "1x1", sku: "PTK-37-9654" }, { color: "Blue", size: "1x1", sku: "PTK-37-9666" }, { color: "Electric Blue", size: "1x1", sku: "PTK-37-9655" }, { color: "Indigo", size: "1x1", sku: "VOM-37-5052" }, { color: "Royal Blue", size: "1x1", sku: "PTK-37-9653" }, { color: "Sky Blue", size: "1x1", sku: "PTK-37-9662" }, { color: "True Blue", size: "1x1", sku: "VOM-37-5056" }, { color: "White", size: "1x1", sku: "PTK-37-9665" }],
  "Mini Koyn Glass": [{ color: "Aquamarine", size: "1x1", sku: "VOM-37-5051" }, { color: "Caribbean Sea", size: "1x1", sku: "VOM-37-5050" }, { color: "Cerulean", size: "1x1", sku: "VOM-37-5053" }, { color: "Cobalt", size: "1x1", sku: "VOM-37-5057" }],
  "Mix Mosaic": [{ color: "Blue Brown", size: "1x1", sku: "PTK-37-9719" }, { color: "Ocean", size: "1x1", sku: "PTK-37-9737" }, { color: "Sandy Beach", size: "1x1", sku: "PTK-37-9736" }],
  "Moon": [{ color: "scape Gray", size: "2x6", sku: "ANM-37-9506" }, { color: "scape Gray", size: "6x6", sku: "ANM-37-9507" }, { color: "scape Turquoise", size: "2x6", sku: "ANM-37-9504" }, { color: "scape Turquoise", size: "6x6", sku: "ANM-37-9505" }, { color: "scape White", size: "2x6", sku: "ANM-37-9502" }, { color: "scape White", size: "6x6", sku: "ANM-37-9503" }],
  "Moonbeam": [{ color: "Cobalt Blue", size: "", sku: "PTK-37-9668" }, { color: "Lake Blue", size: "", sku: "PTK-37-9648" }],
  "Navajo": [{ color: "Blue", size: "1x2", sku: "TGU-37-1063" }, { color: "Blue", size: "3x6", sku: "TGU-37-1062" }, { color: "Gray", size: "1x2", sku: "TGU-37-1061" }, { color: "Gray", size: "3x6", sku: "TGU-37-1060" }, { color: "White", size: "1x2", sku: "TGU-37-1065" }, { color: "White", size: "3x6", sku: "TGU-37-1064" }],
  "Newstone": [{ color: "Beige", size: "12x24", sku: "NVB-37-0103" }, { color: "Beige", size: "2x2", sku: "NVB-37-0101" }, { color: "Beige", size: "6x24", sku: "NVB-37-0102" }, { color: "Beige", size: "6x6", sku: "NVB-37-0100" }, { color: "Pietra Azul", size: "12x24", sku: "NVB-37-0123" }, { color: "Pietra Azul", size: "2x2", sku: "NVB-37-0121" }, { color: "Pietra Azul", size: "6x24", sku: "NVB-37-0122" }, { color: "Pietra Azul", size: "6x6", sku: "NVB-37-0120" }, { color: "White Gray", size: "12x24", sku: "NVB-37-0113" }, { color: "White Gray", size: "2x2", sku: "NVB-37-0111" }, { color: "White Gray", size: "6x24", sku: "NVB-37-0112" }, { color: "White Gray", size: "6x6", sku: "NVB-37-0110" }],
  "North Ocean": [{ color: "Blue \" x \"", size: "", sku: "ELS-37-9200" }, { color: "Cobalt", size: "6x6", sku: "ELS-37-9213" }, { color: "Cobalt \" x \"", size: "", sku: "ELS-37-9204" }],
  "Oceans": [{ color: "Aqua", size: "6x6", sku: "PTK-37-9685" }, { color: "Cobalt", size: "6x6", sku: "PTK-37-9687" }, { color: "Marine", size: "6x6", sku: "PTK-37-9688" }],
  "Onyx": [{ color: "Cobalt", size: "1x2", sku: "GMI-37-0304" }, { color: "Cobalt", size: "6x6", sku: "GMI-37-0313" }, { color: "Emerald", size: "1x2", sku: "GMI-37-0307" }, { color: "Emerald", size: "6x6", sku: "GMI-37-0314" }, { color: "Light Blue", size: "1x2", sku: "GMI-37-0301" }, { color: "Light Blue", size: "6x6", sku: "GMI-37-0312" }],
  "Opal": [{ color: "Azure Blue", size: "1x1", sku: "VOM-37-5011" }, { color: "Bronze Alloy", size: "1x1", sku: "VOM-37-5008" }, { color: "Mint Green", size: "1x1", sku: "VOM-37-5007" }, { color: "Pearl White", size: "1x1", sku: "VOM-37-5009" }, { color: "Sky Blue", size: "1x1", sku: "VOM-37-5006" }, { color: "Steel Gray", size: "1x1", sku: "VOM-37-5010" }],
  "Orion": [{ color: "Iceberg", size: "1x2", sku: "SUE-37-1062" }, { color: "Iceberg \" x \"", size: "", sku: "SUE-37-1065" }, { color: "Ocean", size: "1x2", sku: "SUE-37-1063" }, { color: "Ocean \" x \"", size: "", sku: "SUE-37-1066" }, { color: "Peacock", size: "1x2", sku: "SUE-37-1060" }, { color: "Peacock \" x \"", size: "", sku: "SUE-37-1064" }],
  "Oxford": [{ color: "Blue \" x \"", size: "", sku: "SMF-37-9200" }, { color: "Multicolor", size: "6x6", sku: "SMF-37-9209" }],
  "Paradise": [{ color: "Aquamarine", size: "1x1", sku: "VOM-37-5063" }, { color: "Aquamarine", size: "1x2", sku: "VOM-37-5062" }, { color: "Blue", size: "1x1", sku: "VOM-37-5061" }, { color: "Blue", size: "1x2", sku: "VOM-37-5060" }],
  "Parallax": [{ color: "Cyan", size: "1x2", sku: "SUE-37-1071" }],
  "Pearl": [{ color: "Wind", size: "1x1", sku: "ISA-37-1081" }, { color: "Wind Light Blue", size: "2x6", sku: "ISA-37-1083" }],
  "Prism": [{ color: "Midnight", size: "3x3", sku: "OCG-37-0315" }, { color: "Teal", size: "3x3", sku: "OCG-37-0313" }, { color: "Turquoise", size: "3x3", sku: "OCG-37-0314" }],
  "Purity": [{ color: "Light Blue", size: "6x6", sku: "DCR-37-0102" }, { color: "White", size: "6x6", sku: "DCR-37-0100" }],
  "Ridgeline": [{ color: "Blue Slate \" x \"", size: "", sku: "GMI-37-0180" }, { color: "Silver \" x \"", size: "", sku: "GMI-37-0182" }],
  "Rushmore": [{ color: "Blue Quartz", size: "6x6", sku: "NVB-37-9670" }, { color: "Crystal Quartz", size: "6x6", sku: "NVB-37-9672" }],
  "Safari": [{ color: "Boulder Gray", size: "6x6", sku: "GMI-37-0132" }, { color: "Multicolor", size: "6x6", sku: "GMI-37-0133" }, { color: "Sky Blue", size: "6x6", sku: "GMI-37-0131" }],
  "Sargasso": [{ color: "Aqua", size: "6x6", sku: "MCY-37-5130" }, { color: "Royal", size: "6x6", sku: "MCY-37-5129" }],
  "Scents": [{ color: "Gray", size: "3x16", sku: "DCU-37-1261" }, { color: "Light Blue", size: "3x16", sku: "DCU-37-1263" }, { color: "White", size: "3x16", sku: "DCU-37-1260" }],
  "Sea Glass": [{ color: "Cobalto", size: "1x2", sku: "VOM-37-5041" }],
  "Sea Ice": [{ color: "Silver", size: "1x1", sku: "OCG-37-0154" }, { color: "Silver", size: "1x2", sku: "OCG-37-0159" }],
  "Seabreeze": [{ color: "Aquamarine", size: "6x18", sku: "REA-37-7030" }, { color: "Baltic Blue", size: "6x18", sku: "REA-37-7031" }],
  "Seamist": [{ color: "Midnight Blue", size: "2x3", sku: "BTI-37-1172" }],
  "Seascape": [{ color: "Breeze", size: "1x1", sku: "RHI-37-1083" }, { color: "Breeze", size: "1x2", sku: "RHI-37-1087" }, { color: "Lagoon \" x \"", size: "", sku: "RHI-37-1086" }, { color: "Lagoon \" x \"", size: "", sku: "RHI-37-1082" }, { color: "Ocean \" x \"", size: "", sku: "RHI-37-1085" }, { color: "Ocean \" x \"", size: "", sku: "RHI-37-1081" }],
  "Serpentine": [{ color: "Blue", size: "6x6", sku: "PTL-37-9721" }, { color: "Gray", size: "6x6", sku: "PTL-37-9720" }, { color: "Marine", size: "6x6", sku: "PTL-37-9722" }],
  "Seven Seas": [{ color: "Lake Blue", size: "6x6", sku: "PGR-37-9634" }, { color: "Mediterranean Blue", size: "6x6", sku: "PGR-37-9633" }],
  "Sierra Blue Slate": [{ color: "Blue Slate", size: "6x6", sku: "NVB-37-9660" }],
  "Slate": [{ color: "Ash", size: "12x24", sku: "PTL-37-9778" }, { color: "Ash", size: "6x12", sku: "PTL-37-9775" }, { color: "Ash", size: "6x6", sku: "PTL-37-9772" }, { color: "Pewter", size: "12x24", sku: "PTL-37-9777" }, { color: "Pewter", size: "6x12", sku: "PTL-37-9774" }, { color: "Pewter", size: "6x6", sku: "PTL-37-9771" }, { color: "White", size: "12x24", sku: "PTL-37-9776" }, { color: "White", size: "6x12", sku: "PTL-37-9773" }, { color: "White", size: "6x6", sku: "PTL-37-9770" }],
  "Soleil": [{ color: "Cleo Blue", size: "", sku: "NPT-37-1051" }, { color: "Cleo Blue", size: "1x1", sku: "NPT-37-1054" }, { color: "Silver", size: "", sku: "NPT-37-1052" }, { color: "Silver", size: "1x1", sku: "NPT-37-1055" }],
  "South Seas": [{ color: "Blue", size: "", sku: "BTI-37-1061" }, { color: "Teal", size: "", sku: "BTI-37-1063" }],
  "Starburst": [{ color: "Silver", size: "", sku: "VOM-37-5021" }, { color: "Smoke Gray", size: "", sku: "VOM-37-5020" }, { color: "Teal", size: "", sku: "VOM-37-5022" }],
  "Street Random": [{ color: "Beige", size: "", sku: "CEK-37-9380" }, { color: "Black", size: "", sku: "CEK-37-9362" }, { color: "Copper", size: "", sku: "CEK-37-9322" }, { color: "Dark Blue", size: "", sku: "CEK-37-9321" }, { color: "Mini Dark Blue", size: "", sku: "CEK-37-9271" }],
  "Talavera": [{ color: "La Paz", size: "6x6", sku: "GMI-37-0210" }, { color: "Merida", size: "6x6", sku: "GMI-37-0212" }, { color: "Puebla", size: "6x6", sku: "GMI-37-0211" }],
  "Tivoli Stone": [{ color: "Blue", size: "2x2", sku: "GMI-37-0203" }, { color: "Blue", size: "6x6", sku: "GMI-37-0200" }, { color: "Silver", size: "2x2", sku: "GMI-37-0204" }, { color: "Silver", size: "6x6", sku: "GMI-37-0201" }],
  "Tuxedo": [{ color: "Black", size: "1x1", sku: "VOM-37-5065" }, { color: "Black", size: "1x2", sku: "VOM-37-5064" }, { color: "White", size: "1x1", sku: "VOM-37-5067" }, { color: "White", size: "1x2", sku: "VOM-37-5066" }],
  "Unglazed": [{ color: "Black", size: "2x2", sku: "CEK-37-9236" }, { color: "Black Raven", size: "2x2", sku: "SLP-37-9623" }, { color: "Blue", size: "2x2", sku: "CEK-37-9237" }, { color: "Dark Blue", size: "2x2", sku: "INL-37-4067" }, { color: "Raven Black", size: "1x1", sku: "SLP-37-9622" }, { color: "Sapphire Sky", size: "1x1", sku: "SLP-37-9624" }, { color: "Sapphire Sky", size: "2x2", sku: "SLP-37-9625" }, { color: "White", size: "1x1", sku: "SLP-37-9620" }, { color: "White", size: "2x2", sku: "SLP-37-9621" }],
  "Utopia": [{ color: "Light Blue", size: "6x18", sku: "REA-37-7011" }, { color: "Navy", size: "6x18", sku: "REA-37-7012" }, { color: "White", size: "6x18", sku: "REA-37-7010" }],
  "Vagli": [{ color: "Blue Marble", size: "6x6", sku: "PTL-37-9781" }, { color: "Classic Calacatta", size: "6x6", sku: "PTL-37-9780" }],
  "Veracruz": [{ color: "Cream", size: "2x2", sku: "NVB-37-0043" }, { color: "Cream \" x \"", size: "", sku: "NVB-37-0056" }, { color: "Gray", size: "2x2", sku: "NVB-37-0045" }, { color: "Gray \" x \"", size: "", sku: "NVB-37-0057" }],
  "Verona": [{ color: "Borba Turquoise", size: "6x6", sku: "PGR-37-9625" }, { color: "Tondela Blue", size: "6x6", sku: "PGR-37-9629" }],
  "Villastone": [{ color: "Cascade Beige", size: "6x18", sku: "REA-37-7042" }, { color: "Cascade Black", size: "6x18", sku: "REA-37-7045" }, { color: "Cascade Gray", size: "6x18", sku: "REA-37-7040" }, { color: "Cascade White", size: "6x18", sku: "REA-37-7044" }, { color: "Splitface Beige", size: "6x18", sku: "REA-37-7043" }, { color: "Splitface Gray", size: "6x18", sku: "REA-37-7041" }],
  "Volcano": [{ color: "Aqua Blue", size: "1x1", sku: "CEK-37-9323" }, { color: "Aqua Blue", size: "3x3", sku: "CEK-37-9328" }, { color: "Aqua Blue", size: "6x6", sku: "CEK-37-9354" }, { color: "Beige", size: "1x1", sku: "CEK-37-9327" }, { color: "Beige", size: "3x3", sku: "CEK-37-9332" }, { color: "Beige", size: "6x6", sku: "CEK-37-9340" }, { color: "Brown", size: "1x1", sku: "CEK-37-9326" }, { color: "Brown", size: "3x3", sku: "CEK-37-9353" }, { color: "Brown", size: "6x6", sku: "CEK-37-9339" }, { color: "Dark Blue", size: "1x1", sku: "CEK-37-9325" }, { color: "Dark Blue", size: "3x3", sku: "CEK-37-9331" }, { color: "Dark Blue", size: "6x6", sku: "CEK-37-9336" }, { color: "Light Blue", size: "1x1", sku: "CEK-37-9324" }, { color: "Light Blue", size: "3x3", sku: "CEK-37-9329" }, { color: "Light Blue", size: "6x6", sku: "CEK-37-9335" }],
  "Zanzibar": [{ color: "Blue", size: "6x18", sku: "REA-37-7020" }],
};

// Raised spa (Thomas, Nov 13): the wall is split face travertine, stone or brick veneer, or the pool's waterline tile; the
// spillover is granite or the same tile. Tile prices by SF with labor in 6 inch bands.
export const SPA_WALL_FINISHES = ["Split Face Travertine", "Stone Veneer", "Brick Veneer", "Tile (same as waterline)"];
export const SPA_SPILLOVERS = ["Granite", "Tile (same as waterline)"];

// Fire bowls price by ignition (Thomas, Nov 13): $6,000 each electronic, $4,000 each manual.
export const FIREBOWL_IGNITIONS = ["Manual ignition", "Electronic ignition"];
