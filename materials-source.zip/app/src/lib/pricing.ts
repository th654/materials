/* Live pricing against the sold job. Claire sends one price sheet per client (every option's difference against the sold
   Estimate Review, client price only); this file turns the selections on screen into the lines and total the rep and
   client watch. These numbers are a display: Claire prices the final picks again herself when the sheet is submitted. */

export type TileOpt = { brand?: string; color?: string; series: string; size: string; sku: string; type: string; delta: number | null; ppsf?: number | null; labor?: number; price_sf?: number | null };
/** Raised spa: the wall finish and spillover as sold, and what tile costs where no tile was sold (waste, labor and install per LF). */
export type SpaPrices = {
  rate: { waste: number; install: number; labor: Record<string, number> };
  wall?: { sold: string[]; sf: number; materials: Record<string, number | null>; credit: number };
  spill?: { sold: string; credit?: number; granite?: number | null };
};
export type Prices = {
  est_id: string;
  sold_total?: number;
  tile?: { sold: string; sold_type: string; sf: number; lf?: number; options: TileOpt[] };
  finish?: { sold: string; sf: number; options: { family: string; tier: string; colors: string[]; delta: number | null }[] };
  coping?: { sold: string[]; options: { color: string; thickness: string; profile: string; delta: number | null; offered?: boolean }[]; materials?: Record<string, number | null> };
  deck?: { sold: string[]; sf: number; materials: Record<string, number | null> };
  pavers?: { sold: string[]; options: { color: string; pattern: string; delta: number | null }[] };
  custom?: { name: string; unit: string; price: number }[];
  spa?: SpaPrices;
  /** Retaining walls: the finish sold on the CMU walls, the wall face SF, and each finish as a change on all of it. */
  walls?: { sold: string; sf: number; materials: Record<string, number | null>;
    /** Coping on the walls: material only, as a change on the whole run. Keys "Travertine|Color|5CM|Bullnose|12X24" and "Flagstone". */
    coping?: { sold: string[]; lf: number; materials: Record<string, number | null> } };
};
export type CustomItem = { id: number; name: string; qty: string };
/** delta null = no price on file yet ("price needed"); the line still shows so nobody signs past a hole. */
export type PriceLine = { key: string; label: string; detail: string; delta: number | null; note?: string };

const norm = (s: string) => s.toLowerCase().replace(/&/g, "and").replace(/gray/g, "grey").replace(/[^a-z0-9]+/g, " ").trim();
const dims = (s: string) => { const m = s.toLowerCase().match(/(\d+(?:\.\d+)?)\s*["”]?\s*x\s*(\d+(?:\.\d+)?)/); return m ? `${m[1]}x${m[2]}` : ""; };

export const money = (n: number) => `$${Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
export const signed = (n: number) => (n < -0.004 ? `Credit ${money(n)}` : n > 0.004 ? `+${money(n)}` : "Included");

const SERIES_ALIAS: Record<string, string> = { chateu: "chateau" };

/** A picked Aquabella tile against the priced series: same series, then same size. Two prices for one size is not a guess.
    undefined = nothing picked yet, null = no price on file. */
export function tileOption(p: Prices, product: string, size: string, sku = ""): TileOpt | null | undefined {
  if (!p.tile || !product) return undefined;
  // NPT is priced tile by tile (pool360): the SKU the picker resolved is the match, nothing looser.
  if (sku) {
    const hit = p.tile.options.find(o => o.brand === "NPT" && o.sku === sku);
    if (hit) return hit.delta === null ? null : hit;
  }
  let series = norm(product.split(" - ")[0]);
  series = SERIES_ALIAS[series] ?? series;
  const rows = p.tile.options.filter(o => o.brand !== "NPT" && norm(o.series) === series);
  if (!rows.length) return null;
  const want = dims(size) || norm(size).replace("hexagon", "hex");
  const sized = rows.filter(o => (dims(o.size) || norm(o.size)) === want || norm(o.size) === want);
  const pool = sized.length ? sized : rows;
  const exact = pool.find(o => norm(o.size) === norm(size) || o.size.toLowerCase() === want);
  if (exact) return exact.delta === null ? null : exact;
  const prices = Array.from(new Set(pool.map(o => o.delta)));
  return prices.length === 1 && prices[0] !== null ? pool[0] : null;
}
export function tileDelta(p: Prices, product: string, size: string): number | null | undefined {
  const o = tileOption(p, product, size);
  return o ? o.delta : o;
}
const r2 = (n: number) => Math.round((n + (n >= 0 ? 1e-9 : -1e-9)) * 100) / 100;
/** Field tile with a deco tile every n: the sold tile area splits n/(n+1) field and 1/(n+1) deco, each at its own price
    difference per SF, and labor follows the field tile. Same arithmetic Claire uses for the change order. */
export function tileWithDeco(p: Prices, field: TileOpt, deco: TileOpt, n: number): number | null {
  if (!p.tile || field.ppsf == null || deco.ppsf == null || !(n > 0)) return null;
  const qf = r2(p.tile.sf * n / (n + 1)), qd = r2(p.tile.sf - qf);
  return r2(r2(qf * field.ppsf) + r2(qd * deco.ppsf) + (field.labor ?? 0));
}

/** Tile set where none was sold (a spa wall, a spillover): the tile at its own price on the SF plus waste, labor and install
    material per LF in 6 inch bands (1 SF of wall is 2 LF), less what comes out. Claire prices it the same way. */
export function tileOnWall(spa: SpaPrices, tile: TileOpt, sf: number, credit: number): number | null {
  const labor = spa.rate.labor[tile.type];
  if (tile.price_sf == null || labor == null || !(sf > 0)) return null;
  const lf = r2(sf * 2);
  return r2(credit + r2(r2(sf * (1 + spa.rate.waste)) * tile.price_sf) + r2(lf * labor) + r2(lf * spa.rate.install));
}
export const spilloverSf = (lengthFt: number, heightIn: number) => r2(lengthFt * 14 / 12 + lengthFt * heightIn / 12);
const num = (s: string) => Number(String(s).replace(/[^\d.]/g, "")) || 0;

const FINISH_FAMILY: Record<string, string> = {
  "stonescapes|mini pebble": "mini_pebble",
  "stonescapes|glass mini pebble": "glass_mini_pebble",
  "quartz|": "quartz",
  "plaster|": "plaster",
};

export function finishDelta(p: Prices, brand: string, texture: string, color: string): number | null | undefined {
  if (!p.finish || !brand) return undefined;
  const fam = FINISH_FAMILY[`${norm(brand)}|${norm(texture)}`] ?? FINISH_FAMILY[`${norm(brand)}|`];
  if (!fam) return null;
  if (!color) return undefined;
  const hit = p.finish.options.find(o => o.family === fam && o.colors.some(c => norm(c) === norm(color)));
  return hit ? hit.delta : null;
}

export function copingDelta(p: Prices, color: string, thickness: string, profile: string): number | null | undefined {
  if (!p.coping) return undefined;
  if (!color || !thickness || !profile) return undefined;
  const th = thickness.replace(/\s+/g, "").toUpperCase();
  const hit = p.coping.options.find(o => norm(o.color) === norm(color) && o.thickness === th && norm(o.profile) === norm(profile));
  return hit ? hit.delta : null;
}

export function paverDelta(p: Prices, color: string, pattern: string): number | null | undefined {
  if (!p.pavers) return undefined;
  if (!color || !pattern) return undefined;
  const hit = p.pavers.options.find(o => norm(o.color) === norm(color) && norm(o.pattern) === norm(pattern));
  return hit ? hit.delta : null;
}

type Read = (k: string) => string;

export function priceSelections(p: Prices, eff: Read, opt: { concrete: boolean; waterlineNa: boolean; decks: number[]; customs: CustomItem[]; spaNa?: boolean; walls?: number[]; wallsNa?: boolean }): PriceLine[] {
  const out: PriceLine[] = [];
  const add = (key: string, label: string, detail: string, d: number | null | undefined, note?: string) => {
    if (d === undefined) return;
    out.push({ key, label, detail, delta: d, note: d === null ? note ?? "Price needed" : note });
  };

  if (opt.concrete && p.finish) {
    const brand = eff("interior.brand"), texture = eff("interior.texture"), color = eff("interior.color");
    add("finish", "Interior finish", [brand, texture, color].filter(Boolean).join(" · "), finishDelta(p, brand, texture, color));
  }

  if (p.coping) {
    const mat = eff("coping.material");
    if (mat === "Travertine") {
      const c = eff("coping.travColor"), t = eff("coping.travThickness"), pr = eff("coping.travProfile");
      const th = t.replace(/\s+/g, "").toUpperCase();
      const opt = p.coping.options.find(o => norm(o.color) === norm(c) && o.thickness === th && norm(o.profile) === norm(pr));
      add("coping", "Coping", [c, t, pr].filter(Boolean).join(" · "), copingDelta(p, c, t, pr), opt && opt.offered === false ? "Not offered in this color and profile" : undefined);
    } else if (mat) {
      const key = mat === "Concrete Paver" ? "" : mat;
      const d = p.coping.materials && key in p.coping.materials ? p.coping.materials[key] : null;
      add("coping", "Coping", `${mat} in place of the coping sold`, d);
    }
  }

  if (opt.concrete && !opt.waterlineNa && p.tile) {
    const brand = eff("waterline.brand"), product = eff("waterline.product"), size = eff("waterline.size");
    const detail = [brand === "__other__" ? "" : brand === "Aquabella" ? "" : brand, product, eff("waterline.color"), size].filter(Boolean).join(" · ");
    const field = brand === "Aquabella" && product ? tileOption(p, product, size)
      : brand === "NPT" && product ? (eff("waterline.sku") ? tileOption(p, product, size, eff("waterline.sku")) ?? null : undefined)
      : brand && product ? null : undefined;
    const decoOn = eff("waterline.deco.on") === "Yes" && !!eff("waterline.deco.product");
    const n = Number((eff("waterline.deco.ratio").match(/^(\d+)\s*:/) ?? [])[1] ?? 0);
    const deco = !decoOn ? null : brand === "Aquabella" ? tileOption(p, eff("waterline.deco.product"), eff("waterline.deco.size"))
      : brand === "NPT" && eff("waterline.deco.sku") ? tileOption(p, eff("waterline.deco.product"), eff("waterline.deco.size"), eff("waterline.deco.sku")) : null;
    if (field && decoOn && deco && n > 0) {
      add("tile", "Waterline tile", `${detail} with ${eff("waterline.deco.product")} deco every ${n}`, tileWithDeco(p, field, deco, n));
    } else {
      add("tile", "Waterline tile", detail, field ? field.delta : field);
      if (decoOn) add("deco", "Deco tile", eff("waterline.deco.product"), null, n > 0 ? "Price needed" : "Pick the pattern ratio");
    }
  }

  if (p.pavers || p.deck) {
    const key = (id: number) => {
      const m = eff(`decking.${id}.material`), base = `decking.${id}`;
      if (!m) return "";
      if (m === "Travertine") return `Travertine|${eff(`${base}.travColor`)}|${eff(`${base}.paverFormat`)}`;
      if (m === "Poured Concrete") return `Poured Concrete|${eff(`${base}.finish`)}${eff(`${base}.finish`) === "Broom Finish" && eff(`${base}.integralColor`) === "Yes" ? "|color" : ""}`;
      return m;
    };
    const picks = Array.from(new Set(opt.decks.map(key).filter(Boolean)));
    const priceOf = (k: string): number | null | undefined => {
      if (k.startsWith("Travertine|")) { const [, c, f] = k.split("|"); return p.pavers ? paverDelta(p, c, f) : c && f ? null : undefined; }
      if (k.endsWith("|")) return undefined;
      return p.deck && k in p.deck.materials ? p.deck.materials[k] : null;
    };
    if (picks.length > 1) {
      // Areas that differ: each one prices on its own square feet, as its share of the deck that was sold.
      const soldSf = p.deck?.sf ?? 0;
      let total = 0, sfSum = 0, state: "ok" | "sf" | "price" | "wait" = "ok";
      for (const k of picks) {
        const sf = opt.decks.filter(id => key(id) === k).reduce((s, id) => s + num(eff(`decking.${id}.sf`)), 0);
        const d = priceOf(k);
        if (d === undefined) { state = "wait"; break; }
        if (!(sf > 0) || !(soldSf > 0)) { state = "sf"; break; }
        if (d === null) { state = "price"; break; }
        total += d * sf / soldSf; sfSum += sf;
      }
      if (state === "sf") add("deck", "Pool deck", "Deck areas have different picks", null, "Enter each area's SF");
      else if (state === "price") add("deck", "Pool deck", "Deck areas have different picks", null, "Price needed");
      else if (state === "ok" && sfSum > soldSf * 1.02) add("deck", "Pool deck", `${Math.round(sfSum)} SF picked, ${Math.round(soldSf)} SF in the contract`, null, "Added deck is a custom price");
      else if (state === "ok") add("deck", "Pool deck", `${picks.length} deck areas, each on its own SF`, r2(total));
    } else if (picks.length === 1) {
      const k = picks[0];
      if (k.startsWith("Travertine|")) {
        const [, c, f] = k.split("|");
        add("deck", "Pool deck", ["Travertine", c, f].filter(Boolean).join(" · "), p.pavers ? paverDelta(p, c, f) : c && f ? null : undefined);
      } else if (!k.endsWith("|")) {
        const d = p.deck && k in p.deck.materials ? p.deck.materials[k] : null;
        add("deck", "Pool deck", `${k.replace(/\|color$/, " with integral color").replace("|", " · ")} in place of the deck sold`, d);
      }
    }
  }

  if (p.walls && !opt.wallsNa && opt.walls) {
    const W = p.walls;
    const wkey = (id: number) => {
      if (eff(`walls.${id}.type`) !== "CMU Block Wall") return "";
      const f = eff(`walls.${id}.cmuFinish`);
      if (f === "Split-face Travertine") { const c = eff(`walls.${id}.splitFaceColor`); return c ? `${f}|${c}` : ""; }
      return f;
    };
    const priceOf = (k: string): number | null => { const m = Object.keys(W.materials).find(x => norm(x) === norm(k)); return m ? W.materials[m] : null; };
    const picks = Array.from(new Set(opt.walls.map(wkey).filter(Boolean)));
    if (picks.length === 1) add("walls", "Retaining wall finish", picks[0].replace("|", " · "), priceOf(picks[0]));
    else if (picks.length > 1) {
      let total = 0, sfSum = 0, state: "ok" | "sf" | "price" = "ok";
      for (const k of picks) {
        const sf = opt.walls.filter(id => wkey(id) === k).reduce((s, id) => s + num(eff(`walls.${id}.sf`)), 0);
        const d = priceOf(k);
        if (!(sf > 0)) { state = "sf"; break; }
        if (d === null) { state = "price"; break; }
        total += d * sf / W.sf; sfSum += sf;
      }
      if (state === "sf") add("walls", "Retaining wall finish", "Walls have different finishes", null, "Enter each wall's SF");
      else if (state === "price") add("walls", "Retaining wall finish", "Walls have different finishes", null, "Price needed");
      else if (sfSum > W.sf * 1.02) add("walls", "Retaining wall finish", `${Math.round(sfSum)} SF picked, ${Math.round(W.sf)} SF in the contract`, null, "Added wall is a custom price");
      else add("walls", "Retaining wall finish", `${picks.length} finishes, each on its own SF`, r2(total));
    }
  }

  if (p.walls?.coping && !opt.wallsNa && opt.walls) {
    const K = p.walls.coping;
    const ckey = (id: number) => {
      if (eff(`walls.${id}.type`) !== "CMU Block Wall") return "";
      const c = eff(`walls.${id}.cmuCoping`).replace(" Coping", "");
      if (c !== "Travertine") return c;
      const color = eff(`walls.${id}.travColor`), thick = eff(`walls.${id}.travThickness`), prof = eff(`walls.${id}.travProfile`), size = eff(`walls.${id}.travSize`);
      return color && thick && prof && size ? `Travertine|${color}|${thick.replace(/\s+/g, "").toUpperCase()}|${prof}|${size.toUpperCase()}` : "";
    };
    const priceOf = (k: string): number | null => { const m = Object.keys(K.materials).find(x => norm(x) === norm(k)); return m ? K.materials[m] : null; };
    const picks = Array.from(new Set(opt.walls.map(ckey).filter(Boolean)));
    const say = (k: string) => k.split("|").join(" · ");
    if (picks.length === 1) add("wall_coping", "Wall coping", say(picks[0]), priceOf(picks[0]));
    else if (picks.length > 1) {
      let total = 0, lfSum = 0, state: "ok" | "lf" | "price" = "ok";
      for (const k of picks) {
        const lf = opt.walls.filter(id => ckey(id) === k).reduce((s, id) => s + num(eff(`walls.${id}.copingLf`)), 0);
        const d = priceOf(k);
        if (!(lf > 0) || !(K.lf > 0)) { state = "lf"; break; }
        if (d === null) { state = "price"; break; }
        total += d * lf / K.lf; lfSum += lf;
      }
      if (state === "lf") add("wall_coping", "Wall coping", "Walls have different coping", null, "Enter each wall's coping LF");
      else if (state === "price") add("wall_coping", "Wall coping", "Walls have different coping", null, "Price needed");
      else if (lfSum > K.lf * 1.02) add("wall_coping", "Wall coping", `${Math.round(lfSum)} LF picked, ${Math.round(K.lf)} LF in the contract`, null, "Added coping is a custom price");
      else add("wall_coping", "Wall coping", `${picks.length} copings, each on its own LF`, r2(total));
    }
  }

  if (opt.concrete && p.spa && !opt.spaNa) {
    const brand = eff("waterline.brand"), product = eff("waterline.product"), size = eff("waterline.size");
    const tile = opt.waterlineNa || !product ? undefined : brand === "Aquabella" ? tileOption(p, product, size) : brand === "NPT" && eff("waterline.sku") ? tileOption(p, product, size, eff("waterline.sku")) : null;
    const wall = eff("spa.wallFinish");
    if (p.spa.wall && wall) {
      if (wall === "Split Face Travertine") {
        const c = eff("spa.wallColor");
        const k = Object.keys(p.spa.wall.materials).find(m => norm(m) === norm(`Split Face Travertine|${c}`));
        if (c) add("spa_wall", "Spa wall", `Split Face Travertine · ${c}`, k ? p.spa.wall.materials[k] : null);
      } else if (wall.startsWith("Tile")) {
        add("spa_wall", "Spa wall", `Tile${product ? ` · ${product}` : ""}`, tile ? tileOnWall(p.spa, tile, p.spa.wall.sf, p.spa.wall.credit) : null, tile === undefined ? "Pick the waterline tile first" : undefined);
      } else {
        add("spa_wall", "Spa wall", `${wall} in place of the veneer sold`, wall in p.spa.wall.materials ? p.spa.wall.materials[wall] : null);
      }
    }
    const spill = eff("spa.spillover");
    if (p.spa.spill && spill) {
      const isTile = spill.startsWith("Tile");
      if ((isTile ? "Tile" : spill) === p.spa.spill.sold) add("spillover", "Spa spillover", spill, 0);
      else if (isTile) {
        const sf = spilloverSf(num(eff("spa.spillLength")), num(eff("spa.raisedHeight")));
        const ready = num(eff("spa.spillLength")) > 0 && num(eff("spa.raisedHeight")) > 0;
        add("spillover", "Spa spillover", `Tile${product ? ` · ${product}` : ""}`, ready && tile ? tileOnWall(p.spa, tile, sf, p.spa.spill.credit ?? 0) : null,
          !ready ? "Enter the spillover length and raised height" : tile === undefined ? "Pick the waterline tile first" : undefined);
      } else if (spill === "Granite") add("spillover", "Spa spillover", "Granite in place of the tile sold", p.spa.spill.granite ?? null);
      else add("spillover", "Spa spillover", spill, null);
    }
  }

  for (const c of opt.customs) {
    const it = (p.custom ?? []).find(x => x.name === c.name);
    const qty = Number(c.qty);
    if (!c.name) continue;
    if (!it || !(qty > 0)) { out.push({ key: `custom.${c.id}`, label: "Added item", detail: c.name, delta: null, note: it ? "Enter a quantity" : "Price needed" }); continue; }
    out.push({ key: `custom.${c.id}`, label: "Added item", detail: `${it.name} · ${qty} ${it.unit}`, delta: Math.round(qty * it.price * 100) / 100 });
  }
  return out;
}

export const totalOf = (lines: PriceLine[]) => Math.round(lines.reduce((s, l) => s + (l.delta ?? 0), 0) * 100) / 100;
