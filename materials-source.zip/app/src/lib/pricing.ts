/* Live pricing against the sold job. Claire sends one price sheet per client (every option's difference against the sold
   Estimate Review, client price only); this file turns the selections on screen into the lines and total the rep and
   client watch. These numbers are a display: Claire prices the final picks again herself when the sheet is submitted. */

export type TileOpt = { brand?: string; color?: string; series: string; size: string; sku: string; type: string; delta: number | null; ppsf?: number | null; labor?: number };
export type Prices = {
  est_id: string;
  sold_total?: number;
  tile?: { sold: string; sold_type: string; sf: number; lf?: number; options: TileOpt[] };
  finish?: { sold: string; sf: number; options: { family: string; tier: string; colors: string[]; delta: number | null }[] };
  coping?: { sold: string[]; options: { color: string; thickness: string; profile: string; delta: number | null; offered?: boolean }[]; materials?: Record<string, number | null> };
  deck?: { sold: string[]; sf: number; materials: Record<string, number | null> };
  pavers?: { sold: string[]; options: { color: string; pattern: string; delta: number | null }[] };
  custom?: { name: string; unit: string; price: number }[];
};
export type CustomItem = { id: number; name: string; qty: string };
/** delta null = no price on file yet ("price needed"); the line still shows so nobody signs past a hole. */
export type PriceLine = { key: string; label: string; detail: string; delta: number | null; note?: string };

const norm = (s: string) => s.toLowerCase().replace(/&/g, "and").replace(/gray/g, "grey").replace(/[^a-z0-9]+/g, " ").trim();
const dims = (s: string) => { const m = s.toLowerCase().match(/(\d+(?:\.\d+)?)\s*["”]?\s*x\s*(\d+(?:\.\d+)?)/); return m ? `${m[1]}x${m[2]}` : ""; };

export const money = (n: number) => `$${Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
export const signed = (n: number) => (n < -0.004 ? `Credit ${money(n)}` : n > 0.004 ? `+${money(n)}` : "Included");

const SERIES_ALIAS: Record<string, string> = { chateu: "chateau" };

/** A picked Aquabella tile against the priced series: same series, then same size. Two prices for one size is not a guess.
    undefined = nothing picked yet, null = no price on file. */
export function tileOption(p: Prices, product: string, size: string, sku = ""): TileOpt | null | undefined {
  if (!p.tile || !product) return undefined;
  // NPT is priced tile by tile (pool360): the SKU the picker resolved is the match, nothing looser.
  if (sku) {
    const hit = p.tile.options.find(o => o.brand === "NPT" && o.sku === sku);
    if (hit) return hit.delta === null ? null : hit;
  }
  let series = norm(product.split(" - ")[0]);
  series = SERIES_ALIAS[series] ?? series;
  const rows = p.tile.options.filter(o => o.brand !== "NPT" && norm(o.series) === series);
  if (!rows.length) return null;
  const want = dims(size) || norm(size).replace("hexagon", "hex");
  const sized = rows.filter(o => (dims(o.size) || norm(o.size)) === want || norm(o.size) === want);
  const pool = sized.length ? sized : rows;
  const exact = pool.find(o => norm(o.size) === norm(size) || o.size.toLowerCase() === want);
  if (exact) return exact.delta === null ? null : exact;
  const prices = Array.from(new Set(pool.map(o => o.delta)));
  return prices.length === 1 && prices[0] !== null ? pool[0] : null;
}
export function tileDelta(p: Prices, product: string, size: string): number | null | undefined {
  const o = tileOption(p, product, size);
  return o ? o.delta : o;
}
const r2 = (n: number) => Math.round((n + (n >= 0 ? 1e-9 : -1e-9)) * 100) / 100;
/** Field tile with a deco tile every n: the sold tile area splits n/(n+1) field and 1/(n+1) deco, each at its own price
    difference per SF, and labor follows the field tile. Same arithmetic Claire uses for the change order. */
export function tileWithDeco(p: Prices, field: TileOpt, deco: TileOpt, n: number): number | null {
  if (!p.tile || field.ppsf == null || deco.ppsf == null || !(n > 0)) return null;
  const qf = r2(p.tile.sf * n / (n + 1)), qd = r2(p.tile.sf - qf);
  return r2(r2(qf * field.ppsf) + r2(qd * deco.ppsf) + (field.labor ?? 0));
}

const FINISH_FAMILY: Record<string, string> = {
  "stonescapes|mini pebble": "mini_pebble",
  "stonescapes|glass mini pebble": "glass_mini_pebble",
  "quartz|": "quartz",
  "plaster|": "plaster",
};

export function finishDelta(p: Prices, brand: string, texture: string, color: string): number | null | undefined {
  if (!p.finish || !brand) return undefined;
  const fam = FINISH_FAMILY[`${norm(brand)}|${norm(texture)}`] ?? FINISH_FAMILY[`${norm(brand)}|`];
  if (!fam) return null;
  if (!color) return undefined;
  const hit = p.finish.options.find(o => o.family === fam && o.colors.some(c => norm(c) === norm(color)));
  return hit ? hit.delta : null;
}

export function copingDelta(p: Prices, color: string, thickness: string, profile: string): number | null | undefined {
  if (!p.coping) return undefined;
  if (!color || !thickness || !profile) return undefined;
  const th = thickness.replace(/\s+/g, "").toUpperCase();
  const hit = p.coping.options.find(o => norm(o.color) === norm(color) && o.thickness === th && norm(o.profile) === norm(profile));
  return hit ? hit.delta : null;
}

export function paverDelta(p: Prices, color: string, pattern: string): number | null | undefined {
  if (!p.pavers) return undefined;
  if (!color || !pattern) return undefined;
  const hit = p.pavers.options.find(o => norm(o.color) === norm(color) && norm(o.pattern) === norm(pattern));
  return hit ? hit.delta : null;
}

type Read = (k: string) => string;

export function priceSelections(p: Prices, eff: Read, opt: { concrete: boolean; waterlineNa: boolean; decks: number[]; customs: CustomItem[] }): PriceLine[] {
  const out: PriceLine[] = [];
  const add = (key: string, label: string, detail: string, d: number | null | undefined, note?: string) => {
    if (d === undefined) return;
    out.push({ key, label, detail, delta: d, note: d === null ? note ?? "Price needed" : note });
  };

  if (opt.concrete && p.finish) {
    const brand = eff("interior.brand"), texture = eff("interior.texture"), color = eff("interior.color");
    add("finish", "Interior finish", [brand, texture, color].filter(Boolean).join(" · "), finishDelta(p, brand, texture, color));
  }

  if (p.coping) {
    const mat = eff("coping.material");
    if (mat === "Travertine") {
      const c = eff("coping.travColor"), t = eff("coping.travThickness"), pr = eff("coping.travProfile");
      const th = t.replace(/\s+/g, "").toUpperCase();
      const opt = p.coping.options.find(o => norm(o.color) === norm(c) && o.thickness === th && norm(o.profile) === norm(pr));
      add("coping", "Coping", [c, t, pr].filter(Boolean).join(" · "), copingDelta(p, c, t, pr), opt && opt.offered === false ? "Not offered in this color and profile" : undefined);
    } else if (mat) {
      const key = mat === "Concrete Paver" ? "" : mat;
      const d = p.coping.materials && key in p.coping.materials ? p.coping.materials[key] : null;
      add("coping", "Coping", `${mat} in place of the coping sold`, d);
    }
  }

  if (opt.concrete && !opt.waterlineNa && p.tile) {
    const brand = eff("waterline.brand"), product = eff("waterline.product"), size = eff("waterline.size");
    const detail = [brand === "__other__" ? "" : brand === "Aquabella" ? "" : brand, product, eff("waterline.color"), size].filter(Boolean).join(" · ");
    const field = brand === "Aquabella" && product ? tileOption(p, product, size)
      : brand === "NPT" && product ? (eff("waterline.sku") ? tileOption(p, product, size, eff("waterline.sku")) ?? null : undefined)
      : brand && product ? null : undefined;
    const decoOn = eff("waterline.deco.on") === "Yes" && !!eff("waterline.deco.product");
    const n = Number((eff("waterline.deco.ratio").match(/^(\d+)\s*:/) ?? [])[1] ?? 0);
    const deco = !decoOn ? null : brand === "Aquabella" ? tileOption(p, eff("waterline.deco.product"), eff("waterline.deco.size"))
      : brand === "NPT" && eff("waterline.deco.sku") ? tileOption(p, eff("waterline.deco.product"), eff("waterline.deco.size"), eff("waterline.deco.sku")) : null;
    if (field && decoOn && deco && n > 0) {
      add("tile", "Waterline tile", `${detail} with ${eff("waterline.deco.product")} deco every ${n}`, tileWithDeco(p, field, deco, n));
    } else {
      add("tile", "Waterline tile", detail, field ? field.delta : field);
      if (decoOn) add("deco", "Deco tile", eff("waterline.deco.product"), null, n > 0 ? "Price needed" : "Pick the pattern ratio");
    }
  }

  if (p.pavers || p.deck) {
    const key = (id: number) => {
      const m = eff(`decking.${id}.material`), base = `decking.${id}`;
      if (!m) return "";
      if (m === "Travertine") return `Travertine|${eff(`${base}.travColor`)}|${eff(`${base}.paverFormat`)}`;
      if (m === "Poured Concrete") return `Poured Concrete|${eff(`${base}.finish`)}${eff(`${base}.finish`) === "Broom Finish" && eff(`${base}.integralColor`) === "Yes" ? "|color" : ""}`;
      return m;
    };
    const picks = Array.from(new Set(opt.decks.map(key).filter(Boolean)));
    if (picks.length > 1) {
      add("deck", "Pool deck", "Deck areas have different picks", null, "Price needed: areas differ");
    } else if (picks.length === 1) {
      const k = picks[0];
      if (k.startsWith("Travertine|")) {
        const [, c, f] = k.split("|");
        add("deck", "Pool deck", ["Travertine", c, f].filter(Boolean).join(" · "), p.pavers ? paverDelta(p, c, f) : c && f ? null : undefined);
      } else if (!k.endsWith("|")) {
        const d = p.deck && k in p.deck.materials ? p.deck.materials[k] : null;
        add("deck", "Pool deck", `${k.replace(/\|color$/, " with integral color").replace("|", " · ")} in place of the deck sold`, d);
      }
    }
  }

  for (const c of opt.customs) {
    const it = (p.custom ?? []).find(x => x.name === c.name);
    const qty = Number(c.qty);
    if (!c.name) continue;
    if (!it || !(qty > 0)) { out.push({ key: `custom.${c.id}`, label: "Added item", detail: c.name, delta: null, note: it ? "Enter a quantity" : "Price needed" }); continue; }
    out.push({ key: `custom.${c.id}`, label: "Added item", detail: `${it.name} · ${qty} ${it.unit}`, delta: Math.round(qty * it.price * 100) / 100 });
  }
  return out;
}

export const totalOf = (lines: PriceLine[]) => Math.round(lines.reduce((s, l) => s + (l.delta ?? 0), 0) * 100) / 100;
