/* Talks to the Apps Script proxy. text/plain avoids a CORS preflight, which
   Apps Script web apps cannot answer (same pattern as warranty/referral). */

declare global {
  interface Window { MATSEL_ENDPOINT?: string }
}

export type Rep = { name: string; email: string; token: string };

/** The rep's sign in expired or was turned off. */
export class SessionError extends Error {}

export const REP_DOMAIN = "cpoolworks.com";

async function call(body: unknown): Promise<any> {
  const endpoint = window.MATSEL_ENDPOINT || import.meta.env.VITE_SUBMIT_URL;
  if (!endpoint) throw new Error("This page is not connected to the submission service yet.");
  let res: Response;
  try {
    res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify(body),
    });
  } catch {
    throw new Error("No connection. Check the internet and try again. Nothing was lost.");
  }
  const data = await res.json().catch(() => null);
  if (!data) throw new Error(`The submission service returned an unexpected response (${res.status}). Try again.`);
  if (data.error === "session_expired") throw new SessionError("Your sign in expired. Confirm your email to keep going.");
  if (!data.ok) throw new Error(data.error || "Request was not accepted. Try again.");
  return data;
}

export function requestCode(name: string, email: string) {
  return call({ action: "request_code", name, email });
}

export async function verifyCode(email: string, code: string): Promise<Rep> {
  const d = await call({ action: "verify_code", email, code });
  return { name: d.name, email: d.email, token: d.token };
}

export function checkSession(token: string) {
  return call({ action: "session", token });
}

export function submitSelection(rep: Rep, payload: Record<string, unknown>) {
  return call({ action: "submit", token: rep.token, payload });
}
