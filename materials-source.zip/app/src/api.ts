/* Talks to the Apps Script proxy. text/plain avoids a CORS preflight, which
   Apps Script web apps cannot answer (same pattern as warranty/referral). */

declare global {
  interface Window { MATSEL_ENDPOINT?: string }
}

export type Rep = { name: string; email: string; passcode: string };

export class PasscodeError extends Error {}

async function call(body: unknown): Promise<any> {
  const endpoint = window.MATSEL_ENDPOINT || import.meta.env.VITE_SUBMIT_URL;
  if (!endpoint) throw new Error("This page is not connected to the submission service yet.");
  let res: Response;
  try {
    res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify(body),
    });
  } catch {
    throw new Error("No connection. Check the internet and try again. Nothing was lost.");
  }
  const data = await res.json().catch(() => null);
  if (!data) throw new Error(`The submission service returned an unexpected response (${res.status}). Try again.`);
  if (data.error === "bad_passcode") throw new PasscodeError("The rep passcode is not valid. Sign in again.");
  if (!data.ok) throw new Error(data.error || "Submission was not accepted. Try again.");
  return data;
}

export function verifyRep(rep: Rep) {
  return call({ action: "verify", passcode: rep.passcode, repName: rep.name, repEmail: rep.email });
}

export function submitSelection(rep: Rep, payload: Record<string, unknown>) {
  return call({ action: "submit", passcode: rep.passcode, payload });
}
