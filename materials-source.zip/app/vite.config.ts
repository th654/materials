import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { viteSingleFile } from "vite-plugin-singlefile";

// Builds to ONE self-contained index.html (JS, CSS and logo inlined) so the
// GitHub Pages repo stays as simple as the warranty and referral portals.
export default defineConfig({
  plugins: [react(), viteSingleFile()],
  build: { outDir: "dist", assetsInlineLimit: 100_000_000 },
});
