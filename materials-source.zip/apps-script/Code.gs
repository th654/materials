/**
 * CPW Material Selections Proxy
 * Deploy from info@cpoolworks.com (same as the warranty and referral portals).
 *
 * What it does, per submission from materials.cpoolworks.com:
 *   1. Checks the rep passcode (so nobody off the street can trigger a DocuSign).
 *   2. Logs a full backup copy to the "Material Selections Log" sheet.
 *   3. Forwards the payload to the Viktor webhook, which runs everything else
 *      (selection sheet, DocuSign, Drive filing, ClickUp, team notice).
 *   4. Records Viktor's response on the log row. If Viktor fails, emails the
 *      alert address so the office can resend from the log.
 * The Viktor webhook token lives only in Script Properties, never in the page.
 *
 * SETUP (once):
 *   a. Project Settings > Script Properties, add:
 *        VIKTOR_WEBHOOK_URL  full tokenized Viktor webhook URL for /cpw/material-selections-submit
 *        REP_PASSCODE        the passcode reps type on first sign in
 *        ALERT_EMAIL         optional, defaults to the account running the script (info@)
 *   b. Run setup() once from the editor and approve the permissions.
 *   c. Deploy > New deployment > Web app. Execute as: Me. Who has access: Anyone.
 *   d. Paste the /exec URL into config.js in the th654/materials repo.
 */

var LOG_SHEET_NAME = 'Material Selections Log';
var HEADERS = ['Received', 'Submission ID', 'Rep', 'Rep email', 'Client', 'Client email',
  'Mode', 'Pool type', 'Complete', 'Viktor status', 'Viktor response', 'Payload JSON'];

function setup() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty('LOG_SHEET_ID');
  if (id) {
    try { SpreadsheetApp.openById(id); Logger.log('Log sheet exists: ' + id); return; } catch (e) {}
  }
  var ss = SpreadsheetApp.create(LOG_SHEET_NAME);
  var sh = ss.getSheets()[0];
  sh.setName('Log');
  sh.appendRow(HEADERS);
  sh.setFrozenRows(1);
  sh.getRange(1, 1, 1, HEADERS.length).setFontWeight('bold');
  props.setProperty('LOG_SHEET_ID', ss.getId());
  Logger.log('Created log sheet: ' + ss.getUrl());
  // Touch the external services once so the permission prompt covers them.
  UrlFetchApp.getRequest('https://example.com');
  MailApp.getRemainingDailyQuota();
}

function doGet() {
  return json({ ok: true, service: 'CPW Material Selections Proxy' });
}

function doPost(e) {
  var req;
  try {
    req = JSON.parse(e.postData.contents);
  } catch (err) {
    return json({ ok: false, error: 'Bad request.' });
  }

  var props = PropertiesService.getScriptProperties();
  var passcode = props.getProperty('REP_PASSCODE');
  if (!passcode || String(req.passcode || '') !== passcode) {
    return json({ ok: false, error: 'bad_passcode' });
  }

  if (req.action === 'verify') return json({ ok: true });
  if (req.action !== 'submit') return json({ ok: false, error: 'Unknown action.' });

  var p = req.payload || {};
  var problem = validate(p);
  if (problem) return json({ ok: false, error: problem });

  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var sh = logSheet();

    // Same submission_id already accepted by Viktor: do not send a second DocuSign.
    var existing = findRow(sh, p.submission_id);
    if (existing && isSuccess(sh.getRange(existing, 10).getValue())) {
      return json({ ok: true, duplicate: true });
    }

    var row = existing || (sh.getLastRow() + 1);
    sh.getRange(row, 1, 1, HEADERS.length).setValues([[
      new Date(), p.submission_id || '', p.repName || '', p.repEmail || '',
      p.clientName || '', p.clientEmail || '', p.mode || '', p.poolType || '',
      p.complete === true ? 'Yes' : 'No', 'sending', '', JSON.stringify(p)
    ]]);
    SpreadsheetApp.flush();

    var status = 0, body = '';
    try {
      var res = UrlFetchApp.fetch(props.getProperty('VIKTOR_WEBHOOK_URL'), {
        method: 'post',
        contentType: 'application/json',
        payload: JSON.stringify(p),
        muteHttpExceptions: true
      });
      status = res.getResponseCode();
      body = res.getContentText();
    } catch (err) {
      body = String(err);
    }

    sh.getRange(row, 10, 1, 2).setValues([[status, String(body).slice(0, 1000)]]);

    if (isSuccess(status)) return json({ ok: true, status: status });

    notifyFailure(p, status, body, row);
    return json({ ok: false, error: 'The selection is saved, but it did not reach the signing system (' + (status || 'no response') + '). Try again in a minute. The office has been notified.' });
  } finally {
    lock.releaseLock();
  }
}

function validate(p) {
  if (!p.clientName) return 'Client name is required.';
  if (p.mode !== 'sign_now' && p.mode !== 'send_later') return 'Invalid mode.';
  if (!p.poolType) return 'Pool type is required.';
  if (!p.selections || typeof p.selections !== 'object') return 'Selections are missing.';
  if (p.mode === 'sign_now' && !/^\S+@\S+\.\S+$/.test(String(p.clientEmail || ''))) {
    return 'A valid client email is required to send the DocuSign.';
  }
  return '';
}

function isSuccess(code) {
  var n = Number(code);
  return n >= 200 && n < 300;
}

function logSheet() {
  var id = PropertiesService.getScriptProperties().getProperty('LOG_SHEET_ID');
  if (!id) throw new Error('Run setup() first.');
  return SpreadsheetApp.openById(id).getSheetByName('Log');
}

function findRow(sh, submissionId) {
  if (!submissionId) return 0;
  var last = sh.getLastRow();
  if (last < 2) return 0;
  var ids = sh.getRange(2, 2, last - 1, 1).getValues();
  for (var i = ids.length - 1; i >= 0; i--) {
    if (ids[i][0] === submissionId) return i + 2;
  }
  return 0;
}

function notifyFailure(p, status, body, row) {
  var props = PropertiesService.getScriptProperties();
  var to = props.getProperty('ALERT_EMAIL') || Session.getEffectiveUser().getEmail();
  var sheetUrl = SpreadsheetApp.openById(props.getProperty('LOG_SHEET_ID')).getUrl();
  MailApp.sendEmail({
    to: to,
    subject: 'Material selection did not reach Viktor: ' + (p.clientName || 'unknown client'),
    body: [
      'A material selection was submitted but the Viktor webhook did not accept it.',
      '',
      'Client: ' + (p.clientName || '') + ' ' + (p.clientEmail ? '(' + p.clientEmail + ')' : ''),
      'Rep: ' + (p.repName || '') + ' ' + (p.repEmail ? '(' + p.repEmail + ')' : ''),
      'Mode: ' + (p.mode || ''),
      'Viktor status: ' + (status || 'no response'),
      'Response: ' + String(body).slice(0, 500),
      '',
      'Full payload is on row ' + row + ' of the log: ' + sheetUrl,
      'To resend it, run resendRow(' + row + ') from the script editor.'
    ].join('\n')
  });
}

/** Manual recovery: resend a logged submission to Viktor. */
function resendRow(row) {
  var sh = logSheet();
  var p = JSON.parse(sh.getRange(row, 12).getValue());
  var res = UrlFetchApp.fetch(PropertiesService.getScriptProperties().getProperty('VIKTOR_WEBHOOK_URL'), {
    method: 'post', contentType: 'application/json', payload: JSON.stringify(p), muteHttpExceptions: true
  });
  sh.getRange(row, 10, 1, 2).setValues([[res.getResponseCode(), res.getContentText().slice(0, 1000)]]);
  Logger.log(res.getResponseCode() + ' ' + res.getContentText());
}

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
