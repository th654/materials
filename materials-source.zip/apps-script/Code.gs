/**
 * CPW Material Selections Proxy
 * Owned by info@cpoolworks.com (same as the warranty and referral portals).
 *
 * Rep access (self serve, no admin involvement):
 *   - A rep enters name + @cpoolworks.com email, gets a 6 digit code by email,
 *     enters it, and is signed in on that device for 30 days.
 *   - After 30 days they confirm their email again. When a CPW mailbox is shut off,
 *     that person can no longer receive codes, so access lapses on its own.
 *   - Instant cutoff if ever needed: set Active to "No" on the Reps tab.
 *
 * Per submission from materials.cpoolworks.com:
 *   1. Checks the rep's session. Rep name/email on the payload come from the
 *      verified session, not from what the browser claims.
 *   2. Logs a full backup copy to the "Material Selections Log" sheet (Log tab).
 *   3. Forwards the payload to the Viktor webhook, which runs everything else.
 *   4. Records Viktor's response. On failure, emails ALERT_EMAIL (default info@).
 *
 * Script Properties: VIKTOR_WEBHOOK_URL, LOG_SHEET_ID (set by setup), ALERT_EMAIL (optional).
 */

var LOG_SHEET_NAME = 'Material Selections Log';
var HEADERS = ['Received', 'Submission ID', 'Rep', 'Rep email', 'Client', 'Client email',
  'Mode', 'Pool type', 'Complete', 'Viktor status', 'Viktor response', 'Payload JSON'];
var REPS_HEADERS = ['Email', 'Name', 'Active', 'First verified', 'Last verified'];
var SESSIONS_HEADERS = ['Token hash', 'Email', 'Created', 'Expires'];

var DOMAIN = 'cpoolworks.com';
var SESSION_DAYS = 30;
var CODE_TTL_SEC = 900;          // code valid 15 minutes
var MAX_CODE_ATTEMPTS = 5;       // wrong guesses before the code is burned
var MAX_CODES_PER_HOUR = 5;      // per email address

function setup() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty('LOG_SHEET_ID');
  var ss;
  if (id) {
    try { ss = SpreadsheetApp.openById(id); } catch (e) { ss = null; }
  }
  if (!ss) {
    ss = SpreadsheetApp.create(LOG_SHEET_NAME);
    var sh = ss.getSheets()[0];
    sh.setName('Log');
    sh.appendRow(HEADERS);
    sh.setFrozenRows(1);
    sh.getRange(1, 1, 1, HEADERS.length).setFontWeight('bold');
    props.setProperty('LOG_SHEET_ID', ss.getId());
  }
  tab('Reps', REPS_HEADERS);
  tab('Sessions', SESSIONS_HEADERS);
  Logger.log('Log sheet: ' + ss.getUrl());
  UrlFetchApp.getRequest('https://example.com');
  MailApp.getRemainingDailyQuota();
}

function doGet() {
  return json({ ok: true, service: 'CPW Material Selections Proxy' });
}

function doPost(e) {
  var req;
  try {
    req = JSON.parse(e.postData.contents);
  } catch (err) {
    return json({ ok: false, error: 'Bad request.' });
  }
  try {
    switch (req.action) {
      case 'request_code': return json(requestCode(req));
      case 'verify_code': return json(verifyCode(req));
      case 'session': {
        var s = getSession(req.token);
        return json(s ? { ok: true, name: s.name, email: s.email } : { ok: false, error: 'session_expired' });
      }
      case 'submit': return json(submit(req));
      default: return json({ ok: false, error: 'Unknown action.' });
    }
  } catch (err) {
    return json({ ok: false, error: 'Server error. Try again in a minute.' });
  }
}

/* ============================ rep access ============================ */

function normEmail(v) {
  var e = String(v || '').trim().toLowerCase();
  var re = new RegExp('^[a-z0-9._%+-]+@' + DOMAIN.replace('.', '\\.') + '$');
  return re.test(e) ? e : '';
}

function requestCode(req) {
  var email = normEmail(req.email);
  var name = String(req.name || '').trim().slice(0, 80);
  if (!email) return { ok: false, error: 'Use your @' + DOMAIN + ' email address.' };
  if (name.length < 2) return { ok: false, error: 'Enter your name.' };

  var rep = findRep(email);
  if (rep && rep.active !== 'Yes') return { ok: false, error: 'This email does not have access. Contact the office.' };

  var cache = CacheService.getScriptCache();
  var rlKey = 'rl:' + email;
  var sent = Number(cache.get(rlKey) || 0);
  if (sent >= MAX_CODES_PER_HOUR) return { ok: false, error: 'Too many codes requested. Try again in an hour.' };
  cache.put(rlKey, String(sent + 1), 3600);

  var code = String(parseInt(Utilities.getUuid().replace(/-/g, '').slice(0, 12), 16) % 1000000);
  while (code.length < 6) code = '0' + code;
  cache.put('code:' + email, JSON.stringify({ h: sha(code + '|' + email), n: name, a: 0 }), CODE_TTL_SEC);

  MailApp.sendEmail({
    to: email,
    name: 'CPW Material Selections',
    subject: 'Your material selections code: ' + code,
    body: 'Your sign in code for materials.cpoolworks.com is ' + code + '.\n\nIt expires in 15 minutes. If you did not request it, ignore this email.',
    htmlBody: '<p>Your sign in code for materials.cpoolworks.com:</p>' +
      '<p style="font-size:28px;font-weight:bold;letter-spacing:4px;margin:12px 0">' + code + '</p>' +
      '<p>It expires in 15 minutes. If you did not request it, ignore this email.</p>'
  });
  return { ok: true };
}

function verifyCode(req) {
  var email = normEmail(req.email);
  var code = String(req.code || '').replace(/\D/g, '');
  if (!email || code.length !== 6) return { ok: false, error: 'Enter the 6 digit code from your email.' };

  var cache = CacheService.getScriptCache();
  var key = 'code:' + email;
  var raw = cache.get(key);
  if (!raw) return { ok: false, error: 'That code expired. Send a new one.' };
  var rec = JSON.parse(raw);

  if (sha(code + '|' + email) !== rec.h) {
    rec.a = (rec.a || 0) + 1;
    if (rec.a >= MAX_CODE_ATTEMPTS) {
      cache.remove(key);
      return { ok: false, error: 'Too many wrong tries. Send a new code.' };
    }
    cache.put(key, JSON.stringify(rec), CODE_TTL_SEC);
    return { ok: false, error: 'That code is not right. Check the email and try again.' };
  }
  cache.remove(key);

  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var rep = upsertRep(email, rec.n);
    if (rep.active !== 'Yes') return { ok: false, error: 'This email does not have access. Contact the office.' };

    var token = Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '');
    var now = new Date();
    var expires = new Date(now.getTime() + SESSION_DAYS * 86400000);
    tab('Sessions', SESSIONS_HEADERS).appendRow([sha(token), email, now, expires]);
    return { ok: true, token: token, name: rep.name, email: email, expires: expires.toISOString() };
  } finally {
    lock.releaseLock();
  }
}

function getSession(token) {
  if (!token || String(token).length < 32) return null;
  var h = sha(String(token));
  var sh = tab('Sessions', SESSIONS_HEADERS);
  var last = sh.getLastRow();
  if (last < 2) return null;
  var rows = sh.getRange(2, 1, last - 1, 4).getValues();
  for (var i = rows.length - 1; i >= 0; i--) {
    if (rows[i][0] === h) {
      if (new Date(rows[i][3]).getTime() < Date.now()) return null;
      var rep = findRep(rows[i][1]);
      if (!rep || rep.active !== 'Yes') return null;
      return { name: rep.name, email: rep.email };
    }
  }
  return null;
}

function findRep(email) {
  var sh = tab('Reps', REPS_HEADERS);
  var last = sh.getLastRow();
  if (last < 2) return null;
  var rows = sh.getRange(2, 1, last - 1, 3).getValues();
  for (var i = 0; i < rows.length; i++) {
    if (String(rows[i][0]).toLowerCase() === email) {
      return { row: i + 2, email: email, name: rows[i][1], active: String(rows[i][2] || 'Yes').trim() };
    }
  }
  return null;
}

function upsertRep(email, name) {
  var sh = tab('Reps', REPS_HEADERS);
  var rep = findRep(email);
  var now = new Date();
  if (rep) {
    if (name) sh.getRange(rep.row, 2).setValue(name);
    sh.getRange(rep.row, 5).setValue(now);
    rep.name = name || rep.name;
    return rep;
  }
  sh.appendRow([email, name, 'Yes', now, now]);
  return { row: sh.getLastRow(), email: email, name: name, active: 'Yes' };
}

/* ============================ submissions ============================ */

function submit(req) {
  var s = getSession(req.token);
  if (!s) return { ok: false, error: 'session_expired' };

  var p = req.payload || {};
  p.repName = s.name;
  p.repEmail = s.email;
  var problem = validate(p);
  if (problem) return { ok: false, error: problem };

  var props = PropertiesService.getScriptProperties();
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var sh = logSheet();

    // Same submission_id already accepted by Viktor: do not send a second DocuSign.
    var existing = findRow(sh, p.submission_id);
    if (existing && isSuccess(sh.getRange(existing, 10).getValue())) {
      return { ok: true, duplicate: true };
    }

    var row = existing || (sh.getLastRow() + 1);
    sh.getRange(row, 1, 1, HEADERS.length).setValues([[
      new Date(), p.submission_id || '', p.repName || '', p.repEmail || '',
      p.clientName || '', p.clientEmail || '', p.mode || '', p.poolType || '',
      p.complete === true ? 'Yes' : 'No', 'sending', '', JSON.stringify(p)
    ]]);
    SpreadsheetApp.flush();

    var status = 0, body = '';
    try {
      var res = UrlFetchApp.fetch(props.getProperty('VIKTOR_WEBHOOK_URL'), {
        method: 'post',
        contentType: 'application/json',
        payload: JSON.stringify(p),
        muteHttpExceptions: true
      });
      status = res.getResponseCode();
      body = res.getContentText();
    } catch (err) {
      body = String(err);
    }

    sh.getRange(row, 10, 1, 2).setValues([[status, String(body).slice(0, 1000)]]);

    if (isSuccess(status)) return { ok: true, status: status };

    notifyFailure(p, status, body, row);
    return { ok: false, error: 'The selection is saved, but it did not reach the signing system (' + (status || 'no response') + '). Try again in a minute. The office has been notified.' };
  } finally {
    lock.releaseLock();
  }
}

function validate(p) {
  if (!p.clientName) return 'Client name is required.';
  if (p.mode !== 'sign_now' && p.mode !== 'send_later') return 'Invalid mode.';
  if (!p.poolType) return 'Pool type is required.';
  if (!p.selections || typeof p.selections !== 'object') return 'Selections are missing.';
  if (p.mode === 'sign_now' && !/^\S+@\S+\.\S+$/.test(String(p.clientEmail || ''))) {
    return 'A valid client email is required to send the DocuSign.';
  }
  return '';
}

function isSuccess(code) {
  var n = Number(code);
  return n >= 200 && n < 300;
}

/* ============================ helpers ============================ */

function spreadsheet() {
  var id = PropertiesService.getScriptProperties().getProperty('LOG_SHEET_ID');
  if (!id) throw new Error('Run setup() first.');
  return SpreadsheetApp.openById(id);
}

function logSheet() {
  return spreadsheet().getSheetByName('Log');
}

function tab(name, headers) {
  var ss = spreadsheet();
  var sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.appendRow(headers);
    sh.setFrozenRows(1);
    sh.getRange(1, 1, 1, headers.length).setFontWeight('bold');
  }
  return sh;
}

function findRow(sh, submissionId) {
  if (!submissionId) return 0;
  var last = sh.getLastRow();
  if (last < 2) return 0;
  var ids = sh.getRange(2, 2, last - 1, 1).getValues();
  for (var i = ids.length - 1; i >= 0; i--) {
    if (ids[i][0] === submissionId) return i + 2;
  }
  return 0;
}

function sha(s) {
  var bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, s, Utilities.Charset.UTF_8);
  return bytes.map(function (b) { return ('0' + (b & 0xff).toString(16)).slice(-2); }).join('');
}

function notifyFailure(p, status, body, row) {
  var props = PropertiesService.getScriptProperties();
  var to = props.getProperty('ALERT_EMAIL') || Session.getEffectiveUser().getEmail();
  var sheetUrl = spreadsheet().getUrl();
  MailApp.sendEmail({
    to: to,
    subject: 'Material selection did not reach Viktor: ' + (p.clientName || 'unknown client'),
    body: [
      'A material selection was submitted but the Viktor webhook did not accept it.',
      '',
      'Client: ' + (p.clientName || '') + ' ' + (p.clientEmail ? '(' + p.clientEmail + ')' : ''),
      'Rep: ' + (p.repName || '') + ' ' + (p.repEmail ? '(' + p.repEmail + ')' : ''),
      'Mode: ' + (p.mode || ''),
      'Viktor status: ' + (status || 'no response'),
      'Response: ' + String(body).slice(0, 500),
      '',
      'Full payload is on row ' + row + ' of the Log tab: ' + sheetUrl,
      'To resend it, run resendRow(' + row + ') from the script editor.'
    ].join('\n')
  });
}

/** Manual recovery: resend a logged submission to Viktor. */
function resendRow(row) {
  var sh = logSheet();
  var p = JSON.parse(sh.getRange(row, 12).getValue());
  var res = UrlFetchApp.fetch(PropertiesService.getScriptProperties().getProperty('VIKTOR_WEBHOOK_URL'), {
    method: 'post', contentType: 'application/json', payload: JSON.stringify(p), muteHttpExceptions: true
  });
  sh.getRange(row, 10, 1, 2).setValues([[res.getResponseCode(), res.getContentText().slice(0, 1000)]]);
  Logger.log(res.getResponseCode() + ' ' + res.getContentText());
}

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
